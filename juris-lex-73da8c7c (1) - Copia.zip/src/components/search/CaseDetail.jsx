import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { askOpenAI } from "@/api/functions";
import {
  FileText,
  Calendar,
  Building2,
  Tag,
  ClipboardList,
  Sparkles,
  Lightbulb,
  X
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import ReactMarkdown from 'react-markdown';

export default function CaseDetail({ case: caso, onClose }) {
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    // Limpa a IA quando o caso muda
    setAiPrompt("");
    setAiResponse("");
    setAiLoading(false);
  }, [caso]);

  const handleAskAI = async () => {
    if (!aiPrompt.trim() || !caso) return;
    setAiLoading(true);
    setAiResponse("");
    try {
      const { data } = await askOpenAI({
        prompt: aiPrompt,
        context: caso.ementa
      });
      setAiResponse(data.response);
    } catch (error) {
      console.error("Error asking AI:", error);
      setAiResponse("Desculpe, ocorreu um erro ao contatar a IA. Tente novamente.");
    } finally {
      setAiLoading(false);
    }
  };
  
  if (!caso) {
    return (
      <Card className="sticky top-6">
        <CardContent className="p-6 text-center text-slate-500">
          <FileText className="w-12 h-12 mx-auto mb-4 text-slate-400" />
          <p className="font-medium">Selecione um caso</p>
          <p className="text-sm">Os detalhes aparecerão aqui.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="sticky top-6 space-y-6">
      <Card className="bg-white border-0 shadow-lg overflow-hidden">
        <CardHeader className="bg-slate-50 p-4 border-b">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <CardTitle className="text-base text-slate-800 flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-blue-600" />
                Detalhes do Caso
              </CardTitle>
              <CardDescription className="text-xs">{caso.processo}</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-4 space-y-4">
          <div className="flex flex-wrap gap-2 text-xs">
            <Badge variant="secondary">
              <Building2 className="w-3 h-3 mr-1" />
              {caso.tribunal}
            </Badge>
            {caso.data_julgamento && (
              <Badge variant="secondary">
                <Calendar className="w-3 h-3 mr-1" />
                {format(new Date(caso.data_julgamento), "dd/MM/yyyy", { locale: ptBR })}
              </Badge>
            )}
            {caso.categoria_automatica && (
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                <Tag className="w-3 h-3 mr-1" />
                {caso.categoria_automatica}
              </Badge>
            )}
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-1 text-slate-700">Ementa</h4>
            <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">
              {caso.ementa}
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white border-0 shadow-lg">
        <CardHeader className="p-4 border-b bg-slate-50">
          <CardTitle className="text-base text-slate-800 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Análise com IA
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 space-y-4">
          <Textarea
            placeholder="Faça uma pergunta sobre a ementa... Ex: 'Qual foi o principal fundamento da decisão?'"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            className="text-sm"
          />
          <Button
            onClick={handleAskAI}
            disabled={aiLoading || !aiPrompt.trim()}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {aiLoading ? (
              <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" /> Analisando...</>
            ) : (
              <><Lightbulb className="w-4 h-4 mr-2" /> Perguntar à IA</>
            )}
          </Button>

          {aiLoading && (
            <div className="space-y-2 pt-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          )}

          {aiResponse && !aiLoading && (
            <div className="text-sm p-3 bg-purple-50 border border-purple-200 rounded-lg">
              <ReactMarkdown 
                className="prose prose-sm max-w-none prose-slate"
                components={{ p: ({children}) => <p className="mb-2 last:mb-0">{children}</p> }}
              >
                {aiResponse}
              </ReactMarkdown>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}