import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { FileSearch, Calendar, Gavel, Users, ChevronsRight, Landmark, Clock } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function ProcessoDetalhadoCard({ processo }) {
  if (!processo) return null;

  return (
    <Card className="bg-white border-0 shadow-lg mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-slate-800">
          <FileSearch className="w-6 h-6 text-blue-600" />
          Detalhes do Processo
        </CardTitle>
        <p className="font-bold text-lg text-slate-900 pt-2">{processo.numeroProcesso}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
          <div className="flex items-start gap-2">
            <Landmark className="w-4 h-4 mt-1 text-slate-500" />
            <div>
              <p className="font-medium text-slate-600">Tribunal</p>
              <p className="text-slate-800 font-semibold">{processo.tribunal?.nome || "Não informado"}</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Gavel className="w-4 h-4 mt-1 text-slate-500" />
            <div>
              <p className="font-medium text-slate-600">Órgão Julgador</p>
              <p className="text-slate-800">{processo.orgaoJulgador?.nome || "Não informado"}</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Calendar className="w-4 h-4 mt-1 text-slate-500" />
            <div>
              <p className="font-medium text-slate-600">Distribuição</p>
              <p className="text-slate-800">
                {processo.dataDistribuicao ? format(new Date(processo.dataDistribuicao), "dd/MM/yyyy HH:mm", { locale: ptBR }) : "N/A"}
              </p>
            </div>
          </div>
        </div>
        <div className="space-y-1">
            <p className="text-sm font-medium text-slate-600">Classe</p>
            <Badge variant="secondary">{processo.classe?.nome || "Não informado"}</Badge>
        </div>
        <div className="space-y-1">
            <p className="text-sm font-medium text-slate-600">Assunto</p>
            <Badge variant="outline">{processo.assunto?.nome || "Não informado"}</Badge>
        </div>
        
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="partes">
            <AccordionTrigger className="flex items-center gap-2 font-medium text-base">
              <Users className="w-4 h-4" /> Partes Envolvidas ({processo.partes?.length || 0})
            </AccordionTrigger>
            <AccordionContent>
              <ul className="space-y-3">
                {(processo.partes || []).map((parte, idx) => (
                  <li key={idx} className="p-3 bg-slate-50 rounded-md">
                    <p className="font-semibold text-slate-800">{parte.nome}</p>
                    <div className="flex gap-2 mt-1">
                      <Badge variant="outline">{parte.polo}</Badge>
                      <Badge variant="outline">{parte.participacao}</Badge>
                    </div>
                  </li>
                ))}
              </ul>
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="movimentacoes">
            <AccordionTrigger className="flex items-center gap-2 font-medium text-base">
              <ChevronsRight className="w-4 h-4" /> Movimentações ({processo.movimentacoes?.length || 0})
            </AccordionTrigger>
            <AccordionContent>
              <ul className="space-y-3 max-h-96 overflow-y-auto pr-2">
                {(processo.movimentacoes || []).map((mov, idx) => (
                  <li key={idx} className="p-3 bg-slate-50 rounded-md border-l-4 border-blue-300">
                    <div className="flex items-center justify-between mb-2">
                        <p className="font-semibold text-slate-800">{mov.nome}</p>
                        <Badge variant="secondary" className="flex items-center gap-1.5">
                            <Clock className="w-3 h-3" />
                            {mov.dataHora ? format(new Date(mov.dataHora), "dd/MM/yyyy", { locale: ptBR }) : "N/A"}
                        </Badge>
                    </div>
                    <p className="text-sm text-slate-600">{mov.texto}</p>
                  </li>
                ))}
              </ul>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}