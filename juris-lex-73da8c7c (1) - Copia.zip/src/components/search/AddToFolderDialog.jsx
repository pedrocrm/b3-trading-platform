import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Pasta, User } from "@/api/entities";
import { Folder, CheckCircle, AlertCircle, PlusCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function AddToFolderDialog({ open, onOpenChange, caso, user }) {
  const [folders, setFolders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState(null);

  useEffect(() => {
    if (open && user) {
      loadFolders();
      setFeedback(null);
    }
  }, [open, user]);

  const loadFolders = async () => {
    setLoading(true);
    try {
      const userFolders = await Pasta.filter({ owner_user: user.email });
      setFolders(userFolders);
    } catch (error) {
      console.error("Error loading folders:", error);
      setFeedback({ type: 'error', message: 'Erro ao carregar pastas.' });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveFolder = async (folder) => {
    if (!caso) return;

    if (folder.casos?.includes(caso.id)) {
      setFeedback({ type: 'info', message: 'Este caso já está nesta pasta.' });
      return;
    }

    try {
      const updatedCasos = [...(folder.casos || []), caso.id];
      await Pasta.update(folder.id, { casos: updatedCasos });
      setFeedback({ type: 'success', message: `Salvo em "${folder.nome}" com sucesso!` });
      setTimeout(() => onOpenChange(false), 1500);
    } catch (error) {
      console.error("Error saving to folder:", error);
      setFeedback({ type: 'error', message: 'Erro ao salvar na pasta.' });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Salvar Caso na Pasta</DialogTitle>
          <DialogDescription>
            Selecione uma das suas pastas para adicionar o caso "{caso?.processo}".
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-3 max-h-80 overflow-y-auto">
          {loading ? (
            Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)
          ) : folders.length > 0 ? (
            folders.map((folder) => (
              <Button
                key={folder.id}
                variant="outline"
                className="w-full justify-start gap-3"
                onClick={() => handleSaveFolder(folder)}
              >
                <Folder className="w-4 h-4 text-amber-500" />
                <span className="font-medium">{folder.nome}</span>
                <span className="text-sm text-slate-500 ml-auto">
                  ({folder.casos?.length || 0} casos)
                </span>
              </Button>
            ))
          ) : (
            <p className="text-center text-slate-500">Nenhuma pasta encontrada.</p>
          )}
        </div>
        {feedback && (
          <div className={`flex items-center gap-2 text-sm p-3 rounded-lg ${
            feedback.type === 'success' ? 'bg-emerald-50 text-emerald-700' : 
            feedback.type === 'error' ? 'bg-red-50 text-red-700' :
            'bg-blue-50 text-blue-700'
          }`}>
            {feedback.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {feedback.message}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}