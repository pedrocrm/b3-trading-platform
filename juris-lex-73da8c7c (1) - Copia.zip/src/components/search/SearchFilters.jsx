import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Filter, Calendar, Building2, Tag } from "lucide-react";

export default function SearchFilters({ filters, setFilters, cases }) {
  // Extract unique values for dropdowns
  const uniqueTribunals = [...new Set(cases.map(c => c.tribunal).filter(Boolean))];
  const uniqueCategories = [...new Set(cases.map(c => c.categoria_automatica).filter(Boolean))];

  // Advanced jurimetric filters
  const confidenceLevels = [
    { value: "0.9", label: "Alta Confiança (90%+)" },
    { value: "0.7", label: "Média Confiança (70%+)" },
    { value: "0.5", label: "Baixa Confiança (50%+)" }
  ];

  return (
    <div className="space-y-4 pt-4 mt-4 border-t border-slate-200">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Tribunal Filter */}
        <div className="space-y-2">
          <Label className="flex items-center gap-1 text-sm font-medium">
            <Building2 className="w-3 h-3" />
            Tribunal
          </Label>
          <Select
            value={filters.tribunal || ""}
            onValueChange={(value) => setFilters(prev => ({ ...prev, tribunal: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Todos os tribunais" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todos os tribunais</SelectItem>
              {uniqueTribunals.slice(0, 10).map(tribunal => (
                <SelectItem key={tribunal} value={tribunal}>
                  {tribunal}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Category Filter */}
        <div className="space-y-2">
          <Label className="flex items-center gap-1 text-sm font-medium">
            <Tag className="w-3 h-3" />
            Categoria
          </Label>
          <Select
            value={filters.categoria || ""}
            onValueChange={(value) => setFilters(prev => ({ ...prev, categoria: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Todas as categorias" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todas as categorias</SelectItem>
              {uniqueCategories.slice(0, 10).map(categoria => (
                <SelectItem key={categoria} value={categoria}>
                  {categoria}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Confidence Level Filter */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Nível de Confiança IA</Label>
          <Select
            value={filters.confianca || ""}
            onValueChange={(value) => setFilters(prev => ({ ...prev, confianca: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Qualquer confiança" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Qualquer confiança</SelectItem>
              {confidenceLevels.map(level => (
                <SelectItem key={level.value} value={level.value}>
                  {level.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {/* Date Range */}
        <div className="space-y-2">
          <Label className="flex items-center gap-1 text-sm font-medium">
            <Calendar className="w-3 h-3" />
            Data Inicial
          </Label>
          <Input
            type="date"
            value={filters.dataInicio}
            onChange={(e) => setFilters(prev => ({ ...prev, dataInicio: e.target.value }))}
          />
        </div>
        
        <div className="space-y-2">
          <Label className="flex items-center gap-1 text-sm font-medium">
            <Calendar className="w-3 h-3" />
            Data Final
          </Label>
          <Input
            type="date"
            value={filters.dataFim}
            onChange={(e) => setFilters(prev => ({ ...prev, dataFim: e.target.value }))}
          />
        </div>
      </div>

      {/* Keywords Filter */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">Palavras-chave</Label>
        <Input
          placeholder="Ex: dano moral, responsabilidade civil..."
          value={filters.palavrasChave || ""}
          onChange={(e) => setFilters(prev => ({ ...prev, palavrasChave: e.target.value }))}
        />
      </div>

      {/* Active Filters Display */}
      {(filters.tribunal || filters.categoria || filters.confianca || filters.dataInicio || filters.dataFim || filters.palavrasChave) && (
        <div className="pt-3 border-t border-slate-200">
          <div className="flex flex-wrap gap-2">
            {filters.tribunal && (
              <Badge variant="secondary" className="text-xs">
                Tribunal: {filters.tribunal}
              </Badge>
            )}
            {filters.categoria && (
              <Badge variant="secondary" className="text-xs">
                Categoria: {filters.categoria}
              </Badge>
            )}
            {filters.confianca && (
              <Badge variant="secondary" className="text-xs">
                Confiança: {confidenceLevels.find(l => l.value === filters.confianca)?.label}
              </Badge>
            )}
            {(filters.dataInicio || filters.dataFim) && (
              <Badge variant="secondary" className="text-xs">
                Período: {filters.dataInicio || "..."} - {filters.dataFim || "..."}
              </Badge>
            )}
            {filters.palavrasChave && (
              <Badge variant="secondary" className="text-xs">
                Palavras: {filters.palavrasChave}
              </Badge>
            )}
          </div>
        </div>
      )}
    </div>
  );
}