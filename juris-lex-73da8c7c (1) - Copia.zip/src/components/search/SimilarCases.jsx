import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { InvokeLLM } from "@/api/integrations";
import { Brain, FileText, Calendar, Building2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function SimilarCases({ currentCase, allCases, onSelectCase }) {
  const [similarCases, setSimilarCases] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentCase && allCases.length > 0) {
      findSimilarCases();
    }
  }, [currentCase, allCases]);

  const findSimilarCases = async () => {
    setLoading(true);
    try {
      const otherCases = allCases.filter(c => c.id !== currentCase.id);
      
      const response = await InvokeLLM({
        prompt: `Analise o caso atual e encontre os 3 casos mais similares da lista fornecida.

CASO ATUAL:
Processo: ${currentCase.processo}
Tribunal: ${currentCase.tribunal}
Ementa: ${currentCase.ementa}
Categoria: ${currentCase.categoria_automatica || "Não categorizado"}

CASOS PARA COMPARAR:
${otherCases.slice(0, 20).map(caso => `
ID: ${caso.id}
Processo: ${caso.processo}
Tribunal: ${caso.tribunal}
Ementa: ${caso.ementa}
Categoria: ${caso.categoria_automatica || "Não categorizado"}
---`).join('')}

Considere:
- Similaridade jurídica (mesmo ramo do direito)
- Similaridade factual (situações parecidas)
- Mesmo tribunal ou instância
- Precedentes aplicáveis

Retorne apenas os IDs dos 3 casos mais similares, ordenados por similaridade.`,
        response_json_schema: {
          type: "object",
          properties: {
            similar_case_ids: {
              type: "array",
              items: { type: "string" }
            },
            reasoning: { type: "string" }
          }
        }
      });

      const similar = response.similar_case_ids
        .map(id => otherCases.find(c => c.id === id))
        .filter(Boolean)
        .slice(0, 3);

      setSimilarCases(similar);
    } catch (error) {
      console.error("Error finding similar cases:", error);
      setSimilarCases([]);
    } finally {
      setLoading(false);
    }
  };

  if (!currentCase) {
    return null;
  }

  return (
    <Card className="bg-white border-0 shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-slate-800 flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-600" />
          Cases Similares
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {loading ? (
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-1/4" />
              </div>
            ))}
          </div>
        ) : similarCases.length > 0 ? (
          <div className="space-y-4">
            {similarCases.map((caso) => (
              <div 
                key={caso.id} 
                className="cursor-pointer p-3 rounded-lg border border-slate-200 hover:border-purple-300 hover:bg-purple-50 transition-all duration-200"
                onClick={() => onSelectCase(caso)}
              >
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="font-semibold text-slate-800 text-sm">{caso.processo}</h4>
                  <Badge variant="secondary" className="text-xs">
                    <Building2 className="w-3 h-3 mr-1" />
                    {caso.tribunal}
                  </Badge>
                </div>
                <p className="text-slate-600 text-xs line-clamp-2 mb-2">
                  {caso.ementa}
                </p>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  {caso.categoria_automatica && (
                    <Badge variant="outline" className="text-xs">
                      {caso.categoria_automatica}
                    </Badge>
                  )}
                  {caso.data_julgamento && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {format(new Date(caso.data_julgamento), "dd/MM/yyyy", { locale: ptBR })}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <FileText className="w-8 h-8 text-slate-400 mx-auto mb-3" />
            <p className="text-slate-600 text-sm">
              Nenhum caso similar encontrado
            </p>
            <p className="text-slate-500 text-xs mt-1">
              A IA não conseguiu identificar casos relacionados
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}