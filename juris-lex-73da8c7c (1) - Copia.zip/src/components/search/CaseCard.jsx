import React from "react";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Building2, FileText, Sparkles, Tag, FolderPlus } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function CaseCard({ case: caso, onClick, isSelected, searchMode, onSaveToFolder }) {
  const handleSaveClick = (e) => {
    e.stopPropagation(); // Prevent card's onClick from firing
    onSaveToFolder();
  };
  
  return (
    <Card 
      className={`cursor-pointer transition-all duration-200 hover:shadow-lg flex flex-col ${
        isSelected 
          ? "ring-2 ring-blue-500 shadow-lg bg-blue-50" 
          : "bg-white border-0 shadow-md hover:shadow-lg"
      }`}
      onClick={onClick}
    >
      <div className="flex-grow">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="space-y-2 flex-1">
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-800 text-lg">{caso.processo}</h3>
                {searchMode === "semantic" && (
                  <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                    <Sparkles className="w-3 h-3 mr-1" />
                    IA Match
                  </Badge>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  <Building2 className="w-3 h-3 mr-1" />
                  {caso.tribunal}
                </Badge>
                {caso.data_julgamento && (
                  <Badge variant="outline" className="text-xs">
                    <Calendar className="w-3 h-3 mr-1" />
                    {format(new Date(caso.data_julgamento), "dd/MM/yyyy", { locale: ptBR })}
                  </Badge>
                )}
                {caso.categoria_automatica && (
                  <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">
                    <Tag className="w-3 h-3 mr-1" />
                    {caso.categoria_automatica}
                  </Badge>
                )}
              </div>
            </div>
            <FileText className="w-5 h-5 text-slate-400 flex-shrink-0" />
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <p className="text-slate-600 text-sm line-clamp-3 leading-relaxed mb-3">
            {caso.ementa}
          </p>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-2">
              {caso.inteiro_teor && (
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Texto completo
                </span>
              )}
              {caso.embedding && (
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  IA Ready
                </span>
              )}
            </div>
            <span>
              Adicionado em {format(new Date(caso.created_date), "dd/MM", { locale: ptBR })}
            </span>
          </div>
        </CardContent>
      </div>
      <CardFooter className="pt-4 border-t border-slate-100 bg-slate-50/50">
        <Button 
          variant="ghost" 
          className="w-full text-blue-600 hover:text-blue-700 hover:bg-blue-50"
          onClick={handleSaveClick}
        >
          <FolderPlus className="w-4 h-4 mr-2" />
          Salvar na Pasta
        </Button>
      </CardFooter>
    </Card>
  );
}