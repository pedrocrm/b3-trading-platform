
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Brain, Search, Lightbulb } from "lucide-react";

const exampleQueries = [
  {
    title: "Responsabilidade Civil",
    query: "Casos sobre danos morais por negativação indevida em órgãos de proteção ao crédito",
    icon: Lightbulb,
    color: "blue"
  },
  {
    title: "Direito Trabalhista", 
    query: "Jurisprudência sobre horas extras e intervalos não concedidos",
    icon: Brain,
    color: "emerald"
  },
  {
    title: "Direito Tributário",
    query: "Precedentes sobre imunidade tributária e não incidência de ICMS",
    icon: Search,
    color: "purple"
  }
];

export default function SemanticSearch({ onSearch, loading }) {
  const [query, setQuery] = useState("");
  const [conceptualMode, setConceptualMode] = useState(false);

  const handleSearch = (searchQuery = query) => {
    if (searchQuery.trim()) {
      onSearch(searchQuery, conceptualMode);
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Sparkles className="w-5 h-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-slate-800">
            Busca Inteligente por Contexto Jurídico
          </h3>
          <div className="ml-auto">
            <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
              Powered by Azure OpenAI
            </span>
          </div>
        </div>

        <Textarea
          placeholder="Descreva o tema jurídico, situação fática ou pergunta legal que deseja pesquisar...&#10;&#10;Exemplo: 'Preciso de casos sobre responsabilidade civil em acidentes de trânsito com danos morais e materiais'"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="min-h-[120px] text-base resize-none focus:ring-2 focus:ring-purple-500"
        />

        <div className="flex flex-wrap gap-3">
          <Button
            onClick={() => handleSearch()}
            disabled={!query.trim() || loading}
            className="bg-purple-600 hover:bg-purple-700 flex items-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Analisando...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Buscar com IA
              </>
            )}
          </Button>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="conceptual"
              checked={conceptualMode}
              onChange={(e) => setConceptualMode(e.target.checked)}
              className="rounded border-slate-300"
            />
            <label htmlFor="conceptual" className="text-sm text-slate-600 cursor-pointer">
              Busca conceitual avançada
            </label>
          </div>
        </div>

        {conceptualMode && (
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Brain className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-800">Modo Conceitual Ativado</span>
            </div>
            <p className="text-xs text-purple-700">
              A IA irá buscar cases relacionados por conceitos jurídicos, princípios e precedentes, 
              mesmo que não usem exatamente os mesmos termos.
            </p>
          </div>
        )}
      </div>

      <div className="space-y-3">
        <h4 className="text-sm font-medium text-slate-700">Exemplos de consultas:</h4>
        <div className="grid gap-3">
          {exampleQueries.map((example, index) => (
            <Card 
              key={index} 
              className="cursor-pointer hover:shadow-md transition-all duration-200 hover:border-purple-300"
              onClick={() => {
                setQuery(example.query);
                setTimeout(() => handleSearch(example.query), 100);
              }}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center bg-${example.color}-100`}>
                    <example.icon className={`w-4 h-4 text-${example.color}-600`} />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-slate-800 text-sm">{example.title}</p>
                    <p className="text-slate-600 text-xs mt-1 line-clamp-2">
                      {example.query}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Brain className="w-4 h-4 text-blue-600" />
          <span className="text-sm font-medium text-blue-800">JUIT Rimor - Busca Semântica Avançada</span>
        </div>
        <ul className="text-xs text-blue-700 space-y-1">
          <li>• <strong>Elasticsearch</strong>: Índice otimizado para português jurídico</li>
          <li>• <strong>Embeddings</strong>: Vetores pré-carregados do Azure OpenAI</li>
          <li>• <strong>OCR</strong>: Texto extraído automaticamente dos PDFs</li>
          <li>• <strong>Crawlers</strong>: Dados atualizados diariamente dos tribunais</li>
        </ul>
      </div>
    </div>
  );
}
