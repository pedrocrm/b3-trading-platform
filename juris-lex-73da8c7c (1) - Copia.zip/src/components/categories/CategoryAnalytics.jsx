import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { TrendingUp, Calendar, Award, AlertTriangle } from "lucide-react";
import { format, subDays, eachDayOfInterval } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function CategoryAnalytics({ cases, categoryStats }) {
  // Calculate monthly trends
  const getMonthlyTrends = () => {
    const last30Days = eachDayOfInterval({
      start: subDays(new Date(), 29),
      end: new Date()
    });

    return last30Days.map(date => {
      const dayStr = format(date, 'yyyy-MM-dd');
      const daysCases = cases.filter(caso => 
        caso.created_date && caso.created_date.startsWith(dayStr)
      );
      
      return {
        date: format(date, 'dd/MM', { locale: ptBR }),
        total: daysCases.length,
        direito_civil: daysCases.filter(c => c.categoria_automatica === 'Direito Civil').length,
        direito_trabalhista: daysCases.filter(c => c.categoria_automatica === 'Direito Trabalhista').length,
        direito_tributario: daysCases.filter(c => c.categoria_automatica === 'Direito Tributário').length
      };
    });
  };

  // Get tribunal distribution by category
  const getTribunalDistribution = () => {
    const distribution = {};
    
    cases.forEach(caso => {
      const categoria = caso.categoria_automatica || 'Não categorizado';
      if (!distribution[categoria]) {
        distribution[categoria] = {};
      }
      
      const tribunal = caso.tribunal || 'Não informado';
      distribution[categoria][tribunal] = (distribution[categoria][tribunal] || 0) + 1;
    });

    return distribution;
  };

  // Get insights
  const getInsights = () => {
    const insights = [];
    
    if (categoryStats.length > 0) {
      const topCategory = categoryStats[0];
      insights.push({
        type: 'success',
        icon: Award,
        title: 'Categoria Dominante',
        description: `${topCategory.name} representa ${((topCategory.value / cases.length) * 100).toFixed(1)}% dos casos`
      });
    }

    const uncategorized = cases.filter(c => !c.categoria_automatica).length;
    if (uncategorized > 0) {
      insights.push({
        type: 'warning',
        icon: AlertTriangle,
        title: 'Casos Pendentes',
        description: `${uncategorized} casos ainda precisam ser categorizados automaticamente`
      });
    }

    const recentCases = cases.filter(c => {
      const caseDate = new Date(c.created_date);
      const weekAgo = subDays(new Date(), 7);
      return caseDate >= weekAgo;
    }).length;

    if (recentCases > 0) {
      insights.push({
        type: 'info',
        icon: TrendingUp,
        title: 'Atividade Recente',
        description: `${recentCases} novos casos adicionados nos últimos 7 dias`
      });
    }

    return insights;
  };

  const monthlyTrends = getMonthlyTrends();
  const tribunalDistribution = getTribunalDistribution();
  const insights = getInsights();

  return (
    <div className="space-y-6">
      {/* Insights Cards */}
      <div className="grid md:grid-cols-3 gap-4">
        {insights.map((insight, index) => (
          <Card key={index} className={`border-l-4 ${
            insight.type === 'success' ? 'border-l-emerald-500 bg-emerald-50' :
            insight.type === 'warning' ? 'border-l-amber-500 bg-amber-50' :
            'border-l-blue-500 bg-blue-50'
          }`}>
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <insight.icon className={`w-5 h-5 mt-0.5 ${
                  insight.type === 'success' ? 'text-emerald-600' :
                  insight.type === 'warning' ? 'text-amber-600' :
                  'text-blue-600'
                }`} />
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm">{insight.title}</h4>
                  <p className="text-slate-600 text-xs mt-1">{insight.description}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Monthly Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            Tendência dos Últimos 30 Dias
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyTrends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="total" stroke="#3B82F6" strokeWidth={2} name="Total" />
              <Line type="monotone" dataKey="direito_civil" stroke="#10B981" strokeWidth={2} name="Direito Civil" />
              <Line type="monotone" dataKey="direito_trabalhista" stroke="#F59E0B" strokeWidth={2} name="Direito Trabalhista" />
              <Line type="monotone" dataKey="direito_tributario" stroke="#EF4444" strokeWidth={2} name="Direito Tributário" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Category Details */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Detalhes por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {categoryStats.slice(0, 10).map((stat, index) => (
                <div key={stat.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full`} 
                         style={{backgroundColor: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4', '#F97316'][index % 7]}} />
                    <span className="font-medium text-slate-800">{stat.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{stat.value} casos</Badge>
                    <span className="text-xs text-slate-500">
                      {((stat.value / cases.length) * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Distribuição por Tribunal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {Object.entries(tribunalDistribution).map(([category, tribunals]) => (
                <div key={category} className="space-y-2">
                  <h4 className="font-medium text-slate-800 text-sm">{category}</h4>
                  <div className="pl-4 space-y-1">
                    {Object.entries(tribunals).map(([tribunal, count]) => (
                      <div key={tribunal} className="flex justify-between items-center text-xs">
                        <span className="text-slate-600">{tribunal}</span>
                        <Badge variant="outline" className="text-xs">{count}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}