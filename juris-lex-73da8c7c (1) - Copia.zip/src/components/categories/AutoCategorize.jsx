
import React, { useState } from "react";
import { InvokeLLM } from "@/api/integrations";
import { Jurisprudencia } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Brain, RefreshCw, Settings, Zap, Target } from "lucide-react";

export default function AutoCategorize({ cases, onRecategorize, uncategorizedCount }) {
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [customCategories, setCustomCategories] = useState("");
  const [processingMode, setProcessingMode] = useState("standard");

  const standardCategories = [
    "Direito Civil", "Direito Penal", "Direito Trabalhista", 
    "Direito Tributário", "Direito Administrativo", "Direito Constitucional",
    "Direito Empresarial", "Direito Consumidor", "Direito Previdenciário",
    "Direito Ambiental", "Direito da Família", "Direito Imobiliário"
  ];

  const runCategorization = async (mode = "uncategorized") => {
    const casesToProcess = mode === "all" 
      ? cases 
      : cases.filter(caso => !caso.categoria_automatica);

    if (casesToProcess.length === 0) return;

    setProcessing(true);
    setProgress(0);

    const categories = customCategories 
      ? customCategories.split('\n').map(c => c.trim()).filter(Boolean)
      : standardCategories;

    const batchSize = 5;
    const totalBatches = Math.ceil(casesToProcess.length / batchSize);

    for (let i = 0; i < totalBatches; i++) {
      const batch = casesToProcess.slice(i * batchSize, (i + 1) * batchSize);
      
      try {
        const response = await InvokeLLM({
          prompt: `Como um especialista em jurimetria, analise os seguintes casos e classifique cada um com um "classificador de assunto" detalhado (ex: "TRF3 – Tributário – ICMS").

CASOS PARA ANÁLISE:
${batch.map((caso, index) => `
CASO ${index + 1} (ID: ${caso.id}):
Processo: ${caso.processo}
Tribunal: ${caso.tribunal}
Ementa: ${caso.ementa?.substring(0, 500)}...
---`).join('\n')}

CATEGORIAS BASE (use como guia para criar classificadores específicos):
${categories.join(', ')}

Para cada caso, determine:
1.  **classifier**: O classificador de assunto preciso (ex: "TJSP – Consumidor – Negativação Indevida").
2.  **category**: A categoria principal (ex: "Direito do Consumidor").
3.  **confidence**: Nível de confiança (0-100).
4.  **keywords**: Palavras-chave que justificam a classificação.
5.  **reasoning**: Justificativa breve para o classificador escolhido.

Seja extremamente preciso, combinando tribunal, área do direito e o tema central do caso.`,
          response_json_schema: {
            type: "object",
            properties: {
              categorizations: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    case_id: { type: "string" },
                    classifier: { type: "string" },
                    category: { type: "string" },
                    confidence: { type: "number" },
                    keywords: { 
                      type: "array",
                      items: { type: "string" }
                    },
                    reasoning: { type: "string" }
                  }
                }
              }
            }
          }
        });

        // Update cases with detailed categorization
        for (const cat of response.categorizations) {
          try {
            await Jurisprudencia.update(cat.case_id, {
              categoria_automatica: cat.category,
              subcategoria: cat.classifier, // Usando o campo subcategoria para o classificador detalhado
              confianca_categoria: cat.confidence / 100,
              palavras_chave: cat.keywords,
              justificativa_categoria: cat.reasoning
            });
          } catch (updateError) {
            console.error(`Error updating case ${cat.case_id}:`, updateError);
          }
        }

        setProgress(((i + 1) / totalBatches) * 100);
        
      } catch (error) {
        console.error(`Error categorizing batch ${i + 1}:`, error);
      }
    }

    setProcessing(false);
    setProgress(0);
    onRecategorize();
  };

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-600" />
              Categorização Automática
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Button
                onClick={() => runCategorization("uncategorized")}
                disabled={processing || uncategorizedCount === 0}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {processing ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Categorizando...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Categorizar Pendentes ({uncategorizedCount})
                  </>
                )}
              </Button>

              <Button
                onClick={() => runCategorization("all")}
                disabled={processing}
                variant="outline"
                className="w-full"
              >
                <Target className="w-4 h-4 mr-2" />
                Recategorizar Todos ({cases.length})
              </Button>
            </div>

            {processing && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progresso</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} />
                <p className="text-xs text-slate-600">
                  IA analisando conteúdo jurídico e aplicando classificação especializada...
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-blue-600" />
              Configuração de Categorias
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Categorias Padrão</Label>
              <div className="flex flex-wrap gap-1">
                {standardCategories.slice(0, 6).map(category => (
                  <Badge key={category} variant="secondary" className="text-xs">
                    {category}
                  </Badge>
                ))}
                <Badge variant="outline" className="text-xs">
                  +{standardCategories.length - 6} mais...
                </Badge>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="custom">Categorias Customizadas (opcional)</Label>
              <Textarea
                id="custom"
                placeholder="Digite uma categoria por linha:&#10;Direito Digital&#10;Direito Esportivo&#10;Direito LGPD"
                value={customCategories}
                onChange={(e) => setCustomCategories(e.target.value)}
                className="h-24 text-sm"
              />
              <p className="text-xs text-slate-500">
                Se especificadas, serão usadas no lugar das categorias padrão
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Como Funciona a Categorização IA</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <Brain className="w-4 h-4 text-blue-600" />
              </div>
              <h4 className="font-medium">1. Análise Jurídica</h4>
              <p className="text-sm text-slate-600">
                IA especializada analisa ementa, inteiro teor e contexto jurídico
              </p>
            </div>
            <div className="space-y-2">
              <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                <Target className="w-4 h-4 text-emerald-600" />
              </div>
              <h4 className="font-medium">2. Classificação</h4>
              <p className="text-sm text-slate-600">
                Determina categoria principal, subcategoria e nível de confiança
              </p>
            </div>
            <div className="space-y-2">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-purple-600" />
              </div>
              <h4 className="font-medium">3. Enriquecimento</h4>
              <p className="text-sm text-slate-600">
                Adiciona palavras-chave e justificativa para cada classificação
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
