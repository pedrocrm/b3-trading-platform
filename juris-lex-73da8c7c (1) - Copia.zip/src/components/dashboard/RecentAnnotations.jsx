import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageSquare, ArrowRight, User } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Anotacao } from "@/api/entities";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function RecentAnnotations({ userId }) {
  const [annotations, setAnnotations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      loadAnnotations();
    }
  }, [userId]);

  const loadAnnotations = async () => {
    try {
      const data = await Anotacao.filter({ user_id: userId }, "-created_date", 5);
      setAnnotations(data);
    } catch (error) {
      console.error("Error loading annotations:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="bg-white border-0 shadow-lg">
      <CardHeader className="border-b border-slate-100 flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2 text-slate-800">
          <MessageSquare className="w-5 h-5 text-emerald-600" />
          Anotações Recentes
        </CardTitle>
        <Link to={createPageUrl("Search")}>
          <Button variant="ghost" size="sm" className="text-emerald-600 hover:text-emerald-700">
            Ver todas
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent className="p-6">
        {loading ? (
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-3/4" />
                <Skeleton className="h-3 w-1/4" />
              </div>
            ))}
          </div>
        ) : annotations.length > 0 ? (
          <div className="space-y-4">
            {annotations.map((annotation) => (
              <div key={annotation.id} className="border-l-4 border-emerald-500 pl-4 hover:bg-slate-50 p-2 rounded-r-lg transition-colors">
                <p className="text-slate-700 text-sm mb-2 line-clamp-2">
                  {annotation.texto}
                </p>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <User className="w-3 h-3" />
                  <span>{format(new Date(annotation.created_date), "dd/MM/yyyy HH:mm", { locale: ptBR })}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <MessageSquare className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600 mb-2">Nenhuma anotação ainda</p>
            <p className="text-slate-500 text-sm">
              Suas anotações nos casos aparecerão aqui
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}