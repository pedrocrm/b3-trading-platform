
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

const colorClasses = {
  blue: "from-blue-500 to-blue-600 text-blue-600",
  amber: "from-amber-500 to-amber-600 text-amber-600", 
  emerald: "from-emerald-500 to-emerald-600 text-emerald-600",
  purple: "from-purple-500 to-purple-600 text-purple-600"
};

export default function StatsCard({ title, value, icon: Icon, color, trend, onClick }) {
  return (
    <Card 
      className={`bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 ${
        onClick ? 'cursor-pointer' : ''
      }`}
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-600">{title}</p>
            <p className="text-2xl font-bold text-slate-800">{value}</p>
          </div>
          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colorClasses[color]} bg-opacity-10 flex items-center justify-center`}>
            <Icon className={`w-6 h-6 ${colorClasses[color].split(' ')[2]}`} />
          </div>
        </div>
        {trend && (
          <div className="flex items-center gap-1 mt-4 text-xs">
            <TrendingUp className="w-3 h-3 text-emerald-500" />
            <span className="text-slate-600">{trend}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
