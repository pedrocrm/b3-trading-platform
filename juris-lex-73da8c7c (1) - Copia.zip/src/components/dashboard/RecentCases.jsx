import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Calendar, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Skeleton } from "@/components/ui/skeleton";

export default function RecentCases({ cases, loading }) {
  return (
    <Card className="bg-white border-0 shadow-lg">
      <CardHeader className="border-b border-slate-100 flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2 text-slate-800">
          <FileText className="w-5 h-5 text-blue-600" />
          Casos Recentes
        </CardTitle>
        <Link to={createPageUrl("Search")}>
          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
            Ver todos
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent className="p-6">
        {loading ? (
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-1/4" />
              </div>
            ))}
          </div>
        ) : cases.length > 0 ? (
          <div className="space-y-4">
            {cases.map((caso) => (
              <div key={caso.id} className="border-l-4 border-blue-500 pl-4 hover:bg-slate-50 p-2 rounded-r-lg transition-colors cursor-pointer">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-slate-800 text-sm">{caso.processo}</h4>
                  <Badge variant="secondary" className="text-xs">
                    {caso.tribunal}
                  </Badge>
                </div>
                <p className="text-slate-600 text-sm line-clamp-2 mb-2">
                  {caso.ementa?.substring(0, 120)}...
                </p>
                {caso.data_julgamento && (
                  <div className="flex items-center gap-1 text-xs text-slate-500">
                    <Calendar className="w-3 h-3" />
                    {format(new Date(caso.data_julgamento), "dd/MM/yyyy", { locale: ptBR })}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600 mb-2">Nenhum caso encontrado</p>
            <p className="text-slate-500 text-sm">
              Comece fazendo uma pesquisa jurisprudencial
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}