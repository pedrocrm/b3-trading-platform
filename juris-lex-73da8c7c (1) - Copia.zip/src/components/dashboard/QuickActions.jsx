import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, FolderPlus, BookOpen, FileText } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const quickActions = [
  {
    title: "Nova Pesquisa",
    description: "Buscar jurisprudência por termos ou filtros",
    icon: Search,
    href: createPageUrl("Search"),
    color: "blue"
  },
  {
    title: "Criar Pasta",
    description: "Organizar casos em pastas temáticas",
    icon: FolderPlus,
    href: createPageUrl("Folders"),
    color: "amber"
  },
  {
    title: "Explorar Casos",
    description: "Ver todos os casos disponíveis",
    icon: BookOpen,
    href: createPageUrl("Search"),
    color: "emerald"
  }
];

const colorClasses = {
  blue: "text-blue-600 bg-blue-50 hover:bg-blue-100",
  amber: "text-amber-600 bg-amber-50 hover:bg-amber-100",
  emerald: "text-emerald-600 bg-emerald-50 hover:bg-emerald-100"
};

export default function QuickActions() {
  return (
    <Card className="bg-white border-0 shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="flex items-center gap-2 text-slate-800">
          <FileText className="w-5 h-5 text-purple-600" />
          Ações Rápidas
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {quickActions.map((action) => (
            <Link key={action.title} to={action.href}>
              <Button
                variant="ghost" 
                className={`w-full justify-start h-auto p-4 ${colorClasses[action.color]} transition-all duration-200`}
              >
                <div className="flex items-center gap-3">
                  <action.icon className="w-5 h-5" />
                  <div className="text-left">
                    <div className="font-medium">{action.title}</div>
                    <div className="text-xs opacity-70">{action.description}</div>
                  </div>
                </div>
              </Button>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}