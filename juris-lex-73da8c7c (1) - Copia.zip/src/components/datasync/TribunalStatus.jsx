import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { verificarStatusTribunais } from "@/api/functions";
import { RefreshCw, Server, Wifi, WifiOff } from "lucide-react";

export default function TribunalStatus() {
  const [status, setStatus] = useState({});
  const [loading, setLoading] = useState(true);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const { data } = await verificarStatusTribunais();
      if (data?.sucesso) {
        setStatus(data.data);
      }
    } catch (error) {
      console.error("Erro ao verificar status dos tribunais:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Server className="w-5 h-5 text-blue-600" />
          Status dos Tribunais (DataJud)
        </CardTitle>
        <Button variant="ghost" size="sm" onClick={fetchStatus} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(15).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(status).map(([codigo, info]) => (
              <div key={codigo} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <span className="text-sm font-medium text-slate-700">{info.nome}</span>
                <Badge className={info.status === 'online' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}>
                  {info.status === 'online' ? 
                    <Wifi className="w-3 h-3 mr-1.5" /> : 
                    <WifiOff className="w-3 h-3 mr-1.5" />
                  }
                  {info.status === 'online' ? 'Online' : 'Offline'}
                </Badge>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}