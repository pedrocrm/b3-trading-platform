import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Share2, X, Plus, Mail } from "lucide-react";

export default function ShareFolderDialog({ open, onOpenChange, folder, onShare }) {
  const [emailInput, setEmailInput] = useState("");
  const [emailsToAdd, setEmailsToAdd] = useState([]);

  const handleAddEmail = () => {
    const email = emailInput.trim().toLowerCase();
    if (email && email.includes("@") && !emailsToAdd.includes(email)) {
      setEmailsToAdd(prev => [...prev, email]);
      setEmailInput("");
    }
  };

  const handleRemoveEmail = (emailToRemove) => {
    setEmailsToAdd(prev => prev.filter(email => email !== emailToRemove));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (emailsToAdd.length > 0) {
      onShare(emailsToAdd);
      setEmailsToAdd([]);
      setEmailInput("");
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setEmailsToAdd([]);
    setEmailInput("");
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddEmail();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-blue-600" />
            Compartilhar: {folder?.nome}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {folder?.shared_users?.length > 0 && (
            <div>
              <Label className="text-sm text-slate-600">Já compartilhada com:</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {folder.shared_users.map((email) => (
                  <Badge key={email} variant="secondary" className="text-xs">
                    <Mail className="w-3 h-3 mr-1" />
                    {email}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Adicionar usuários (por email)</Label>
              <div className="flex gap-2">
                <Input
                  id="email"
                  type="email"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="usuario@exemplo.com"
                />
                <Button 
                  type="button" 
                  onClick={handleAddEmail}
                  size="icon"
                  variant="outline"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {emailsToAdd.length > 0 && (
              <div>
                <Label className="text-sm text-slate-600">Usuários para adicionar:</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {emailsToAdd.map((email) => (
                    <Badge key={email} variant="outline" className="text-xs">
                      {email}
                      <button
                        type="button"
                        onClick={() => handleRemoveEmail(email)}
                        className="ml-1 hover:text-red-500"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={emailsToAdd.length === 0}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Compartilhar
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}