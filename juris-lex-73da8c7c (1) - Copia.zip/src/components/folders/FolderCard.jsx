import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FolderOpen, Share2, User, Users, FileText } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function FolderCard({ folder, isOwner, onShare }) {
  return (
    <Card className="bg-white border-0 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 h-full flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-500 rounded-lg flex items-center justify-center">
              <FolderOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-800">{folder.nome}</h3>
              <p className="text-xs text-slate-500">
                Criada em {format(new Date(folder.created_date), "dd/MM/yyyy", { locale: ptBR })}
              </p>
            </div>
          </div>
          {isOwner && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onShare}
              className="text-slate-400 hover:text-slate-600"
            >
              <Share2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-0 flex-grow">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isOwner ? (
              <Badge variant="secondary" className="text-xs">
                <User className="w-3 h-3 mr-1" />
                Proprietário
              </Badge>
            ) : (
              <Badge variant="secondary" className="text-xs bg-emerald-100 text-emerald-800">
                <Users className="w-3 h-3 mr-1" />
                Compartilhada
              </Badge>
            )}
            <Badge variant="outline" className="text-xs">
              <FileText className="w-3 h-3 mr-1" />
              {folder.casos?.length || 0} casos
            </Badge>
          </div>
          <div className="text-xs text-slate-500">
            {folder.shared_users?.length || 0} compartilhamentos
          </div>
        </div>
      </CardContent>
    </Card>
  );
}