import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FolderPlus } from "lucide-react";

export default function CreateFolderDialog({ open, onOpenChange, onCreateFolder }) {
  const [formData, setFormData] = useState({
    nome: "",
    descricao: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.nome.trim()) {
      onCreateFolder(formData);
      setFormData({ nome: "", descricao: "" });
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setFormData({ nome: "", descricao: "" });
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderPlus className="w-5 h-5 text-amber-600" />
            Criar Nova Pasta
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nome">Nome da Pasta</Label>
            <Input
              id="nome"
              value={formData.nome}
              onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
              placeholder="Ex: Direito Civil, Trabalhista..."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="descricao">Descrição (opcional)</Label>
            <Textarea
              id="descricao"
              value={formData.descricao}
              onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
              placeholder="Descreva o conteúdo desta pasta..."
              className="h-20"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-amber-600 hover:bg-amber-700">
              Criar Pasta
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}