import { base44 } from './base44Client';


export const Jurisprudencia = base44.entities.Jurisprudencia;

export const Pasta = base44.entities.Pasta;

export const Anotacao = base44.entities.Anotacao;

export const ProcessoDetalhado = base44.entities.ProcessoDetalhado;

export const DocumentoProcessado = base44.entities.DocumentoProcessado;



// auth sdk:
export const User = base44.auth;