import { base44 } from './base44Client';


export const dataIngestionPipeline = base44.functions.dataIngestionPipeline;

export const stjCrawler = base44.functions.stjCrawler;

export const consultarProcesso = base44.functions.consultarProcesso;

export const consultarPorDocumento = base44.functions.consultarPorDocumento;

export const listarTribunais = base44.functions.listarTribunais;

export const verificarStatusTribunais = base44.functions.verificarStatusTribunais;

export const metricas = base44.functions.metricas;

export const healthCheck = base44.functions.healthCheck;

export const buscarJurisprudencia = base44.functions.buscarJurisprudencia;

export const processarDocumento = base44.functions.processarDocumento;

export const askOpenAI = base44.functions.askOpenAI;

