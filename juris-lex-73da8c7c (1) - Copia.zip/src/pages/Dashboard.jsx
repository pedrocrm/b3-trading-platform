
import React, { useState, useEffect } from "react";
import { Jurisprudencia, Pasta, Anotacao, User } from "@/api/entities";
import { SendEmail, InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Search,
  FolderOpen,
  FileText,
  MessageSquare,
  TrendingUp,
  Calendar,
  Scale,
  ArrowRight,
  DatabaseZap,
  Info
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

import StatsCard from "../components/dashboard/StatsCard";
import RecentCases from "../components/dashboard/RecentCases";
import RecentAnnotations from "../components/dashboard/RecentAnnotations";
import QuickActions from "../components/dashboard/QuickActions";

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalCases: 0,
    totalFolders: 0,
    totalAnnotations: 0,
    recentCases: []
  });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
    checkForDailyDigest();
  }, []);

  const checkForDailyDigest = async () => {
    try {
      const currentUser = await User.me();
      const today = new Date().toISOString().split('T')[0];
      const lastDigest = localStorage.getItem('lastDigestDate');

      if (lastDigest !== today && currentUser.preferences?.dailyDigest !== false) {
        await generateDailyDigest(currentUser);
        localStorage.setItem('lastDigestDate', today);
      }
    } catch (error) {
      console.error("Error checking daily digest:", error);
    }
  };

  const generateDailyDigest = async (currentUser) => {
    try {
      const today = new Date();
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);

      const recentCases = await Jurisprudencia.filter({
        data_julgamento: yesterday.toISOString().split('T')[0]
      });

      if (recentCases.length > 0) {
        const digestContent = await InvokeLLM({
          prompt: `Crie um resumo executivo dos novos casos jurisprudenciais de ontem para um profissional jurídico:

${recentCases.map(caso => `
• ${caso.processo} - ${caso.tribunal}
  Ementa: ${caso.ementa}
  Categoria: ${caso.categoria_automatica || "Não categorizado"}
`).join('\n')}

O resumo deve:
1. Destacar os casos mais relevantes
2. Agrupar por área do direito
3. Mencionar precedentes importantes
4. Ter tom profissional e conciso
5. Incluir estatísticas básicas

Formato: HTML para email, com estrutura clara e links internos.`,
          response_json_schema: {
            type: "object",
            properties: {
              subject: { type: "string" },
              html_content: { type: "string" },
              summary: { type: "string" }
            }
          }
        });

        await SendEmail({
          to: currentUser.email,
          subject: digestContent.subject,
          body: digestContent.html_content,
          from_name: "LexSearch Daily"
        });
      }
    } catch (error) {
      console.error("Error generating daily digest:", error);
    }
  };

  const loadDashboardData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      // Leveraging JUIT Rimor's REST APIs for data fetching
      const [cases, folders, annotations] = await Promise.all([
        Jurisprudencia.list("-created_date", 5), // Portal de Dados + APIs
        Pasta.filter({ owner_user: currentUser.email }), // Workspace Colaborativo
        Anotacao.filter({ user_id: currentUser.email }, "-created_date", 5) // Objetos de Conhecimento
      ]);

      setStats({
        totalCases: cases.length,
        totalFolders: folders.length,
        totalAnnotations: annotations.length,
        recentCases: cases
      });
    } catch (error) {
      console.error("Error loading dashboard:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-900 to-blue-800 rounded-lg flex items-center justify-center">
              <Scale className="w-4 h-4 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-800">Dashboard</h1>
          </div>
          <p className="text-slate-600">
            Bem-vindo de volta! Acompanhe suas pesquisas jurisprudenciais e anotações.
          </p>
          {/* JUIT Rimor Integration Status */}
          <div className="mt-4 flex flex-wrap gap-2 text-xs">
            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full">✓ Portal de Dados Ativo</span>
            <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">✓ IA Generativa Azure OpenAI</span>
            <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-full">✓ Elasticsearch Gerenciado</span>
            <span className="bg-amber-100 text-amber-800 px-2 py-1 rounded-full">✓ Workspace Colaborativo</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total de Casos"
            value={stats.totalCases}
            icon={FileText}
            color="blue"
            trend="+12% este mês"
          />
          <StatsCard
            title="Minhas Pastas"
            value={stats.totalFolders}
            icon={FolderOpen}
            color="amber"
            trend="3 novas pastas"
          />
          <StatsCard
            title="Anotações"
            value={stats.totalAnnotations}
            icon={MessageSquare}
            color="emerald"
            trend="Última hoje"
          />
          <StatsCard
            title="Pesquisas Hoje"
            value={0}
            icon={Search}
            color="purple"
            trend="Realizar pesquisa"
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <RecentCases cases={stats.recentCases} loading={loading} />
          </div>
          <div>
            <QuickActions />
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <RecentAnnotations userId={user?.email} />
          <Card className="bg-white border-0 shadow-lg">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="flex items-center gap-2 text-slate-800">
                <TrendingUp className="w-5 h-5 text-amber-600" />
                Atividade Recente
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3 text-sm">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-slate-700">Sistema iniciado</p>
                    <p className="text-slate-500 text-xs">
                      {format(new Date(), "PPpp", { locale: ptBR })}
                    </p>
                  </div>
                </div>
                <div className="text-center py-8">
                  <Calendar className="w-8 h-8 text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-500 text-sm">
                    Suas atividades aparecerão aqui conforme você usar o sistema
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
