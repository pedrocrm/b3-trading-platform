import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Palette, Upload, Eye, Save, Crown } from "lucide-react";
import { UploadFile } from "@/api/integrations";

export default function BrandCustomization() {
  const [user, setUser] = useState(null);
  const [brandConfig, setBrandConfig] = useState({
    name: "",
    logo_url: "",
    brand_color_primary: "#0c2f57",
    brand_color_secondary: "#fbbF24",
    custom_domain: "",
    email_signature: ""
  });
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  useEffect(() => {
    loadUserAndBrand();
  }, []);

  const loadUserAndBrand = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      if (currentUser.tenant) {
        setBrandConfig(prev => ({
          ...prev,
          ...currentUser.tenant
        }));
      }
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setBrandConfig(prev => ({ ...prev, logo_url: file_url }));
    } catch (error) {
      console.error("Error uploading logo:", error);
      alert("Erro ao fazer upload do logo");
    } finally {
      setUploading(false);
    }
  };

  const saveBrandConfig = async () => {
    if (!user) return;

    setLoading(true);
    try {
      await User.updateMyUserData({
        tenant: brandConfig
      });
      
      alert("Configuração de marca salva com sucesso!");
      // Reload page to apply new branding
      window.location.reload();
    } catch (error) {
      console.error("Error saving brand config:", error);
      alert("Erro ao salvar configuração");
    } finally {
      setLoading(false);
    }
  };

  const presetColors = [
    { name: "Azul Jurídico", primary: "#0c2f57", secondary: "#fbbF24" },
    { name: "Verde Corporativo", primary: "#065f46", secondary: "#10b981" },
    { name: "Roxo Moderno", primary: "#581c87", secondary: "#a855f7" },
    { name: "Vermelho Elegante", primary: "#991b1b", secondary: "#ef4444" },
    { name: "Cinza Profissional", primary: "#374151", secondary: "#6b7280" }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Marca Branca</h1>
            <p className="text-slate-600">
              Personalize a aparência da plataforma com sua identidade visual
            </p>
          </div>
          <Badge className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
            <Crown className="w-3 h-3 mr-1" />
            Enterprise
          </Badge>
        </div>

        <Tabs defaultValue="visual" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="visual">Identidade Visual</TabsTrigger>
            <TabsTrigger value="domain">Domínio & URLs</TabsTrigger>
            <TabsTrigger value="preview">Preview</TabsTrigger>
          </TabsList>

          <TabsContent value="visual" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="w-5 h-5 text-blue-600" />
                    Logo da Empresa
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Nome da Empresa</Label>
                    <Input
                      value={brandConfig.name}
                      onChange={(e) => setBrandConfig(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Sua Empresa Jurídica"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Logo (PNG/SVG recomendado)</Label>
                    <div className="flex items-center gap-4">
                      {brandConfig.logo_url && (
                        <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center">
                          <img 
                            src={brandConfig.logo_url} 
                            alt="Logo" 
                            className="max-w-full max-h-full object-contain"
                          />
                        </div>
                      )}
                      <div>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoUpload}
                          disabled={uploading}
                        />
                        {uploading && <p className="text-sm text-blue-600 mt-1">Fazendo upload...</p>}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="w-5 h-5 text-purple-600" />
                    Paleta de Cores
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Cor Primária</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={brandConfig.brand_color_primary}
                        onChange={(e) => setBrandConfig(prev => ({ ...prev, brand_color_primary: e.target.value }))}
                        className="w-16 h-10"
                      />
                      <Input
                        value={brandConfig.brand_color_primary}
                        onChange={(e) => setBrandConfig(prev => ({ ...prev, brand_color_primary: e.target.value }))}
                        placeholder="#0c2f57"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Cor Secundária</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={brandConfig.brand_color_secondary}
                        onChange={(e) => setBrandConfig(prev => ({ ...prev, brand_color_secondary: e.target.value }))}
                        className="w-16 h-10"
                      />
                      <Input
                        value={brandConfig.brand_color_secondary}
                        onChange={(e) => setBrandConfig(prev => ({ ...prev, brand_color_secondary: e.target.value }))}
                        placeholder="#fbbF24"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Paletas Pré-definidas</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {presetColors.map((preset) => (
                        <Button
                          key={preset.name}
                          variant="outline"
                          size="sm"
                          onClick={() => setBrandConfig(prev => ({
                            ...prev,
                            brand_color_primary: preset.primary,
                            brand_color_secondary: preset.secondary
                          }))}
                          className="justify-start gap-2"
                        >
                          <div className="flex gap-1">
                            <div 
                              className="w-3 h-3 rounded-full" 
                              style={{ backgroundColor: preset.primary }}
                            ></div>
                            <div 
                              className="w-3 h-3 rounded-full" 
                              style={{ backgroundColor: preset.secondary }}
                            ></div>
                          </div>
                          <span className="text-xs">{preset.name}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="domain">
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Domínio</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Domínio Personalizado</Label>
                  <Input
                    value={brandConfig.custom_domain}
                    onChange={(e) => setBrandConfig(prev => ({ ...prev, custom_domain: e.target.value }))}
                    placeholder="pesquisa.seuescritorio.com.br"
                  />
                  <p className="text-sm text-slate-500">
                    Configure um CNAME no seu DNS apontando para nossa plataforma
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Assinatura de Email</Label>
                  <Input
                    value={brandConfig.email_signature}
                    onChange={(e) => setBrandConfig(prev => ({ ...prev, email_signature: e.target.value }))}
                    placeholder="Equipe Jurídica - Seu Escritório"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preview">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5 text-emerald-600" />
                  Preview da Marca
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  className="border-2 border-dashed border-slate-300 rounded-lg p-8"
                  style={{
                    background: `linear-gradient(135deg, ${brandConfig.brand_color_primary}10, ${brandConfig.brand_color_secondary}10)`
                  }}
                >
                  <div className="flex items-center gap-4 mb-6">
                    {brandConfig.logo_url ? (
                      <img src={brandConfig.logo_url} alt="Logo" className="w-12 h-12 object-contain" />
                    ) : (
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: brandConfig.brand_color_primary }}
                      >
                        <span className="text-white font-bold">
                          {brandConfig.name ? brandConfig.name[0] : 'L'}
                        </span>
                      </div>
                    )}
                    <div>
                      <h3 className="font-bold text-xl" style={{ color: brandConfig.brand_color_primary }}>
                        {brandConfig.name || "Sua Empresa Jurídica"}
                      </h3>
                      <p className="text-slate-600">Pesquisa Jurisprudencial</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <Button 
                      style={{ backgroundColor: brandConfig.brand_color_primary }}
                      className="text-white"
                    >
                      Botão Primário
                    </Button>
                    <Button 
                      variant="outline"
                      style={{ 
                        borderColor: brandConfig.brand_color_secondary,
                        color: brandConfig.brand_color_secondary 
                      }}
                    >
                      Botão Secundário
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-3 mt-8">
          <Button variant="outline">
            Cancelar
          </Button>
          <Button 
            onClick={saveBrandConfig}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Salvar Configuração
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}