import React, { useState, useEffect } from "react";
import { Jurisprudencia } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Brain, 
  Tag, 
  BarChart3, 
  RefreshCw,
  FileText,
  Sparkles,
  TrendingUp,
  Filter,
  Settings,
  Zap,
  Target
} from "lucide-react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4', '#F97316'];

export default function CaseCategories() {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [categorizing, setCategorizing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [categoryStats, setCategoryStats] = useState([]);
  const [uncategorizedCount, setUncategorizedCount] = useState(0);
  const [customCategories, setCustomCategories] = useState("");

  useEffect(() => {
    loadCases();
  }, []);

  useEffect(() => {
    calculateStats();
  }, [cases]);

  const loadCases = async () => {
    setLoading(true);
    try {
      const data = await Jurisprudencia.list("-created_date", 500);
      setCases(data);
    } catch (error) {
      console.error("Error loading cases:", error);
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = () => {
    const categoryCounts = {};
    let uncategorized = 0;

    cases.forEach(caso => {
      if (caso.categoria_automatica) {
        categoryCounts[caso.categoria_automatica] = (categoryCounts[caso.categoria_automatica] || 0) + 1;
      } else {
        uncategorized++;
      }
    });

    const stats = Object.entries(categoryCounts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);

    setCategoryStats(stats);
    setUncategorizedCount(uncategorized);
  };

  const categorizeAllCases = async () => {
    const uncategorizedCases = cases.filter(caso => !caso.categoria_automatica);
    if (uncategorizedCases.length === 0) return;

    setCategorizing(true);
    setProgress(0);

    const categories = customCategories 
      ? customCategories.split('\n').map(c => c.trim()).filter(Boolean)
      : [
          "Direito Civil", "Direito Penal", "Direito Trabalhista", 
          "Direito Tributário", "Direito Administrativo", "Direito Constitucional",
          "Direito Empresarial", "Direito Consumidor", "Direito Previdenciário",
          "Direito Ambiental", "Direito da Família", "Direito Imobiliário"
        ];

    const batchSize = 5;
    const totalBatches = Math.ceil(uncategorizedCases.length / batchSize);

    for (let i = 0; i < totalBatches; i++) {
      const batch = uncategorizedCases.slice(i * batchSize, (i + 1) * batchSize);
      
      try {
        const response = await InvokeLLM({
          prompt: `Como um especialista em jurimetria, analise os seguintes casos e classifique cada um com um "classificador de assunto" detalhado (ex: "TRF3 – Tributário – ICMS").

CASOS PARA ANÁLISE:
${batch.map((caso, index) => `
CASO ${index + 1} (ID: ${caso.id}):
Processo: ${caso.processo}
Tribunal: ${caso.tribunal}
Ementa: ${caso.ementa?.substring(0, 500)}...
---`).join('\n')}

CATEGORIAS BASE (use como guia para criar classificadores específicos):
${categories.join(', ')}

Para cada caso, determine:
1. **classifier**: O classificador de assunto preciso (ex: "TJSP – Consumidor – Negativação Indevida").
2. **category**: A categoria principal (ex: "Direito do Consumidor").
3. **confidence**: Nível de confiança (0-100).
4. **keywords**: Palavras-chave que justificam a classificação.
5. **reasoning**: Justificativa breve para o classificador escolhido.

Seja extremamente preciso, combinando tribunal, área do direito e o tema central do caso.`,
          response_json_schema: {
            type: "object",
            properties: {
              categorizations: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    case_id: { type: "string" },
                    classifier: { type: "string" },
                    category: { type: "string" },
                    confidence: { type: "number" },
                    keywords: { 
                      type: "array",
                      items: { type: "string" }
                    },
                    reasoning: { type: "string" }
                  }
                }
              }
            }
          }
        });

        // Update cases with detailed categorization
        for (const cat of response.categorizations) {
          try {
            await Jurisprudencia.update(cat.case_id, {
              categoria_automatica: cat.category,
              subcategoria: cat.classifier,
              confianca_categoria: cat.confidence / 100,
              palavras_chave: cat.keywords,
              justificativa_categoria: cat.reasoning
            });
          } catch (updateError) {
            console.error(`Error updating case ${cat.case_id}:`, updateError);
          }
        }

        setProgress(((i + 1) / totalBatches) * 100);
        
      } catch (error) {
        console.error(`Error categorizing batch ${i + 1}:`, error);
      }
    }

    setCategorizing(false);
    setProgress(0);
    loadCases();
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Categorização Automática</h1>
            <p className="text-slate-600">
              Organize e analise casos por área do direito usando inteligência artificial
            </p>
          </div>
          <Button
            onClick={categorizeAllCases}
            disabled={categorizing || uncategorizedCount === 0}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {categorizing ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Categorizando...
              </>
            ) : (
              <>
                <Brain className="w-4 h-4 mr-2" />
                Categorizar Casos ({uncategorizedCount})
              </>
            )}
          </Button>
        </div>

        {categorizing && (
          <Card className="mb-6 border-purple-200 bg-purple-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-purple-800 font-medium">Categorizando casos com IA...</span>
                <span className="text-purple-600 text-sm">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="text-purple-700 text-sm mt-2">
                A IA está analisando o conteúdo jurídico de cada caso para determinar a área do direito mais apropriada.
              </p>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="stats" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="stats">Estatísticas</TabsTrigger>
            <TabsTrigger value="management">Configuração</TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardContent className="p-6 text-center">
                  <FileText className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-blue-800">{cases.length}</p>
                  <p className="text-blue-600 text-sm font-medium">Total de Casos</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
                <CardContent className="p-6 text-center">
                  <Tag className="w-8 h-8 text-emerald-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-emerald-800">{categoryStats.length}</p>
                  <p className="text-emerald-600 text-sm font-medium">Categorias Ativas</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardContent className="p-6 text-center">
                  <Sparkles className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-purple-800">
                    {cases.length - uncategorizedCount}
                  </p>
                  <p className="text-purple-600 text-sm font-medium">Categorizados</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
                <CardContent className="p-6 text-center">
                  <Filter className="w-8 h-8 text-amber-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-amber-800">{uncategorizedCount}</p>
                  <p className="text-amber-600 text-sm font-medium">Pendentes</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-blue-600" />
                    Distribuição por Categoria
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={categoryStats}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {categoryStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-600" />
                    Top Categorias
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={categoryStats.slice(0, 8)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="name" 
                        angle={-45}
                        textAnchor="end"
                        height={80}
                        fontSize={12}
                      />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" fill="#3B82F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="management" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-600" />
                    Categorização Automática
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Button
                      onClick={() => categorizeAllCases()}
                      disabled={categorizing || uncategorizedCount === 0}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                    >
                      {categorizing ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Categorizando...
                        </>
                      ) : (
                        <>
                          <Zap className="w-4 h-4 mr-2" />
                          Categorizar Pendentes ({uncategorizedCount})
                        </>
                      )}
                    </Button>

                    <Button
                      onClick={() => categorizeAllCases()}
                      disabled={categorizing}
                      variant="outline"
                      className="w-full"
                    >
                      <Target className="w-4 h-4 mr-2" />
                      Recategorizar Todos ({cases.length})
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5 text-blue-600" />
                    Configuração de Categorias
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Categorias Padrão</Label>
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="secondary" className="text-xs">Direito Civil</Badge>
                      <Badge variant="secondary" className="text-xs">Direito Penal</Badge>
                      <Badge variant="secondary" className="text-xs">Direito Trabalhista</Badge>
                      <Badge variant="outline" className="text-xs">+9 mais...</Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="custom">Categorias Customizadas (opcional)</Label>
                    <Textarea
                      id="custom"
                      placeholder="Digite uma categoria por linha:&#10;Direito Digital&#10;Direito Esportivo&#10;Direito LGPD"
                      value={customCategories}
                      onChange={(e) => setCustomCategories(e.target.value)}
                      className="h-24 text-sm"
                    />
                    <p className="text-xs text-slate-500">
                      Se especificadas, serão usadas no lugar das categorias padrão
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}