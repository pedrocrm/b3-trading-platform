
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Database, 
  Search, 
  Brain, 
  Shield, 
  Palette, 
  Users,
  Server,
  FileText,
  Zap
} from "lucide-react";

const architectureComponents = [
  {
    title: "Multi-Tenancy",
    description: "Criar tenant por escritório. Isolamento de dados e personalização por cliente.",
    icon: Users,
    color: "blue",
    status: "Implementado",
    features: ["Isolamento por tenant_id", "Layout dinâmico", "RBAC por tenant"]
  },
  {
    title: "Modelagem de Dados",
    description: "Criar entidades para armazenar jurisprudência, pastas e anotações.",
    icon: Database,
    color: "emerald",
    status: "Implementado",
    features: ["Jurisprudencia", "DocumentoProcessado", "Pasta", "Anotacao"]
  },
  {
    title: "Pipeline de Ingestão (ETL)", 
    description: "Configurar Fluxo de Dados com OCR e Embeddings.",
    icon: Zap,
    color: "amber",
    status: "Implementado", 
    features: ["OCR Inteligente", "Categorização IA", "Embeddings Semânticos", "Enriquecimento de Metadados"]
  },
  {
    title: "Índice de Busca",
    description: "Criar índice no Elasticsearch com busca semântica.",
    icon: Search,
    color: "purple",
    status: "Implementado",
    features: ["Full-text search", "Vector search", "Filtros Jurimétricos", "Busca Multi-campo", "API DataJud Integrada"]
  },
  {
    title: "Portal de Experiência",
    description: "Criar páginas e componentes para interação do usuário.",
    icon: Palette,
    color: "pink",
    status: "Implementado",
    features: ["React + shadcn/ui", "Busca Semântica UI", "Dashboard", "Pastas"]
  },
  {
    title: "Segurança e Permissões",
    description: "Testar permissões e controle de acesso.",
    icon: Shield,
    color: "red",
    status: "Implementado",
    features: ["RBAC (admin, editor, viewer)", "Isolamento por Tenant", "JWT Auth"]
  }
];

export default function Architecture() {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Arquitetura da Solução - JUIT Rimor</h1>
          <p className="text-slate-600">
            Visão geral dos componentes da plataforma e status de implementação.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {architectureComponents.map((component, index) => (
            <Card key={index} className="flex flex-col">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center bg-${component.color}-100`}>
                    <component.icon className={`w-5 h-5 text-${component.color}-600`} />
                  </div>
                  <CardTitle className="text-lg">{component.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="flex-grow space-y-3">
                <p className="text-sm text-slate-600">{component.description}</p>
                <div>
                  <h4 className="font-semibold text-xs text-slate-500 uppercase mb-2">Features</h4>
                  <div className="flex flex-wrap gap-2">
                    {component.features.map(feature => (
                      <Badge key={feature} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
              <div className="p-4 border-t mt-4">
                <Badge className={component.status === 'Implementado' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}>
                  Status: {component.status}
                </Badge>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
