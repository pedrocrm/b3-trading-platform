import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Pasta, Jurisprudencia } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import CaseCard from "../components/search/CaseCard";
import { FolderOpen, FileText, AlertTriangle } from "lucide-react";

export default function FolderDetail() {
  const [folder, setFolder] = useState(null);
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const folderId = params.get('id');

    if (folderId) {
      loadFolderData(folderId);
    } else {
      setError("ID da pasta não fornecido.");
      setLoading(false);
    }
  }, [location]);

  const loadFolderData = async (folderId) => {
    setLoading(true);
    setError(null);
    try {
      const folderData = await Pasta.get(folderId);
      setFolder(folderData);

      if (folderData.casos && folderData.casos.length > 0) {
        // Fetch cases in batches if necessary, though for now we fetch all
        const caseData = await Jurisprudencia.filter({ id: { '$in': folderData.casos } });
        setCases(caseData);
      } else {
        setCases([]);
      }
    } catch (err) {
      console.error("Error loading folder data:", err);
      setError("Não foi possível carregar a pasta. Verifique se ela existe e se você tem permissão para acessá-la.");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <Skeleton className="h-10 w-1/3 mb-4" />
        <Skeleton className="h-6 w-1/2 mb-8" />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-800">Ocorreu um Erro</h2>
        <p className="text-slate-600">{error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <FolderOpen className="w-8 h-8 text-amber-500" />
            <h1 className="text-3xl font-bold text-slate-800">{folder?.nome}</h1>
          </div>
          <p className="text-slate-600">
            {folder?.descricao || `Visualizando ${cases.length} caso(s) salvo(s) nesta pasta.`}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cases.length > 0 ? (
            cases.map((caso) => (
              <CaseCard key={caso.id} case={caso} onClick={() => {}} onSaveToFolder={() => {}} />
            ))
          ) : (
            <div className="lg:col-span-3">
              <Card className="p-8 text-center">
                <FileText className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-600 mb-2">
                  Nenhum caso nesta pasta
                </h3>
                <p className="text-slate-500">
                  Adicione casos a esta pasta através da página de pesquisa.
                </p>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}