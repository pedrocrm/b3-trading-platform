
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  TestTube,
  CheckCircle2,
  XCircle,
  Clock,
  FileSearch,
  AlertTriangle,
  Info,
  Zap
} from "lucide-react";
import { consultarProcesso } from "@/api/functions";
import { consultarPorDocumento } from "@/api/functions";
import { verificarStatusTribunais } from "@/api/functions";

const getErrorMessage = (error) => {
  if (!error) return "Ocorreu um erro desconhecido.";

  // Check for specific error codes from our backend
  if (error.codigo === 'CNJ_UNAUTHORIZED' || error.error?.includes('Chave de API inválida')) {
      return "🔑 Erro de autenticação com a API do CNJ. Sua chave está inválida, expirada ou as credenciais não foram configuradas. Configure DATAJUD_USERNAME e DATAJUD_PASSWORD nas 'Secrets' para acesso completo via API Elastic, ou CNJ_API_KEY para API Pública.";
  }
  if (error.codigo === 'CONFIG_ERROR') {
      return "⚙️ Credenciais do DataJud não configuradas. Configure as variáveis de ambiente nas 'Secrets' do projeto.";
  }
  if (error.codigo === 'API_ERROR') {
      return `🌐 Erro na comunicação com a API: ${error.error || 'Falha na conectividade'}`;
  }
  if (error.codigo === 'NOT_FOUND') {
      return "🔍 Processo não encontrado na base de dados do CNJ.";
  }

  // Fallback for other errors from our function
  if (error.error) {
      return typeof error.error === 'string' ? error.error : JSON.stringify(error.error);
  }

  // Fallback for unexpected error formats
  return JSON.stringify(error);
};

export default function TestePesquisa() {
  const [testResults, setTestResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [manualTest, setManualTest] = useState({ numero: "", documento: "" });

  // Casos de teste atualizados com exemplos da documentação oficial
  const casosTeste = [
    {
      nome: "📋 TJMG - Exemplo Oficial Validado",
      numero: "13668284120218130024",
      tribunal: "TJMG",
      esperado: "Deve retornar dados estruturados do TJMG (MTD 1.2)."
    },
    {
      nome: "📋 TJSP - Exemplo Oficial Validado",
      numero: "5005618952013826057",
      tribunal: "TJSP",
      esperado: "Deve retornar dados estruturados do TJSP (MTD 1.2)."
    },
    {
      nome: "⚖️ STJ - Recurso Especial (Simulado)",
      numero: "REsp 2.048.123/SP",
      tribunal: "STJ",
      esperado: "Teste com formato de recurso especial do STJ."
    },
    {
      nome: "🔧 Processo com Formatação",
      numero: "1234567-89.2024.8.26.0001",
      tribunal: "TJSP",
      esperado: "Deve processar número com formatação (hífens e pontos)."
    },
    {
      nome: "❌ Formato Inválido",
      numero: "123-456-TESTE",
      tribunal: "Erro",
      esperado: "Deve retornar erro ou dados de demonstração para formato inválido."
    }
  ];

  const executeTest = async (caso) => {
    const startTime = Date.now();
    try {
      const { data, error } = await consultarProcesso({ numeroProcesso: caso.numero });
      const endTime = Date.now();

      return {
        ...caso,
        status: error ? 'erro' : 'sucesso',
        resultado: error ? error : data,
        tempo: endTime - startTime,
        detalhes: error ? getErrorMessage(error) : 'Consulta executada com sucesso'
      };
    } catch (e) {
      return {
        ...caso,
        status: 'erro',
        resultado: null,
        tempo: Date.now() - startTime,
        detalhes: e.message
      };
    }
  };

  const executarTodosOsTestes = async () => {
    setLoading(true);
    setTestResults([]);

    const results = [];
    for (const caso of casosTeste) {
      const result = await executeTest(caso);
      results.push(result);
      setTestResults([...results]); // Update progressively
    }

    setLoading(false);
  };

  const testeManualProcesso = async () => {
    if (!manualTest.numero) return;

    setLoading(true);
    const result = await executeTest({
      nome: "Teste Manual - Processo",
      numero: manualTest.numero,
      tribunal: "Manual",
      esperado: "Teste definido pelo usuário"
    });

    setTestResults([result]);
    setLoading(false);
  };

  const testeManualDocumento = async () => {
    if (!manualTest.documento) return;

    setLoading(true);
    const startTime = Date.now();

    try {
      const { data, error } = await consultarPorDocumento({ documento: manualTest.documento });
      const endTime = Date.now();

      const result = {
        nome: "Teste Manual - Documento",
        numero: manualTest.documento,
        tribunal: "Múltiplos",
        esperado: "Busca em todos os tribunais",
        status: error ? 'erro' : 'sucesso',
        resultado: error ? error : data,
        tempo: endTime - startTime,
        detalhes: error ? getErrorMessage(error) : `Encontrados processos em ${data?.resultados?.length || 0} tribunais`
      };

      setTestResults([result]);
    } catch (e) {
      setTestResults([{
        nome: "Teste Manual - Documento",
        numero: manualTest.documento,
        status: 'erro',
        detalhes: e.message,
        tempo: Date.now() - startTime
      }]);
    }

    setLoading(false);
  };

  const testarStatusTribunais = async () => {
    setLoading(true);
    const startTime = Date.now();

    try {
      const { data, error } = await verificarStatusTribunais();
      const endTime = Date.now();

      if (error) {
        throw new Error(getErrorMessage(error));
      }

      if (data?.sucesso) {
        const tribunaisOnline = Object.values(data.data).filter(t => t.status === 'online').length;
        const tribunaisTotal = Object.keys(data.data).length;

        setTestResults([{
          nome: "Status dos Tribunais",
          numero: "Verificação de conectividade",
          status: tribunaisOnline > 0 ? 'sucesso' : 'erro',
          resultado: data.data,
          tempo: endTime - startTime,
          detalhes: `${tribunaisOnline}/${tribunaisTotal} tribunais online`
        }]);
      }
    } catch (e) {
      setTestResults([{
        nome: "Status dos Tribunais",
        status: 'erro',
        detalhes: e.message,
        tempo: Date.now() - startTime
      }]);
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Teste de Pesquisa e Diagnósticos</h1>
          <p className="text-slate-600">
            Ferramenta para testar e diagnosticar o funcionamento da busca por processos e documentos.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TestTube className="w-5 h-5 text-blue-600" />
                Testes Automáticos
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-slate-600">
                Executa uma bateria de testes predefinidos para verificar diferentes cenários de busca.
              </p>
              <Button
                onClick={executarTodosOsTestes}
                disabled={loading}
                className="w-full"
              >
                {loading ? <Clock className="w-4 h-4 mr-2 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
                Executar Todos os Testes
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSearch className="w-5 h-5 text-emerald-600" />
                Testes Manuais
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <Input
                  placeholder="Número do processo (ex: 1234567-89.2024.8.26.0001)"
                  value={manualTest.numero}
                  onChange={(e) => setManualTest({...manualTest, numero: e.target.value})}
                />
                <Button onClick={testeManualProcesso} disabled={loading} className="w-full" variant="outline">
                  Testar Processo
                </Button>
              </div>

              <div className="space-y-3">
                <Input
                  placeholder="CPF ou CNPJ (ex: 12345678901)"
                  value={manualTest.documento}
                  onChange={(e) => setManualTest({...manualTest, documento: e.target.value})}
                />
                <Button onClick={testeManualDocumento} disabled={loading} className="w-full" variant="outline">
                  Testar Documento
                </Button>
              </div>

              <Button onClick={testarStatusTribunais} disabled={loading} className="w-full" variant="outline">
                Verificar Status dos Tribunais
              </Button>
            </CardContent>
          </Card>
        </div>

        {testResults.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="w-5 h-5 text-purple-600" />
                Resultados dos Testes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {testResults.map((result, index) => (
                  <div key={index} className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {result.status === 'sucesso' ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        ) : (
                          <XCircle className="w-5 h-5 text-red-600" />
                        )}
                        <h4 className="font-semibold text-slate-800">{result.nome}</h4>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={result.status === 'sucesso' ? 'default' : 'destructive'}>
                          {result.status}
                        </Badge>
                        {result.tempo && (
                          <Badge variant="outline">
                            {result.tempo}ms
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="text-sm text-slate-600 mb-2">
                      <strong>Entrada:</strong> {result.numero}
                    </div>

                    <div className="text-sm text-slate-600 mb-2">
                      <strong>Detalhes:</strong> {result.detalhes}
                    </div>

                    {result.resultado && typeof result.resultado === 'object' && (
                      <div className="mt-3 p-3 bg-slate-50 rounded text-xs">
                        <strong>Resposta:</strong>
                        <pre className="mt-1 overflow-auto">
                          {JSON.stringify(result.resultado, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Alert className="mt-6">
          <AlertTriangle className="w-4 h-4" />
          <AlertTitle>Status da Integração DataJud</AlertTitle>
          <AlertDescription>
            <div className="space-y-3 mt-2">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-800">🔄 Modo Demonstração Ativo</p>
                <p className="text-xs text-blue-700 mt-1">
                  Sistema configurado com dados simulados baseados na documentação oficial do CNJ (MTD 1.2).
                  Os exemplos testados seguem a estrutura real das APIs DataJud.
                </p>
              </div>

              <div className="p-3 bg-amber-50 rounded-lg">
                <p className="text-sm font-medium text-amber-800">⚙️ Configuração para Produção</p>
                <div className="text-xs text-amber-700 mt-1 space-y-1">
                  <p><strong>API Elastic (Acesso Completo):</strong> Configure DATAJUD_USERNAME e DATAJUD_PASSWORD</p>
                  <p><strong>API Pública (Metadados):</strong> Configure CNJ_API_KEY (opcional)</p>
                  <p><strong>Documentação:</strong> Seguindo especificações oficiais CNJ</p>
                </div>
              </div>

              <div className="text-xs text-slate-600 space-y-1">
                <p><strong>✅ Sucesso:</strong> Dados retornados seguindo padrão MTD 1.2.</p>
                <p><strong>❌ Erro:</strong> Verifique conectividade ou configuração de credenciais.</p>
                <p><strong>⏱️ Tempo:</strong> Latência incluindo cache e processamento.</p>
                <p><strong>📊 Exemplos:</strong> Baseados na documentação oficial do CNJ.</p>
                <p><strong>🔧 Cache:</strong> Resultados mantidos por 1 hora para otimização.</p>
              </div>
            </div>
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}
