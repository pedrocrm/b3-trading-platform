
import React, { useState, useEffect } from "react";
import { Pasta, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FolderOpen, Plus, Users, Lock, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import FolderCard from "../components/folders/FolderCard";
import CreateFolderDialog from "../components/folders/CreateFolderDialog";
import ShareFolderDialog from "../components/folders/ShareFolderDialog";

export default function Folders() {
  const [folders, setFolders] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [showShareDialog, setShowShareDialog] = useState(false);

  useEffect(() => {
    getCurrentUser();
  }, []);

  useEffect(() => {
    if (user) {
      loadFolders();
    }
  }, [user]);

  const getCurrentUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error getting user:", error);
    }
  };

  const loadFolders = async () => {
    setLoading(true);
    try {
      const [ownedFolders, sharedFolders] = await Promise.all([
        Pasta.filter({ owner_user: user.email }),
        Pasta.list() // We'll filter client-side for shared folders
      ]);

      const sharedWithMe = sharedFolders.filter(folder => 
        folder.shared_users?.includes(user.email) && folder.owner_user !== user.email
      );

      setFolders([...ownedFolders, ...sharedWithMe]);
    } catch (error) {
      console.error("Error loading folders:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFolder = async (folderData) => {
    try {
      await Pasta.create({
        ...folderData,
        owner_user: user.email,
        tenant_id: "default",
        shared_users: [],
        casos: [] // Added to initialize an empty array for cases
      });
      
      setShowCreateDialog(false);
      loadFolders();
    } catch (error) {
      console.error("Error creating folder:", error);
    }
  };

  const handleShareFolder = async (emails) => {
    if (!selectedFolder) return;

    try {
      const uniqueEmails = [...new Set([...(selectedFolder.shared_users || []), ...emails])];
      await Pasta.update(selectedFolder.id, {
        shared_users: uniqueEmails
      });
      
      setShowShareDialog(false);
      setSelectedFolder(null);
      loadFolders();
    } catch (error) {
      console.error("Error sharing folder:", error);
    }
  };

  const filteredFolders = folders.filter(folder =>
    folder.nome?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const ownedFolders = filteredFolders.filter(folder => folder.owner_user === user?.email);
  const sharedFolders = filteredFolders.filter(folder => folder.owner_user !== user?.email);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Minhas Pastas</h1>
            <p className="text-slate-600">
              Organize seus casos jurisprudenciais em pastas temáticas
            </p>
          </div>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Pasta
          </Button>
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Buscar pastas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-8">
          {ownedFolders.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Lock className="w-4 h-4 text-slate-600" />
                <h2 className="text-xl font-semibold text-slate-800">Minhas Pastas</h2>
                <span className="text-sm text-slate-500">({ownedFolders.length})</span>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {ownedFolders.map((folder) => (
                  <Link to={createPageUrl(`FolderDetail?id=${folder.id}`)} key={folder.id} className="no-underline">
                    <FolderCard
                      folder={folder}
                      isOwner={true}
                      onShare={(e) => {
                        e.preventDefault(); // Prevent link navigation
                        e.stopPropagation(); // Stop event propagation
                        setSelectedFolder(folder);
                        setShowShareDialog(true);
                      }}
                    />
                  </Link>
                ))}
              </div>
            </div>
          )}

          {sharedFolders.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-4 h-4 text-emerald-600" />
                <h2 className="text-xl font-semibold text-slate-800">Compartilhadas Comigo</h2>
                <span className="text-sm text-slate-500">({sharedFolders.length})</span>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sharedFolders.map((folder) => (
                  <Link to={createPageUrl(`FolderDetail?id=${folder.id}`)} key={folder.id} className="no-underline">
                    <FolderCard
                      folder={folder}
                      isOwner={false}
                    />
                  </Link>
                ))}
              </div>
            </div>
          )}

          {filteredFolders.length === 0 && !loading && (
            <Card className="p-8 text-center">
              <FolderOpen className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-600 mb-2">
                {searchTerm ? "Nenhuma pasta encontrada" : "Nenhuma pasta criada"}
              </h3>
              <p className="text-slate-500 mb-4">
                {searchTerm 
                  ? "Tente ajustar os termos de busca" 
                  : "Crie sua primeira pasta para organizar casos jurisprudenciais"
                }
              </p>
              {!searchTerm && (
                <Button
                  onClick={() => setShowCreateDialog(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeira Pasta
                </Button>
              )}
            </Card>
          )}
        </div>

        <CreateFolderDialog
          open={showCreateDialog}
          onOpenChange={setShowCreateDialog}
          onCreateFolder={handleCreateFolder}
        />

        <ShareFolderDialog
          open={showShareDialog}
          onOpenChange={setShowShareDialog}
          folder={selectedFolder}
          onShare={handleShareFolder}
        />
      </div>
    </div>
  );
}
