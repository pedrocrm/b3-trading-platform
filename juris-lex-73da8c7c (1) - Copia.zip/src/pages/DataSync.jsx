import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, DatabaseZap, Clock } from "lucide-react";
import TribunalStatus from "../components/datasync/TribunalStatus";
import { Input } from "@/components/ui/input";

export default function DataSync() {

  const handleManualSync = () => {
    // Adicionar lógica para chamar a função stjCrawler
    alert("Sincronização manual iniciada. (Funcionalidade a ser implementada)");
  };
  
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Sincronização de Dados</h1>
          <p className="text-slate-600">
            Gerencie a ingestão e atualização da sua base de dados jurisprudencial.
          </p>
        </div>

        <TribunalStatus />

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DatabaseZap className="w-5 h-5 text-emerald-600" />
                Sincronização Automática
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-slate-600">
                A plataforma está configurada para buscar novos casos dos tribunais conectados automaticamente.
              </p>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <span className="font-medium text-slate-700">Próxima Sincronização</span>
                <span className="font-semibold text-emerald-700">Amanhã às 02:00</span>
              </div>
              <Button variant="outline" className="w-full">
                <Clock className="w-4 h-4 mr-2" />
                Ajustar Horário
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-amber-600" />
                Upload Manual de Documentos
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-slate-600">
                Faça o upload de arquivos (PDF, DOCX) para que sejam processados, categorizados e adicionados à base.
              </p>
              <Input type="file" multiple />
              <Button className="w-full bg-amber-600 hover:bg-amber-700">
                <Upload className="w-4 h-4 mr-2" />
                Enviar Arquivos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}