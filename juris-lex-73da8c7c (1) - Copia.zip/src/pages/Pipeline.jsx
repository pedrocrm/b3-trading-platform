import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Zap, FileInput, Brain, Database, CheckCircle, AlertTriangle, Tag, DatabaseZap } from "lucide-react";

import { dataIngestionPipeline } from "@/api/functions";

export default function Pipeline() {
  const [caseText, setCaseText] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  
  // Estados para processamento de arquivo
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileProcessing, setFileProcessing] = useState(false);
  const [fileResult, setFileResult] = useState(null);
  const [processingOptions, setProcessingOptions] = useState({
    ocr: true,
    categorizar: true,
    embeddings: true
  });

  const steps = [
    { name: "Início", icon: FileInput },
    { name: "OCR + Extração", icon: Brain },
    { name: "Categorização IA", icon: Tag },
    { name: "Embeddings", icon: DatabaseZap },
    { name: "Persistência", icon: Database },
    { name: "Concluído", icon: CheckCircle },
  ];

  const handleTriggerPipeline = async () => {
    if (!caseText.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);
    setFileResult(null);
    setCurrentStep(0);

    try {
      setCurrentStep(1);
      
      const { data, error: apiError } = await dataIngestionPipeline({ caseText });

      if (apiError) {
        throw new Error(apiError.error || "Ocorreu um erro na pipeline.");
      }
      
      setCurrentStep(4);
      setResult(data.case);
      setCurrentStep(5);
    } catch (e) {
      setError(e.message);
      setCurrentStep(0);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      setFileResult(null);
      setResult(null);
      setError(null);
    }
  };

  const handleFileProcessing = async () => {
    if (!selectedFile) return;

    setFileProcessing(true);
    setLoading(false);
    setCurrentStep(0);
    setFileResult(null);
    setResult(null);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('ocr', processingOptions.ocr.toString());
      formData.append('categorizar', processingOptions.categorizar.toString());
      formData.append('embeddings', processingOptions.embeddings.toString());

      setCurrentStep(1);
      await new Promise(resolve => setTimeout(resolve, 500)); 

      setCurrentStep(2);
      await new Promise(resolve => setTimeout(resolve, 500)); 

      setCurrentStep(3);
      await new Promise(resolve => setTimeout(resolve, 500)); 

      setCurrentStep(4);

      const response = await fetch('/api/functions/processarDocumento', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro no processamento do arquivo.');
      }

      setCurrentStep(5);
      setFileResult(data.documento);

    } catch (e) {
      setError(e.message);
      setCurrentStep(0);
    } finally {
      setFileProcessing(false);
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Pipeline ETL + OCR + Embeddings</h1>
          <p className="text-slate-600">
            Processe documentos jurídicos completos com OCR, categorização automática e geração de embeddings.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Pipeline de Texto Existente */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-600" />
                Pipeline de Texto
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label htmlFor="case-text" className="block text-sm font-medium text-slate-700 mb-2">
                  Cole o inteiro teor de um documento para simular a ingestão:
                </label>
                <Textarea
                  id="case-text"
                  placeholder="Cole o texto completo de um acórdão ou decisão aqui..."
                  value={caseText}
                  onChange={(e) => setCaseText(e.target.value)}
                  className="h-32"
                  disabled={loading || fileProcessing}
                />
              </div>
              <Button 
                onClick={handleTriggerPipeline} 
                disabled={loading || !caseText.trim() || fileProcessing}
                className="w-full"
              >
                {loading ? "Processando..." : "Iniciar Pipeline de Texto"}
              </Button>
            </CardContent>
          </Card>

          {/* Pipeline de Arquivo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600" />
                Pipeline de Arquivo (OCR + IA)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Selecione um arquivo (PDF, DOCX, JPG, PNG):
                </label>
                <Input
                  type="file"
                  accept=".pdf,.docx,.jpg,.jpeg,.png"
                  onChange={handleFileUpload}
                  disabled={fileProcessing || loading}
                />
                {selectedFile && (
                  <p className="text-xs text-slate-600 mt-1">
                    Arquivo: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Opções de Processamento:</label>
                <div className="flex flex-wrap gap-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={processingOptions.ocr}
                      onChange={(e) => setProcessingOptions({
                        ...processingOptions,
                        ocr: e.target.checked
                      })}
                      className="mr-2"
                      disabled={fileProcessing || loading}
                    />
                    <span className="text-sm">OCR + Extração</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={processingOptions.categorizar}
                      onChange={(e) => setProcessingOptions({
                        ...processingOptions,
                        categorizar: e.target.checked
                      })}
                      className="mr-2"
                      disabled={fileProcessing || loading}
                    />
                    <span className="text-sm">Categorização IA</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={processingOptions.embeddings}
                      onChange={(e) => setProcessingOptions({
                        ...processingOptions,
                        embeddings: e.target.checked
                      })}
                      className="mr-2"
                      disabled={fileProcessing || loading}
                    />
                    <span className="text-sm">Embeddings</span>
                  </label>
                </div>
              </div>

              <Button 
                onClick={handleFileProcessing} 
                disabled={fileProcessing || !selectedFile || loading}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {fileProcessing ? "Processando Arquivo..." : "Iniciar Pipeline Completo"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Progresso do Pipeline */}
        {(loading || fileProcessing) && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Progresso do Pipeline ETL</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                {steps.map((step, index) => (
                  <div key={step.name} className="flex flex-col items-center flex-1">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      currentStep > index ? 'bg-emerald-500 text-white' : 
                      currentStep === index ? 'bg-purple-500 text-white animate-pulse' : 
                      'bg-slate-200 text-slate-500'
                    }`}>
                      <step.icon className="w-6 h-6" />
                    </div>
                    <p className={`mt-2 text-xs text-center ${currentStep >= index ? 'font-semibold' : ''}`}>
                      {step.name}
                    </p>
                  </div>
                ))}
              </div>
              
              {fileProcessing && (
                <div className="mt-4">
                  <div className="bg-purple-100 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-purple-800 font-medium">
                        Processando: {selectedFile?.name}
                      </span>
                      <span className="text-purple-600 text-sm">
                        Etapa {currentStep} de {steps.length - 1}
                      </span>
                    </div>
                    <div className="w-full bg-purple-200 rounded-full h-2">
                      <div 
                        className="bg-purple-600 h-2 rounded-full transition-all duration-300" 
                        style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Resultado do Processamento de Arquivo */}
        {fileResult && (
          <Card className="mb-6 border-emerald-300 bg-emerald-50">
            <CardHeader className="flex flex-row items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              <CardTitle className="text-emerald-800">Processamento Concluído!</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p><strong>Arquivo:</strong> {fileResult.nome_arquivo}</p>
                  <p><strong>Status:</strong> {fileResult.status_processamento}</p>
                  <p><strong>Tempo Total:</strong> {fileResult.tempo_total}ms</p>
                </div>
                <div>
                  <p><strong>Categoria:</strong> {fileResult.resumo.categoria_identificada}</p>
                  <p><strong>Embeddings:</strong> {fileResult.resumo.embeddings_gerados ? 'Sim' : 'Não'}</p>
                  <p><strong>Qualidade:</strong> {Math.round(fileResult.resumo.qualidade_processamento * 100)}%</p>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h4 className="font-semibold text-emerald-800 mb-2">Etapas Executadas:</h4>
                <div className="flex flex-wrap gap-4 text-xs">
                  {Object.entries(fileResult.etapas_executadas).map(([etapa, executada]) => (
                    <span key={etapa} className={`px-2 py-1 rounded ${
                      executada ? 'bg-emerald-200 text-emerald-800' : 'bg-slate-200 text-slate-600'
                    }`}>
                      {etapa}: {executada ? '✓' : '✗'}
                    </span>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Resultado Existente do Pipeline de Texto */}
        {result && (
          <Card className="mt-6 border-emerald-300 bg-emerald-50">
            <CardHeader className="flex flex-row items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              <CardTitle className="text-emerald-800">Pipeline de Texto Concluído!</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p><strong>ID do Caso:</strong> {result.id}</p>
              <p><strong>Processo:</strong> {result.processo}</p>
              <p><strong>Tribunal:</strong> {result.tribunal}</p>
              <p><strong>Categoria IA:</strong> {result.categoria_automatica}</p>
            </CardContent>
          </Card>
        )}

        {/* Error Display */}
        {error && (
          <Card className="mt-6 border-red-300 bg-red-50">
            <CardHeader className="flex flex-row items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <CardTitle className="text-red-800">Erro no Pipeline</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-700">{error}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}