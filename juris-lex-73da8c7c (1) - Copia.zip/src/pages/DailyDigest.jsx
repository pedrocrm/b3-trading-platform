import React, { useState, useEffect } from "react";
import { Jurisprudencia, User } from "@/api/entities";
import { SendEmail, InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Mail, 
  Calendar, 
  Settings, 
  Send,
  Clock,
  Brain,
  FileText,
  TrendingUp
} from "lucide-react";
import { format, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function DailyDigest() {
  const [user, setUser] = useState(null);
  const [preferences, setPreferences] = useState({
    enabled: true,
    includeStats: true,
    includeCategories: true,
    customTopics: ""
  });
  const [recentCases, setRecentCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [lastDigest, setLastDigest] = useState(null);

  useEffect(() => {
    loadUserAndPreferences();
    loadRecentCases();
  }, []);

  const loadUserAndPreferences = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const userPrefs = currentUser.digest_preferences || {};
      setPreferences(prev => ({
        ...prev,
        ...userPrefs
      }));
      
      setLastDigest(localStorage.getItem('lastDigestDate'));
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const loadRecentCases = async () => {
    setLoading(true);
    try {
      const yesterday = subDays(new Date(), 1);
      const yesterdayStr = format(yesterday, 'yyyy-MM-dd');
      
      const cases = await Jurisprudencia.filter({
        created_date: yesterdayStr
      });
      
      setRecentCases(cases);
    } catch (error) {
      console.error("Error loading recent cases:", error);
    } finally {
      setLoading(false);
    }
  };

  const savePreferences = async () => {
    if (!user) return;
    
    try {
      await User.updateMyUserData({
        digest_preferences: preferences
      });
      
      alert("Preferências salvas com sucesso!");
    } catch (error) {
      console.error("Error saving preferences:", error);
      alert("Erro ao salvar preferências");
    }
  };

  const generateAndSendDigest = async () => {
    if (!user || recentCases.length === 0) return;
    
    setGenerating(true);
    try {
      const digestContent = await InvokeLLM({
        prompt: `Crie um digest jurisprudencial profissional e elegante para ${user.full_name || 'Advogado'}.

CASOS DE ONTEM (${format(subDays(new Date(), 1), 'dd/MM/yyyy', { locale: ptBR })}):
${recentCases.map(caso => `
📄 ${caso.processo} - ${caso.tribunal}
${caso.categoria_automatica ? `🏷️ ${caso.categoria_automatica}` : ''}
📝 ${caso.ementa}
${caso.palavras_chave?.length ? `🔍 Palavras-chave: ${caso.palavras_chave.join(', ')}` : ''}
---`).join('\n')}

${preferences.customTopics ? `
TÓPICOS DE INTERESSE ESPECIAL:
${preferences.customTopics}
` : ''}

INSTRUÇÕES:
1. Crie um resumo executivo atrativo e informativo
2. ${preferences.includeStats ? 'Inclua estatísticas e métricas relevantes' : 'Foque apenas no conteúdo dos casos'}
3. ${preferences.includeCategories ? 'Organize por categoria jurídica' : 'Mantenha organização cronológica'}
4. Use formatação HTML elegante para email
5. Destaque insights jurídicos importantes
6. Inclua análise de tendências se relevante
7. Tom profissional mas acessível
8. Máximo 2000 palavras

O digest deve ser valioso para um profissional do direito busy.`,
        response_json_schema: {
          type: "object",
          properties: {
            subject: { type: "string" },
            html_content: { type: "string" },
            summary: { type: "string" },
            key_highlights: {
              type: "array", 
              items: { type: "string" }
            }
          }
        }
      });

      await SendEmail({
        to: user.email,
        subject: digestContent.subject,
        body: digestContent.html_content,
        from_name: "LexSearch Daily Digest"
      });

      localStorage.setItem('lastDigestDate', format(new Date(), 'yyyy-MM-dd'));
      setLastDigest(format(new Date(), 'yyyy-MM-dd'));
      
      alert("Digest enviado com sucesso para seu email!");
      
    } catch (error) {
      console.error("Error generating digest:", error);
      alert("Erro ao gerar digest");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Digest Diário</h1>
          <p className="text-slate-600">
            Receba um resumo inteligente dos novos casos jurisprudenciais
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-blue-600" />
                  Configurações do Digest
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="enabled" className="font-medium">
                      Digest Diário Ativo
                    </Label>
                    <p className="text-sm text-slate-600 mt-1">
                      Receber resumo automático às 7h da manhã
                    </p>
                  </div>
                  <Switch
                    id="enabled"
                    checked={preferences.enabled}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, enabled: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="stats" className="font-medium">
                      Incluir Estatísticas
                    </Label>
                    <p className="text-sm text-slate-600 mt-1">
                      Métricas e análises quantitativas
                    </p>
                  </div>
                  <Switch
                    id="stats"
                    checked={preferences.includeStats}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, includeStats: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="categories" className="font-medium">
                      Organizar por Categoria
                    </Label>
                    <p className="text-sm text-slate-600 mt-1">
                      Agrupar casos por área do direito
                    </p>
                  </div>
                  <Switch
                    id="categories"
                    checked={preferences.includeCategories}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, includeCategories: checked }))
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="topics">Tópicos de Interesse Especial</Label>
                  <Textarea
                    id="topics"
                    placeholder="Ex: Direito Digital, LGPD, Inteligência Artificial, Direito do Consumidor..."
                    value={preferences.customTopics}
                    onChange={(e) => 
                      setPreferences(prev => ({ ...prev, customTopics: e.target.value }))
                    }
                    className="h-20"
                  />
                  <p className="text-xs text-slate-500">
                    A IA dará atenção especial a casos relacionados a esses tópicos
                  </p>
                </div>

                <div className="flex gap-3">
                  <Button onClick={savePreferences} variant="outline">
                    <Settings className="w-4 h-4 mr-2" />
                    Salvar Preferências
                  </Button>
                  
                  <Button 
                    onClick={generateAndSendDigest}
                    disabled={generating || recentCases.length === 0}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {generating ? (
                      <>
                        <Clock className="w-4 h-4 mr-2 animate-spin" />
                        Gerando...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Enviar Digest Agora
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  Preview - Casos de Ontem
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-3">
                    {Array(3).fill(0).map((_, i) => (
                      <div key={i} className="animate-pulse space-y-2">
                        <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                        <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                      </div>
                    ))}
                  </div>
                ) : recentCases.length > 0 ? (
                  <div className="space-y-4">
                    {recentCases.slice(0, 5).map((caso) => (
                      <div key={caso.id} className="border-l-4 border-emerald-500 pl-4 py-2">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold text-slate-800">{caso.processo}</h4>
                          <Badge variant="secondary">{caso.tribunal}</Badge>
                          {caso.categoria_automatica && (
                            <Badge variant="outline" className="bg-emerald-50 text-emerald-700">
                              {caso.categoria_automatica}
                            </Badge>
                          )}
                        </div>
                        <p className="text-slate-600 text-sm line-clamp-2">
                          {caso.ementa}
                        </p>
                      </div>
                    ))}
                    {recentCases.length > 5 && (
                      <p className="text-sm text-slate-500 text-center">
                        ... e mais {recentCases.length - 5} casos
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <Calendar className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                    <p className="text-slate-600">
                      Nenhum caso novo ontem
                    </p>
                    <p className="text-slate-500 text-sm">
                      O digest será enviado quando houver novos casos
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                  Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Status</span>
                    <Badge variant={preferences.enabled ? "default" : "secondary"}>
                      {preferences.enabled ? "Ativo" : "Inativo"}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Último Digest</span>
                    <span className="text-sm font-medium">
                      {lastDigest ? format(new Date(lastDigest), "dd/MM", { locale: ptBR }) : "Nunca"}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Casos Ontem</span>
                    <span className="text-sm font-medium">{recentCases.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-indigo-600" />
                  Como Funciona
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-slate-600">
                      <strong>Coleta automática:</strong> Sistema busca novos casos diariamente
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-slate-600">
                      <strong>Análise IA:</strong> Categoriza e extrai insights jurídicos
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-slate-600">
                      <strong>Digest personalizado:</strong> Gera resumo baseado nas suas preferências
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-slate-600">
                      <strong>Entrega automática:</strong> Email enviado às 7h da manhã
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}