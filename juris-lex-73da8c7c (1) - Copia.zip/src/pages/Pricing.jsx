import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap, Building2, Users, Crown } from "lucide-react";

const plans = [
  {
    name: "Starter",
    price: "R$ 299",
    period: "/mês",
    description: "Perfeito para advogados individuais e pequenos escritórios",
    icon: Star,
    color: "blue",
    features: [
      "Até 1.000 pesquisas/mês",
      "Acesso a 3 tribunais",
      "Busca textual básica",
      "5 pastas organizacionais",
      "Suporte por email",
      "Relatórios básicos"
    ],
    limitations: [
      "Sem busca semântica",
      "Sem marca branca",
      "1 usuário apenas"
    ]
  },
  {
    name: "Professional",
    price: "R$ 799",
    period: "/mês",
    description: "Ideal para escritórios médios com equipes colaborativas",
    icon: Building2,
    color: "emerald",
    popular: true,
    features: [
      "Pesquisas ilimitadas",
      "Acesso a todos os tribunais",
      "Busca semântica com IA",
      "Pastas compartilhadas",
      "Até 10 usuários",
      "Analytics avançados",
      "API para integração",
      "Suporte prioritário",
      "Digest diário personalizado"
    ],
    limitations: [
      "Sem marca branca"
    ]
  },
  {
    name: "Enterprise",
    price: "Sob consulta",
    period: "",
    description: "Solução completa para grandes escritórios e departamentos jurídicos",
    icon: Crown,
    color: "purple",
    features: [
      "Tudo do Professional",
      "Marca branca completa",
      "Usuários ilimitados",
      "SSO corporativo",
      "Auditoria completa",
      "Treinamento dedicado",
      "Account Manager",
      "SLA garantido",
      "Customizações específicas",
      "Deploy on-premises"
    ],
    limitations: []
  }
];

export default function Pricing() {
  const [billingType, setBillingType] = useState("monthly");

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-800 mb-4">
            Planos que crescem com seu escritório
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Desde advogados individuais até grandes departamentos jurídicos. 
            Escolha o plano ideal para potencializar sua pesquisa jurisprudencial.
          </p>
        </div>

        {/* Billing Toggle */}
        <div className="flex justify-center mb-8">
          <div className="bg-slate-100 p-1 rounded-lg">
            <button
              onClick={() => setBillingType("monthly")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                billingType === "monthly"
                  ? "bg-white text-slate-800 shadow-sm"
                  : "text-slate-600 hover:text-slate-800"
              }`}
            >
              Mensal
            </button>
            <button
              onClick={() => setBillingType("annual")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                billingType === "annual"
                  ? "bg-white text-slate-800 shadow-sm"
                  : "text-slate-600 hover:text-slate-800"
              }`}
            >
              Anual
              <Badge variant="secondary" className="ml-2 text-xs bg-emerald-100 text-emerald-700">
                -20%
              </Badge>
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <Card 
              key={plan.name}
              className={`relative ${
                plan.popular 
                  ? "ring-2 ring-emerald-500 shadow-xl scale-105" 
                  : "shadow-lg hover:shadow-xl"
              } transition-all duration-300`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-emerald-500 text-white px-4 py-1">
                    Mais Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-6">
                <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-${plan.color}-400 to-${plan.color}-600 flex items-center justify-center`}>
                  <plan.icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold text-slate-800">
                  {plan.name}
                </CardTitle>
                <p className="text-slate-600 text-sm mt-2">
                  {plan.description}
                </p>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-slate-800">
                    {plan.price}
                  </span>
                  <span className="text-slate-600">{plan.period}</span>
                  {billingType === "annual" && plan.price !== "Sob consulta" && (
                    <div className="text-sm text-emerald-600 mt-1">
                      Economize 20% no plano anual
                    </div>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <Button 
                  className={`w-full ${
                    plan.popular 
                      ? "bg-emerald-600 hover:bg-emerald-700" 
                      : "bg-slate-800 hover:bg-slate-700"
                  }`}
                >
                  {plan.price === "Sob consulta" ? "Falar com Vendas" : "Começar Agora"}
                </Button>

                <div className="space-y-3">
                  <h4 className="font-semibold text-slate-800 text-sm">
                    Recursos inclusos:
                  </h4>
                  <ul className="space-y-2">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                        <span className="text-slate-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {plan.limitations.length > 0 && (
                  <div className="space-y-3 pt-4 border-t border-slate-100">
                    <h4 className="font-semibold text-slate-600 text-sm">
                      Limitações:
                    </h4>
                    <ul className="space-y-2">
                      {plan.limitations.map((limitation, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-sm">
                          <div className="w-4 h-4 rounded-full bg-slate-300 flex-shrink-0"></div>
                          <span className="text-slate-600">{limitation}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-8">
            Perguntas Frequentes
          </h2>
          <div className="grid md:grid-cols-2 gap-6 text-left">
            {[
              {
                question: "Posso fazer upgrade/downgrade a qualquer momento?",
                answer: "Sim, você pode alterar seu plano a qualquer momento. As mudanças são aplicadas no próximo ciclo de cobrança."
              },
              {
                question: "Os dados ficam seguros na nuvem?",
                answer: "Absolutamente. Utilizamos criptografia de ponta e compliance com LGPD. Seus dados são isolados por tenant."
              },
              {
                question: "Há limite de armazenamento?",
                answer: "Não há limite para documentos. O limite está no número de pesquisas e usuários conforme seu plano."
              },
              {
                question: "Posso testar antes de assinar?",
                answer: "Sim! Oferecemos 14 dias gratuitos em qualquer plano, sem necessidade de cartão de crédito."
              }
            ].map((faq, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <h4 className="font-semibold text-slate-800 mb-2">
                    {faq.question}
                  </h4>
                  <p className="text-slate-600 text-sm">
                    {faq.answer}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}