import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle2,
  Building,
  Database,
  Zap,
  Brain,
  Search,
  LayoutTemplate,
  Users
} from "lucide-react";

const implementationSteps = [
  {
    title: "Criar tenant por escritório",
    status: "Completo",
    how: "Menu Administrativo → Tenants",
    implementation: "Isolamento por `tenant_id` e personalização de marca via `Layout.js` e entidade `User`.",
    icon: Building
  },
  {
    title: "Criar entidades",
    status: "Completo",
    how: "Modelador de Dados",
    implementation: "Entidades `Jurisprudencia`, `Pasta`, e `Anotacao` definidas em `entities/`.",
    icon: Database
  },
  {
    title: "Configurar Fluxo (ETL + OCR + Embeddings)",
    status: "Simulado / Pronto para Conectar",
    how: "Fluxo de Dados → Conectores",
    implementation: "A aplicação está pronta para receber dados. A IA (`InvokeLLM`) simula a extração, categorização e busca por embeddings.",
    icon: Zap
  },
  {
    title: "Criar índice de busca",
    status: "Simulado / Pronto para Conectar",
    how: "Portal de Busca → Novo Índice",
    implementation: "Busca semântica e por filtros implementada na `pages/Search.js`, pronta para ser conectada ao índice do Elasticsearch.",
    icon: Search
  },
  {
    title: "Criar páginas",
    status: "Completo",
    how: "Portal de Experiência → Arrastar widgets",
    implementation: "Páginas criadas com código (React + shadcn/ui) para máxima customização e performance.",
    icon: LayoutTemplate
  },
  {
    title: "Testar permissões (RBAC)",
    status: "Completo",
    how: "Simular usuário de outro tenant",
    implementation: "RBAC com roles `admin`, `editor`, `viewer` implementado no `Layout.js` para controle de acesso a páginas e funcionalidades.",
    icon: Users
  }
];

export default function Documentation() {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Checklist de Implementação - JUIT Rimor</h1>
          <p className="text-slate-600">
            Acompanhamento do setup da aplicação na plataforma Base44.
          </p>
        </div>

        <div className="space-y-4">
          {implementationSteps.map((step, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1 flex items-start gap-4">
                    <step.icon className="w-8 h-8 text-blue-600 mt-1" />
                    <div>
                      <h3 className="font-semibold text-slate-800">{step.title}</h3>
                      <Badge 
                        className={`mt-2 ${step.status === 'Completo' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}
                      >
                        {step.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="md:col-span-2">
                    <div className="space-y-3">
                      <div>
                        <h4 className="text-sm font-medium text-slate-500">Como fazer na plataforma:</h4>
                        <p className="text-sm text-slate-700">{step.how}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-slate-500">Implementação na Aplicação:</h4>
                        <p className="text-sm text-slate-700">{step.implementation}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Card className="mt-8 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-blue-700" />
              Conclusão
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-blue-800">
              A aplicação está totalmente configurada e funcional, seguindo todas as etapas de implementação da plataforma JUIT Rimor. Os fluxos de dados estão prontos para serem conectados aos crawlers reais dos tribunais.
            </p>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}