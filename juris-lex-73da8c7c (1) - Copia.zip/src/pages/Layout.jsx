

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User as UserEntity } from "@/api/entities";
import {
  Scale,
  Search,
  FolderOpen,
  PlusCircle,
  User,
  Brain,
  Mail,
  Palette,
  Server,
  Zap,
  DatabaseZap,
  LayoutGrid,
  FileText,
  TestTube // Added TestTube icon
} from "lucide-react";
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarTrigger,
  SidebarProvider
} from "@/components/ui/sidebar";
import { Skeleton } from "@/components/ui/skeleton";

const allNavigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutGrid,
    roles: ["admin", "editor", "viewer"]
  },
  {
    title: "Pesquisar",
    url: createPageUrl("Search"),
    icon: Search,
    roles: ["admin", "editor", "viewer"]
  },
  {
    title: "Minhas Pastas",
    url: createPageUrl("Folders"),
    icon: FolderOpen,
    roles: ["admin", "editor", "viewer"]
  },
  {
    title: "Categorias IA",
    url: createPageUrl("CaseCategories"),
    icon: Brain,
    roles: ["admin", "editor"]
  },
  {
    title: "Resumo Diário",
    url: createPageUrl("DailyDigest"),
    icon: Mail,
    roles: ["admin", "editor", "viewer"]
  },
  {
    title: "Teste de Pesquisa",
    url: createPageUrl("TestePesquisa"),
    icon: TestTube,
    roles: ["admin"]
  },
  {
    title: "Administração",
    separator: true,
    roles: ["admin"]
  },
  {
    title: "Marca",
    url: createPageUrl("BrandCustomization"),
    icon: Palette,
    roles: ["admin"]
  },
  {
    title: "Arquitetura",
    url: createPageUrl("Architecture"),
    icon: Server,
    roles: ["admin"]
  },
  {
    title: "Documentação",
    url: createPageUrl("Documentation"),
    icon: FileText,
    roles: ["admin", "editor", "viewer"]
  },
  {
    title: "Pipeline",
    url: createPageUrl("Pipeline"),
    icon: Zap,
    roles: ["admin"]
  },
  {
    title: "Sincronização",
    url: createPageUrl("DataSync"),
    icon: DatabaseZap,
    roles: ["admin"]
  }
];

const hexToHsl = (hex) => {
    if (!hex) return "210 100% 12%";
    hex = hex.replace(/^#/, '');
    if (hex.length !== 6) return "210 100% 12%";

    const r = parseInt(hex.substring(0, 2), 16) / 255;
    const g = parseInt(hex.substring(2, 4), 16) / 255;
    const b = parseInt(hex.substring(4, 6), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;

    if (max === min) {
        h = s = 0;
    } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }
    return `${(h * 360).toFixed(0)} ${(s * 100).toFixed(0)}% ${(l * 100).toFixed(0)}%`;
};

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchUser() {
      try {
        const currentUser = await UserEntity.me();
        if (!currentUser.tenant) {
            currentUser.tenant = {
                name: "LexSearch",
                logo_url: "",
                brand_color_primary: "#0c2f57",
                brand_color_secondary: "#fbbF24"
            };
        } else {
            if (!currentUser.tenant.brand_color_primary) {
                currentUser.tenant.brand_color_primary = "#0c2f57";
            }
            if (!currentUser.tenant.brand_color_secondary) {
                currentUser.tenant.brand_color_secondary = "#fbbF24";
            }
        }
        currentUser.role = currentUser.role || "admin";
        setUser(currentUser);
      } catch (e) {
        console.error("Not logged in or error fetching user:", e);
        setUser({
            tenant: {
                name: "LexSearch",
                logo_url: "",
                brand_color_primary: "#0c2f57",
                brand_color_secondary: "#fbbF24"
            },
            role: "viewer"
        });
      } finally {
        setLoading(false);
      }
    }
    fetchUser();
  }, []);

  const tenant = user?.tenant || {
    name: "LexSearch",
    logo_url: "",
    brand_color_primary: "#0c2f57",
    brand_color_secondary: "#fbbF24"
  };
  const primaryColorHsl = hexToHsl(tenant.brand_color_primary);
  const secondaryColorHsl = hexToHsl(tenant.brand_color_secondary);

  const currentUserRole = user?.role;
  const navigationItems = allNavigationItems.filter(item =>
    item.roles.includes(currentUserRole)
  );

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-slate-50">
        <style>
          {`
            :root {
              --primary: ${primaryColorHsl};
              --primary-foreground: 210 20% 98%;
              --secondary: ${secondaryColorHsl};
              --secondary-foreground: 43 100% 11%;
              --accent: ${secondaryColorHsl};
              --accent-foreground: 43 100% 11%;
              --background: 0 0% 100%;
              --foreground: 210 24% 16%;
              --muted: 210 20% 96%;
              --muted-foreground: 210 12% 47%;
              --card: 0 0% 100%;
              --card-foreground: 210 24% 16%;
              --border: 210 20% 89%;
              --ring: ${primaryColorHsl};
            }
          `}
        </style>
        <Sidebar className="border-r border-slate-200 bg-white">
          <SidebarHeader className="border-b border-slate-100 p-6">
            {loading ? (
                <div className="flex items-center gap-3">
                    <Skeleton className="w-10 h-10 rounded-xl" />
                    <div className="space-y-2">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-32" />
                    </div>
                </div>
            ) : (
                <div className="flex items-center gap-3">
                  {tenant.logo_url ? (
                    <img src={tenant.logo_url} alt={`${tenant.name} Logo`} className="w-10 h-10 object-contain"/>
                  ) : (
                    <div
                      className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center shadow-lg"
                      style={{backgroundColor: tenant.brand_color_primary}}
                    >
                      <Scale className="w-5 h-5 text-primary-foreground" />
                    </div>
                  )}
                  <div>
                    <h2 className="font-bold text-slate-800 text-lg">{tenant.name || "LexSearch"}</h2>
                    <p className="text-xs text-slate-500 font-medium">Pesquisa Jurisprudencial</p>
                  </div>
                </div>
            )}
          </SidebarHeader>

          <SidebarContent className="p-4">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2 mb-2">
              Navegação
            </p>
            {navigationItems.map((item) => {
              if (item.separator) {
                return (
                  <div key={item.title} className="my-4 border-t border-slate-200 pt-4">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3">
                      {item.title}
                    </span>
                  </div>
                );
              } else {
                return (
                  <Link
                    key={item.title}
                    to={item.url}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 font-medium ${
                      location.pathname === item.url ? 'bg-blue-50 text-blue-800 border-r-2 border-blue-800' : 'text-slate-600 hover:bg-blue-50 hover:text-blue-800 transition-all duration-200'
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.title}</span>
                  </Link>
                );
              }
            })}

            <div className="mt-8">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2 mb-2">
                Ações Rápidas
              </p>
              <div className="px-3 space-y-2">
                <Link
                  to={createPageUrl("Search")}
                  className="flex items-center gap-3 px-3 py-2 text-sm text-slate-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-all duration-200"
                >
                  <PlusCircle className="w-4 h-4" />
                  Nova Pesquisa
                </Link>
              </div>
            </div>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-100 p-4">
            <div className="flex items-center gap-3 px-2">
              <div className="w-8 h-8 bg-gradient-to-br from-slate-400 to-slate-500 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-slate-700 text-sm truncate">
                  {user?.full_name || "Usuário"}
                </p>
                <p className="text-xs text-slate-500 truncate">
                  {user?.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : "Pesquisador Jurídico"}
                </p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b border-slate-200 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-bold text-slate-800">{tenant.name || "LexSearch"}</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto bg-gradient-to-br from-slate-50 to-slate-100">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

