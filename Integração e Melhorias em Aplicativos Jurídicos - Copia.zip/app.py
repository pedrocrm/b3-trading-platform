
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
import os
import json
import sqlite3
from datetime import datetime, timedelta
import hashlib
import openai
from werkzeug.utils import secure_filename
import PyPDF2
import io
import traceback
import time

app = Flask(__name__)
CORS(app, origins=["*"])  # Permitir todas as origens em desenvolvimento

# ====================================================================
# CONFIGURAÇÕES COM SUAS CHAVES REAIS
# ====================================================================

# CNJ DataJud - SUA CHAVE REAL
CNJ_API_KEY = "cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw=="
CNJ_BASE_URL = "https://api-publica.datajud.cnj.jus.br"

# OpenAI - SUA CHAVE REAL  
OPENAI_API_KEY = "sk-svcacct-dUa18gVbSIcLMKSMAxRgAll5zI_P0vL8eEnBMYF-TjhVo-C8mRFV90iXACxnHD6pjw4o2ESTrT3BlbkFJRqJ9aonvD72jVjKtq7S2KNsMpjtPy8SuOMBogvBBZ0PwkXLXnXeSfDoYBD0JX2kmbboPMMLeIkA"

# Configurar OpenAI
openai.api_key = OPENAI_API_KEY

# Configurações da aplicação
app.config["SECRET_KEY"] = "lexusai-prod-2024"
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16MB max file size

# ====================================================================
# CLASSE DE INTEGRAÇÃO CNJ DATAJUD - IMPLEMENTAÇÃO REAL
# ====================================================================

class CNJDataJudIntegration:
    def __init__(self):
        self.api_key = CNJ_API_KEY
        self.base_url = CNJ_BASE_URL
        self.headers = {
            "Authorization": f"APIKey {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        self.timeout = 30
        
    def test_connection(self):
        """Testar conexão com a API CNJ"""
        try:
            url = f"{self.base_url}/api_publica_tjsp/_search"
            payload = {"size": 1, "query": {"match_all": {}}}
            response = requests.post(url, headers=self.headers, json=payload, timeout=self.timeout)
            
            return {
                "success": response.status_code == 200,
                "status_code": response.status_code,
                "message": "Conexão CNJ OK" if response.status_code == 200 else f"Erro {response.status_code}"
            }
        except Exception as e:
            return {
                "success": False,
                "status_code": 0,
                "message": f"Erro de conexão: {str(e)}"
            }
    
    def buscar_processo_por_numero(self, numero_processo):
        """Buscar processo específico por número"""
        try:
            # Limpar e formatar número do processo
            numero_limpo = "".join(filter(str.isdigit, numero_processo))
            
            url = f"{self.base_url}/api/v1/processos"
            params = {
                "numeroProcesso": numero_processo,
                "size": 1
            }
            
            response = requests.get(url, headers=self.headers, params=params, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("hits", {}).get("total", {}).get("value", 0) > 0:
                    processo = data["hits"]["hits"][0]["_source"]
                    return {
                        "success": True,
                        "processo": self._formatar_processo(processo),
                        "fonte": "CNJ DataJud"
                    }
                else:
                    return {
                        "success": False,
                        "error": "Processo não encontrado no DataJud",
                        "codigo": "NOT_FOUND"
                    }
            else:
                return {
                    "success": False,
                    "error": f"Erro na API CNJ: {response.status_code}",
                    "detalhes": response.text
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": f"Erro na consulta: {str(e)}",
                "trace": traceback.format_exc()
            }
    
    def buscar_jurisprudencia(self, termo_busca, tribunal=None, limite=20):
        """Buscar jurisprudência por termo"""
        try:
            url = f"{self.base_url}/api/v1/decisoes"
            params = {
                "q": termo_busca,
                "size": limite,
                "sort": "dataJulgamento:desc"
            }
            
            if tribunal:
                params["tribunal"] = tribunal
            
            response = requests.get(url, headers=self.headers, params=params, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                decisoes = []
                
                for hit in data.get("hits", {}).get("hits", []):
                    decisao = hit.get("_source", {})
                    decisoes.append(self._formatar_decisao(decisao))
                
                return {
                    "success": True,
                    "decisoes": decisoes,
                    "total": data.get("hits", {}).get("total", {}).get("value", 0),
                    "termo_busca": termo_busca
                }
            else:
                return {
                    "success": False,
                    "error": f"Erro na busca: {response.status_code}",
                    "detalhes": response.text
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": f"Erro na busca: {str(e)}",
                "trace": traceback.format_exc()
            }
    
    def obter_estatisticas_tribunal(self, tribunal, data_inicio=None, data_fim=None):
        """Obter estatísticas do tribunal"""
        try:
            url = f"{self.base_url}/api/v1/estatisticas"
            params = {
                "tribunal": tribunal
            }
            
            if data_inicio:
                params["dataInicio"] = data_inicio
            if data_fim:
                params["dataFim"] = data_fim
            
            response = requests.get(url, headers=self.headers, params=params, timeout=self.timeout)
            
            if response.status_code == 200:
                return {
                    "success": True,
                    "estatisticas": response.json()
                }
            else:
                return {
                    "success": False,
                    "error": f"Erro nas estatísticas: {response.status_code}"
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": f"Erro: {str(e)}"
            }
    
    def listar_tribunais(self):
        """Listar todos os tribunais disponíveis"""
        try:
            url = f"{self.base_url}/api/v1/tribunais"
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            
            if response.status_code == 200:
                return {
                    "success": True,
                    "tribunais": response.json()
                }
            else:
                return {
                    "success": False,
                    "error": f"Erro ao listar tribunais: {response.status_code}"
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": f"Erro: {str(e)}"
            }
    
    def _formatar_processo(self, processo_raw):
        """Formatar dados do processo para exibição"""
        return {
            "numero": processo_raw.get("numeroProcesso", "N/A"),
            "classe": processo_raw.get("classe", {}).get("nome", "N/A"),
            "assunto": processo_raw.get("assunto", {}).get("nome", "N/A"),
            "tribunal": processo_raw.get("tribunal", "N/A"),
            "orgaoJulgador": processo_raw.get("orgaoJulgador", {}).get("nome", "N/A"),
            "dataDistribuicao": processo_raw.get("dataDistribuicao", "N/A"),
            "situacao": processo_raw.get("situacao", "N/A"),
            "valor": processo_raw.get("valor", "N/A"),
            "partes": self._extrair_partes(processo_raw.get("partes", [])),
            "movimentacoes": self._extrair_movimentacoes(processo_raw.get("movimentacoes", []))
        }
    
    def _formatar_decisao(self, decisao_raw):
        """Formatar dados da decisão para exibição"""
        return {
            "id": decisao_raw.get("id", ""),
            "tribunal": decisao_raw.get("tribunal", "N/A"),
            "relator": decisao_raw.get("relator", "N/A"),
            "dataJulgamento": decisao_raw.get("dataJulgamento", "N/A"),
            "ementa": decisao_raw.get("ementa", "N/A")[:500] + "..." if len(decisao_raw.get("ementa", "")) > 500 else decisao_raw.get("ementa", "N/A"),
            "classe": decisao_raw.get("classe", "N/A"),
            "assunto": decisao_raw.get("assunto", "N/A")
        }
    
    def _extrair_partes(self, partes_raw):
        """Extrair e formatar partes do processo"""
        partes = []
        for parte in partes_raw[:10]:  # Limite de 10 partes
            partes.append({
                "nome": parte.get("nome", "N/A"),
                "tipo": parte.get("tipo", "N/A"),
                "documento": parte.get("documento", "N/A")
            })
        return partes
    
    def _extrair_movimentacoes(self, movimentacoes_raw):
        """Extrair últimas movimentações"""
        movimentacoes = []
        for mov in movimentacoes_raw[:5]:  # Últimas 5 movimentações
            movimentacoes.append({
                "data": mov.get("data", "N/A"),
                "descricao": mov.get("descricao", "N/A"),
                "responsavel": mov.get("responsavel", "N/A")
            })
        return sorted(movimentacoes, key=lambda x: x["data"], reverse=True)

# Instanciar integração CNJ
cnj = CNJDataJudIntegration()

# ====================================================================
# CLASSE DE IA JURÍDICA INTEGRADA COM CNJ
# ====================================================================

class LexusaiIA:
    def __init__(self):
        self.client = openai
        self.cache = {}  # Cache simples para otimização
        
    def consulta_com_datajud(self, pergunta_usuario, contexto_adicional=None):
        """IA integrada com dados CNJ DataJud"""
        try:
            # 1. Extrair termos jurídicos relevantes
            termos = self._extrair_termos_juridicos(pergunta_usuario)
            
            # 2. Buscar dados relevantes no CNJ (se houver termos)
            dados_cnj = []
            if termos:
                for termo in termos[:2]:  # Máximo 2 consultas por pergunta
                    resultado = cnj.buscar_jurisprudencia(termo, limite=5)
                    if resultado["success"]:
                        dados_cnj.extend(resultado["decisoes"])
            
            # 3. Construir prompt enriquecido
            prompt_sistema = self._construir_prompt_sistema(dados_cnj, contexto_adicional)
            
            # 4. Gerar resposta com OpenAI
            response = self.client.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": prompt_sistema},
                    {"role": "user", "content": pergunta_usuario}
                ],
                max_tokens=1000,
                temperature=0.7,
                timeout=30
            )
            
            resposta = response.choices[0].message.content
            
            # 5. Adicionar informações sobre fontes CNJ
            if dados_cnj:
                resposta += f"\n\n📊 **Baseado em {len(dados_cnj)} decisão(ões) oficial(is) do CNJ DataJud**"
            
            return {
                "success": True,
                "resposta": resposta,
                "fontes_cnj": len(dados_cnj),
                "termos_buscados": termos
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Erro na IA: {str(e)}",
                "trace": traceback.format_exc()
            }
    
    def analisar_documento_com_jurisprudencia(self, texto_documento):
        """Analisar documento legal com jurisprudência CNJ"""
        try:
            # Extrair conceitos jurídicos principais
            conceitos = self._extrair_conceitos_documento(texto_documento)
            
            # Buscar jurisprudência relevante
            jurisprudencia = []
            for conceito in conceitos[:3]:
                resultado = cnj.buscar_jurisprudencia(conceito, limite=3)
                if resultado["success"]:
                    jurisprudencia.extend(resultado["decisoes"])
            
            # Análise com IA
            prompt_analise = f"""Analise o documento jurídico abaixo considerando a jurisprudência brasileira recente.\n\nJURISPRUDÊNCIA RELEVANTE (CNJ DataJud):\n{json.dumps(jurisprudencia, indent=2, ensure_ascii=False) if jurisprudencia else 'Nenhuma jurisprudência específica encontrada'}\n\nDOCUMENTO A ANALISAR:\n{texto_documento[:3000]}\n\nForneça uma análise estruturada com:\n1. RESUMO EXECUTIVO\n2. PRINCIPAIS RISCOS JURÍDICOS\n3. PONTOS FORTES\n4. RECOMENDAÇÕES\n5. JURISPRUDÊNCIA APLICÁVEL\n\nSeja preciso e cite sempre que usar dados da jurisprudência CNJ."""

            response = self.client.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Você é um especialista em análise jurídica com acesso aos dados oficiais do CNJ."},
                    {"role": "user", "content": prompt_analise}
                ],
                max_tokens=1500,
                temperature=0.5
            )
            
            return {
                "success": True,
                "analise": response.choices[0].message.content,
                "jurisprudencia_usada": len(jurisprudencia),
                "conceitos_analisados": conceitos
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Erro na análise: {str(e)}"
            }
    
    def _construir_prompt_sistema(self, dados_cnj, contexto_adicional):
        """Construir prompt do sistema com dados CNJ"""
        prompt_base = """Você é a Lexusai, uma IA jurídica especializada em direito brasileiro.\nVocê tem acesso aos dados oficiais do CNJ via DataJud e deve sempre priorizar informações oficiais.\n\nINSTRUÇÕES:\n- Sempre mencione quando usar dados oficiais CNJ\n- Seja preciso e técnico, mas acessível\n- Cite artigos de lei quando relevante\n- Indique quando a resposta é baseada em jurisprudência atual"""

        if dados_cnj:
            prompt_base += f"""\n\nJURISPRUDÊNCIA OFICIAL CNJ DISPONÍVEL:\n{json.dumps(dados_cnj, indent=2, ensure_ascii=False)}\n\nUse essas decisões para fundamentar sua resposta quando relevante."""

        if contexto_adicional:
            prompt_base += f"""\n\nCONTEXTO ADICIONAL:\n{contexto_adicional}"""

        return prompt_base
    
    def _extrair_termos_juridicos(self, texto):
        """Extrair termos jurídicos para busca no CNJ"""
        termos_juridicos = [
            "responsabilidade civil", "dano moral", "indenização", "lucros cessantes",
            "direito do trabalho", "rescisão indireta", "horas extras", "adicional noturno",
            "direito penal", "homicídio", "furto", "roubo", "estelionato",
            "direito tributário", "ICMS", "ISS", "IPTU", "IPI", "COFINS",
            "direito empresarial", "falência", "recuperação judicial", "dissolução societária",
            "direito civil", "contrato", "responsabilidade contratual", "vício redibitório",
            "direito administrativo", "licitação", "concurso público", "servidor público",
            "direito constitucional", "habeas corpus", "mandado de segurança", "ação direta"
        ]
        
        texto_lower = texto.lower()
        termos_encontrados = []
        
        for termo in termos_juridicos:
            if termo in texto_lower:
                termos_encontrados.append(termo)
        
        return termos_encontrados[:3]
    
    def _extrair_conceitos_documento(self, texto):
        """Extrair conceitos chave de um documento usando IA"""
        try:
            response = self.client.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Você é um assistente que extrai os 5 principais conceitos jurídicos de um texto."},
                    {"role": "user", "content": f"Extraia os 5 principais conceitos jurídicos do seguinte texto: {texto[:2000]}"}
                ],
                max_tokens=100,
                temperature=0.3
            )
            conceitos = response.choices[0].message.content.split(", ")
            return conceitos
        except Exception as e:
            print(f"Erro ao extrair conceitos: {e}")
            return []

# Instanciar IA
lexusai_ia = LexusaiIA()

# ====================================================================
# ROTAS DA API
# ====================================================================

@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Bem-vindo à API LexusAI!"})

@app.route("/cnj/test_connection", methods=["GET"])
def cnj_test_connection():
    result = cnj.test_connection()
    return jsonify(result)

@app.route("/cnj/processo/<numero_processo>", methods=["GET"])
def cnj_buscar_processo(numero_processo):
    result = cnj.buscar_processo_por_numero(numero_processo)
    return jsonify(result)

@app.route("/cnj/jurisprudencia", methods=["POST"])
def cnj_buscar_jurisprudencia():
    data = request.get_json()
    termo_busca = data.get("termo_busca")
    tribunal = data.get("tribunal")
    limite = data.get("limite", 20)
    
    if not termo_busca:
        return jsonify({"success": False, "error": "Termo de busca é obrigatório."}), 400
        
    result = cnj.buscar_jurisprudencia(termo_busca, tribunal, limite)
    return jsonify(result)

@app.route("/cnj/tribunais", methods=["GET"])
def cnj_listar_tribunais():
    result = cnj.listar_tribunais()
    return jsonify(result)

@app.route("/ia/consulta", methods=["POST"])
def ia_consulta():
    data = request.get_json()
    pergunta_usuario = data.get("pergunta")
    contexto_adicional = data.get("contexto_adicional")
    
    if not pergunta_usuario:
        return jsonify({"success": False, "error": "A pergunta do usuário é obrigatória."}), 400
        
    result = lexusai_ia.consulta_com_datajud(pergunta_usuario, contexto_adicional)
    return jsonify(result)

@app.route("/ia/analisar_documento", methods=["POST"])
def ia_analisar_documento():
    if "file" not in request.files:
        return jsonify({"success": False, "error": "Nenhum arquivo enviado."}), 400
    
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"success": False, "error": "Nome de arquivo inválido."}), 400
        
    if file and file.filename.endswith(".pdf"):
        try:
            reader = PyPDF2.PdfReader(io.BytesIO(file.read()))
            text = ""
            for page in reader.pages:
                text += page.extract_text() or ""
            
            result = lexusai_ia.analisar_documento_com_jurisprudencia(text)
            return jsonify(result)
            
        except Exception as e:
            return jsonify({"success": False, "error": f"Erro ao processar PDF: {str(e)}", "trace": traceback.format_exc()}), 500
    else:
        return jsonify({"success": False, "error": "Formato de arquivo não suportado. Apenas PDF."}), 400

# ====================================================================
# ROTAS DE AUTENTICAÇÃO E USUÁRIOS (SIMPLIFICADAS PARA EXEMPLO)
# ====================================================================

USERS_DB = "users.db"

def init_db():
    conn = sqlite3.connect(USERS_DB)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        api_key TEXT UNIQUE NOT NULL,
        created_at TEXT
    )""")
    conn.commit()
    conn.close()

init_db()

def generate_api_key(username):
    return hashlib.sha256(f"{username}{datetime.now()}".encode()).hexdigest()

@app.route("/auth/register", methods=["POST"])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"success": False, "message": "Nome de usuário e senha são obrigatórios."}), 400

    conn = sqlite3.connect(USERS_DB)
    c = conn.cursor()
    
    try:
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        api_key = generate_api_key(username)
        created_at = datetime.now().isoformat()
        
        c.execute("INSERT INTO users (username, password_hash, api_key, created_at) VALUES (?, ?, ?, ?)",
                  (username, password_hash, api_key, created_at))
        conn.commit()
        return jsonify({"success": True, "message": "Usuário registrado com sucesso!", "api_key": api_key}), 201
    except sqlite3.IntegrityError:
        return jsonify({"success": False, "message": "Nome de usuário já existe."}), 409
    except Exception as e:
        return jsonify({"success": False, "message": f"Erro ao registrar usuário: {str(e)}"}), 500
    finally:
        conn.close()

@app.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"success": False, "message": "Nome de usuário e senha são obrigatórios."}), 400

    conn = sqlite3.connect(USERS_DB)
    c = conn.cursor()
    c.execute("SELECT password_hash, api_key FROM users WHERE username = ?", (username,))
    user_data = c.fetchone()
    conn.close()

    if user_data and user_data[0] == hashlib.sha256(password.encode()).hexdigest():
        return jsonify({"success": True, "message": "Login bem-sucedido!", "api_key": user_data[1]}), 200
    else:
        return jsonify({"success": False, "message": "Nome de usuário ou senha inválidos."}), 401

@app.route("/auth/me", methods=["GET"])
def get_current_user():
    api_key = request.headers.get("X-API-Key")
    if not api_key:
        return jsonify({"success": False, "message": "API Key ausente."}), 401

    conn = sqlite3.connect(USERS_DB)
    c = conn.cursor()
    c.execute("SELECT username FROM users WHERE api_key = ?", (api_key,))
    user_data = c.fetchone()
    conn.close()

    if user_data:
        return jsonify({"success": True, "username": user_data[0]}), 200
    else:
        return jsonify({"success": False, "message": "API Key inválida."}), 401

# ====================================================================
# ROTAS DE PASTAS E DOCUMENTOS (SIMPLIFICADAS PARA EXEMPLO)
# ====================================================================

FOLDERS_DB = "folders.db"

def init_folders_db():
    conn = sqlite3.connect(FOLDERS_DB)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_api_key TEXT NOT NULL,
        name TEXT NOT NULL,
        created_at TEXT,
        UNIQUE(user_api_key, name)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        folder_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT,
        FOREIGN KEY (folder_id) REFERENCES folders(id)
    )""")
    conn.commit()
    conn.close()

init_folders_db()

@app.route("/folders", methods=["GET"])
def list_folders():
    api_key = request.headers.get("X-API-Key")
    if not api_key:
        return jsonify({"success": False, "message": "API Key ausente."}), 401

    conn = sqlite3.connect(FOLDERS_DB)
    c = conn.cursor()
    c.execute("SELECT id, name, created_at FROM folders WHERE user_api_key = ?", (api_key,))
    folders = [{
        "id": row[0],
        "name": row[1],
        "created_at": row[2]
    } for row in c.fetchall()]
    conn.close()
    return jsonify({"success": True, "folders": folders}), 200

@app.route("/folders", methods=["POST"])
def create_folder():
    api_key = request.headers.get("X-API-Key")
    if not api_key:
        return jsonify({"success": False, "message": "API Key ausente."}), 401

    data = request.get_json()
    name = data.get("name")

    if not name:
        return jsonify({"success": False, "message": "Nome da pasta é obrigatório."}), 400

    conn = sqlite3.connect(FOLDERS_DB)
    c = conn.cursor()
    try:
        created_at = datetime.now().isoformat()
        c.execute("INSERT INTO folders (user_api_key, name, created_at) VALUES (?, ?, ?)",
                  (api_key, name, created_at))
        conn.commit()
        return jsonify({"success": True, "message": "Pasta criada com sucesso!", "id": c.lastrowid}), 201
    except sqlite3.IntegrityError:
        return jsonify({"success": False, "message": "Pasta com este nome já existe."}), 409
    except Exception as e:
        return jsonify({"success": False, "message": f"Erro ao criar pasta: {str(e)}"}), 500
    finally:
        conn.close()

@app.route("/folders/<int:folder_id>/documents", methods=["GET"])
def list_documents_in_folder(folder_id):
    api_key = request.headers.get("X-API-Key")
    if not api_key:
        return jsonify({"success": False, "message": "API Key ausente."}), 401

    conn = sqlite3.connect(FOLDERS_DB)
    c = conn.cursor()
    
    # Verificar se a pasta pertence ao usuário
    c.execute("SELECT id FROM folders WHERE id = ? AND user_api_key = ?", (folder_id, api_key))
    if not c.fetchone():
        conn.close()
        return jsonify({"success": False, "message": "Pasta não encontrada ou não pertence ao usuário."}), 404

    c.execute("SELECT id, title, created_at FROM documents WHERE folder_id = ?", (folder_id,))
    documents = [{
        "id": row[0],
        "title": row[1],
        "created_at": row[2]
    } for row in c.fetchall()]
    conn.close()
    return jsonify({"success": True, "documents": documents}), 200

@app.route("/folders/<int:folder_id>/documents", methods=["POST"])
def add_document_to_folder(folder_id):
    api_key = request.headers.get("X-API-Key")
    if not api_key:
        return jsonify({"success": False, "message": "API Key ausente."}), 401

    data = request.get_json()
    title = data.get("title")
    content = data.get("content")

    if not title or not content:
        return jsonify({"success": False, "message": "Título e conteúdo do documento são obrigatórios."}), 400

    conn = sqlite3.connect(FOLDERS_DB)
    c = conn.cursor()
    try:
        # Verificar se a pasta pertence ao usuário
        c.execute("SELECT id FROM folders WHERE id = ? AND user_api_key = ?", (folder_id, api_key))
        if not c.fetchone():
            conn.close()
            return jsonify({"success": False, "message": "Pasta não encontrada ou não pertence ao usuário."}), 404

        created_at = datetime.now().isoformat()
        c.execute("INSERT INTO documents (folder_id, title, content, created_at) VALUES (?, ?, ?, ?)",
                  (folder_id, title, content, created_at))
        conn.commit()
        return jsonify({"success": True, "message": "Documento adicionado com sucesso!", "id": c.lastrowid}), 201
    except Exception as e:
        return jsonify({"success": False, "message": f"Erro ao adicionar documento: {str(e)}"}), 500
    finally:
        conn.close()

@app.route("/documents/<int:document_id>", methods=["GET"])
def get_document_content(document_id):
    api_key = request.headers.get("X-API-Key")
    if not api_key:
        return jsonify({"success": False, "message": "API Key ausente."}), 401

    conn = sqlite3.connect(FOLDERS_DB)
    c = conn.cursor()
    
    # Verificar se o documento pertence ao usuário (via pasta)
    c.execute("""SELECT d.title, d.content, d.created_at 
                   FROM documents d 
                   JOIN folders f ON d.folder_id = f.id 
                   WHERE d.id = ? AND f.user_api_key = ?""", (document_id, api_key))
    document_data = c.fetchone()
    conn.close()

    if document_data:
        return jsonify({
            "success": True,
            "title": document_data[0],
            "content": document_data[1],
            "created_at": document_data[2]
        }), 200
    else:
        return jsonify({"success": False, "message": "Documento não encontrado ou não pertence ao usuário."}), 404

# ====================================================================
# ROTAS DE CATEGORIAS DE IA E RESUMO DIÁRIO (SIMPLIFICADAS PARA EXEMPLO)
# ====================================================================

@app.route("/ia/categorias", methods=["POST"])
def ia_categorizar_texto():
    data = request.get_json()
    texto = data.get("texto")

    if not texto:
        return jsonify({"success": False, "error": "Texto para categorização é obrigatório."}), 400

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Você é um assistente que categoriza textos jurídicos em uma das seguintes categorias: Direito Civil, Direito Penal, Direito do Trabalho, Direito Tributário, Direito Administrativo, Direito Constitucional, Direito Empresarial. Retorne apenas a categoria mais relevante."},
                {"role": "user", "content": f"Categorize o seguinte texto jurídico: {texto[:1000]}"}
            ],
            max_tokens=20,
            temperature=0.2
        )
        categoria = response.choices[0].message.content.strip()
        return jsonify({"success": True, "categoria": categoria}), 200
    except Exception as e:
        return jsonify({"success": False, "error": f"Erro ao categorizar texto: {str(e)}"}), 500

@app.route("/ia/resumo_diario", methods=["POST"])
def ia_resumo_diario():
    data = request.get_json()
    processos_recentes = data.get("processos_recentes") # Lista de processos ou eventos

    if not processos_recentes:
        return jsonify({"success": False, "error": "Dados de processos recentes são obrigatórios."}), 400

    try:
        prompt = f"""Crie um resumo diário conciso e relevante para um advogado, com base nos seguintes processos/eventos recentes:
{json.dumps(processos_recentes, indent=2, ensure_ascii=False)}

Inclua os pontos mais importantes, tendências e ações recomendadas. O resumo deve ser profissional e direto ao ponto."""

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Você é um assistente jurídico que gera resumos diários para advogados."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            temperature=0.7
        )
        resumo = response.choices[0].message.content.strip()
        return jsonify({"success": True, "resumo": resumo}), 200
    except Exception as e:
        return jsonify({"success": False, "error": f"Erro ao gerar resumo diário: {str(e)}"}), 500

# ====================================================================
# ROTAS DE CHANCE DE ÊXITO E TENDÊNCIAS (SIMPLIFICADAS PARA EXEMPLO)
# ====================================================================

@app.route("/analise/chance_exito", methods=["POST"])
def analisar_chance_exito():
    data = request.get_json()
    contexto_caso = data.get("contexto_caso")

    if not contexto_caso:
        return jsonify({"success": False, "error": "Contexto do caso é obrigatório."}), 400

    try:
        # Exemplo simplificado: IA analisa o contexto e dá uma chance de êxito
        prompt = f"""Analise o seguinte contexto de caso jurídico e estime a chance de êxito (em porcentagem) para o lado do autor, justificando brevemente. Contexto: {contexto_caso}"""
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Você é um especialista em análise de casos jurídicos e estima chances de êxito."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=100,
            temperature=0.5
        )
        analise = response.choices[0].message.content.strip()
        return jsonify({"success": True, "analise": analise}), 200
    except Exception as e:
        return jsonify({"success": False, "error": f"Erro ao analisar chance de êxito: {str(e)}"}), 500

@app.route("/analise/tendencias", methods=["POST"])
def analisar_tendencias():
    data = request.get_json()
    tema_juridico = data.get("tema_juridico")

    if not tema_juridico:
        return jsonify({"success": False, "error": "Tema jurídico é obrigatório."}), 400

    try:
        # Exemplo simplificado: IA analisa tendências com base em um tema
        prompt = f"""Descreva as principais tendências jurisprudenciais e doutrinárias recentes sobre o tema jurídico: {tema_juridico}. Inclua casos relevantes se possível."""
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Você é um analista de tendências jurídicas."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=300,
            temperature=0.7
        )
        tendencias = response.choices[0].message.content.strip()
        return jsonify({"success": True, "tendencias": tendencias}), 200
    except Exception as e:
        return jsonify({"success": False, "error": f"Erro ao analisar tendências: {str(e)}"}), 500


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)

