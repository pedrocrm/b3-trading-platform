import { base44 } from './base44Client';


export const checkCNJStatus = base44.functions.checkCNJStatus;

export const consultarProcesso = base44.functions.consultarProcesso;

export const buscarJurisprudencia = base44.functions.buscarJurisprudencia;

export const gerarRelatorio = base44.functions.gerarRelatorio;

export const anthropicBatch = base44.functions.anthropicBatch;

export const sistemaHealth = base44.functions.sistemaHealth;

export const logSistema = base44.functions.logSistema;

export const consultarPorDocumento = base44.functions.consultarPorDocumento;

export const buscaAvancada = base44.functions.buscaAvancada;

export const filtrosJurimetricos = base44.functions.filtrosJurimetricos;

export const indiceSemantico = base44.functions.indiceSemantico;

export const analisarTendencias = base44.functions.analisarTendencias;

export const analisarChancesExito = base44.functions.analisarChancesExito;

