
import React from 'react';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Scale, BarChart, Bot } from 'lucide-react';

export default function HomePage() {
    return (
        <div className="bg-slate-50 font-sans">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white">
                <div className="max-w-7xl mx-auto px-6 py-24 md:py-32 text-center">
                    <div className="animate-fadeIn">
                        <div className="inline-flex items-center bg-white/20 px-4 py-2 rounded-full text-sm font-semibold mb-6">
                            <span className="w-2 h-2 bg-green-300 rounded-full mr-2 animate-pulse-slow"></span>
                            🏛️ Integração Oficial CNJ DataJud
                        </div>
                        
                        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
                            LegalTech AI
                            <br /><span className="text-yellow-300">IA Jurídica Oficial</span>
                        </h1>
                        
                        <p className="text-xl md:text-2xl mb-8 opacity-90 max-w-4xl mx-auto">
                            A primeira IA jurídica do Brasil com acesso aos
                            <br /><strong className="text-yellow-200">dados oficiais do CNJ via DataJud</strong>
                        </p>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10 max-w-3xl mx-auto">
                            <div className="text-center"><div className="text-3xl font-bold">2.5M+</div><div className="text-sm opacity-80">Processos CNJ</div></div>
                            <div className="text-center"><div className="text-3xl font-bold">90+</div><div className="text-sm opacity-80">Tribunais</div></div>
                            <div className="text-center"><div className="text-3xl font-bold">24/7</div><div className="text-sm opacity-80">Disponível</div></div>
                            <div className="text-center"><div className="text-3xl font-bold">100%</div><div className="text-sm opacity-80">Dados Oficiais</div></div>
                        </div>
                        
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Link to={createPageUrl("Chat")}>
                                <Button size="lg" className="w-full sm:w-auto bg-white text-blue-600 font-bold text-lg hover:bg-slate-100 transition-colors shadow-lg">
                                    <Bot className="w-5 h-5 mr-3" /> Conversar com IA + CNJ
                                </Button>
                            </Link>
                            <Link to={createPageUrl("Processo")}>
                                <Button size="lg" variant="outline" className="w-full sm:w-auto border-2 border-white text-white font-bold text-lg hover:bg-white hover:text-blue-600 transition-colors">
                                    🔍 Consultar Processos
                                </Button>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>

            {/* Features Section */}
            <div className="py-24 bg-white">
                <div className="max-w-6xl mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
                            Por que escolher a LegalTech AI?
                        </h2>
                        <p className="text-xl text-slate-600 max-w-3xl mx-auto">
                            A única IA jurídica com dados oficiais do CNJ, para máxima performance e confiabilidade.
                        </p>
                    </div>
                    
                    <div className="grid md:grid-cols-3 gap-8">
                        <Card className="text-center p-8 rounded-2xl bg-blue-50 border border-blue-100 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                            <CardHeader className="p-0">
                                <div className="bg-blue-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-white text-3xl">
                                    <Scale />
                                </div>
                                <CardTitle className="text-2xl font-bold mb-4 text-slate-900">Dados Oficiais CNJ</CardTitle>
                            </CardHeader>
                            <CardContent className="p-0">
                                <p className="text-slate-600 leading-relaxed">
                                    Acesso direto aos dados de todos os tribunais brasileiros via integração certificada DataJud do Conselho Nacional de Justiça.
                                </p>
                            </CardContent>
                        </Card>
                        
                        <Card className="text-center p-8 rounded-2xl bg-green-50 border border-green-100 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                             <CardHeader className="p-0">
                                <div className="bg-emerald-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-white text-3xl">
                                    <BarChart />
                                </div>
                                <CardTitle className="text-2xl font-bold mb-4 text-slate-900">Jurisprudência Atualizada</CardTitle>
                            </CardHeader>
                            <CardContent className="p-0">
                                <p className="text-slate-600 leading-relaxed">
                                    Consulte decisões recentes, tendências dos tribunais e estatísticas atualizadas em tempo real para fundamentar seus argumentos.
                                </p>
                            </CardContent>
                        </Card>
                        
                        <Card className="text-center p-8 rounded-2xl bg-purple-50 border border-purple-100 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                             <CardHeader className="p-0">
                                <div className="bg-purple-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-white text-3xl">
                                    <Bot />
                                </div>
                                <CardTitle className="text-2xl font-bold mb-4 text-slate-900">IA GPT-4 Especializada</CardTitle>
                            </CardHeader>
                            <CardContent className="p-0">
                                <p className="text-slate-600 leading-relaxed">
                                    Nossa IA analisa milhões de processos reais para fornecer insights precisos e estratégias baseadas em dados concretos.
                                </p>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>

            {/* Hosting Badge */}
            <div className="py-12 bg-slate-100">
                <div className="max-w-4xl mx-auto px-4 text-center">
                    <div className="inline-flex items-center bg-white px-6 py-3 rounded-full shadow-sm border">
                        <span className="w-3 h-3 bg-green-400 rounded-full mr-3 animate-pulse"></span>
                        <span className="text-slate-700 font-medium">Hospedado na</span>
                        <span className="text-blue-600 font-bold ml-2">Base44</span>
                        <span className="text-slate-500 ml-2">• Alta Performance • 99.9% Uptime</span>
                    </div>
                </div>
            </div>
        </div>
    );
}
