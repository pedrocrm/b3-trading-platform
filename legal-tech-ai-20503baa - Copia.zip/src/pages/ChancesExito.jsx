
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Target, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Brain, Lightbulb, Loader2 } from 'lucide-react';
import { ChanceExito } from '@/api/entities';
import { analisarChancesExito } from '@/api/functions';

export default function ChancesExitoPage() {
    const [analises, setAnalises] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showForm, setShowForm] = useState(false);
    
    // Form states
    const [teseJuridica, setTeseJuridica] = useState('');
    const [tribunalAlvo, setTribunalAlvo] = useState('');
    const [areaDireito, setAreaDireito] = useState('');

    useEffect(() => {
        loadAnalises();
    }, []);

    const loadAnalises = async () => {
        try {
            const data = await ChanceExito.list('-created_date', 20);
            setAnalises(data);
        } catch (error) {
            console.error('Erro ao carregar análises:', error);
        }
    };

    const handleNovaAnalise = async () => {
        if (!teseJuridica.trim() || !tribunalAlvo) {
            alert('Preencha a tese jurídica e o tribunal alvo.');
            return;
        }

        setLoading(true);
        try {
            const { data } = await analisarChancesExito({
                tese_juridica: teseJuridica,
                tribunal_alvo: tribunalAlvo,
                area_direito: areaDireito
            });

            console.log('Resposta da análise:', data); // Debug

            if (data.success) {
                await loadAnalises();
                setShowForm(false);
                setTeseJuridica('');
                setTribunalAlvo('');
                setAreaDireito('');
                
                // Mostrar resumo da análise
                const analise = data.analise || {};
                alert(`✅ Análise de chances de êxito concluída!

📊 Probabilidade de Êxito: ${analise.probabilidade_exito || 'N/A'}%
📈 Precedentes Analisados: ${analise.precedentes_total || 'N/A'}
⚖️ Precedentes Favoráveis: ${analise.precedentes_favoraveis || 0}
❌ Precedentes Desfavoráveis: ${analise.precedentes_desfavoraveis || 0}
🎯 Nível de Confiança: ${(analise.confidence_level || 'media').toUpperCase()}

${data.message || 'Análise processada com êxito'}`);
            } else {
                throw new Error(data?.message || 'Erro na análise');
            }
        } catch (error) {
            console.error('Erro na análise:', error);
            
            let errorMessage = 'Erro desconhecido';
            if (error.response?.data?.message) {
                errorMessage = error.response.data.message;
            } else if (error.message) {
                errorMessage = error.message;
            }
            
            alert(`❌ Erro na análise: ${errorMessage}

💡 Dicas:
- Verifique se o termo existe na jurisprudência
- Tente termos mais gerais (ex: "dano moral" em vez de "dano moral por negativação indevida")
- Teste com outros tribunais`);
        } finally {
            setLoading(false);
        }
    };

    const getProbabilidadeColor = (prob) => {
        if (prob >= 70) return 'text-green-600 bg-green-100';
        if (prob >= 50) return 'text-yellow-600 bg-yellow-100';
        return 'text-red-600 bg-red-100';
    };

    const getProbabilidadeIcon = (prob) => {
        if (prob >= 70) return <TrendingUp className="w-5 h-5" />;
        if (prob >= 50) return <Target className="w-5 h-5" />;
        return <TrendingDown className="w-5 h-5" />;
    };

    const getConfidenceColor = (level) => {
        switch (level) {
            case 'alta': return 'bg-green-100 text-green-800 border-green-200';
            case 'media': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            default: return 'bg-red-100 text-red-800 border-red-200';
        }
    };

    return (
        <div className="py-8 bg-gradient-to-br from-slate-50 to-green-50 min-h-screen">
            <div className="max-w-7xl mx-auto px-4">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-slate-900 mb-3 flex items-center gap-3">
                        <Target className="w-10 h-10 text-green-600" />
                        Análise de Chances de Êxito
                    </h1>
                    <p className="text-xl text-slate-600">
                        IA especializada que analisa a probabilidade de sucesso de suas teses jurídicas
                    </p>
                </div>

                {/* Nova Análise Button */}
                <div className="mb-8">
                    <Button 
                        onClick={() => setShowForm(!showForm)}
                        size="lg"
                        className="bg-green-600 hover:bg-green-700"
                    >
                        <Brain className="w-5 h-5 mr-2" />
                        Nova Análise IA
                    </Button>
                </div>

                {/* Formulário Nova Análise */}
                {showForm && (
                    <Card className="mb-8">
                        <CardHeader>
                            <CardTitle className="text-xl text-green-800">
                                Configurar Nova Análise
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-2">Tese Jurídica *</label>
                                <Textarea
                                    placeholder="Descreva detalhadamente a tese jurídica que deseja analisar..."
                                    value={teseJuridica}
                                    onChange={(e) => setTeseJuridica(e.target.value)}
                                    rows={4}
                                    className="w-full"
                                />
                            </div>
                            
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium mb-2">Tribunal Alvo *</label>
                                    <Select value={tribunalAlvo} onValueChange={setTribunalAlvo}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Selecione o tribunal" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="tjsp">TJSP - São Paulo</SelectItem>
                                            <SelectItem value="tjrj">TJRJ - Rio de Janeiro</SelectItem>
                                            <SelectItem value="tjmg">TJMG - Minas Gerais</SelectItem>
                                            <SelectItem value="tjrs">TJRS - Rio Grande do Sul</SelectItem>
                                            <SelectItem value="tjpr">TJPR - Paraná</SelectItem>
                                            <SelectItem value="tjsc">TJSC - Santa Catarina</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-2">Área do Direito</label>
                                    <Select value={areaDireito} onValueChange={setAreaDireito}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Área (opcional)" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="civil">Civil</SelectItem>
                                            <SelectItem value="trabalhista">Trabalhista</SelectItem>
                                            <SelectItem value="tributario">Tributário</SelectItem>
                                            <SelectItem value="administrativo">Administrativo</SelectItem>
                                            <SelectItem value="penal">Penal</SelectItem>
                                            <SelectItem value="consumidor">Consumidor</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div className="flex justify-end gap-3">
                                <Button variant="outline" onClick={() => setShowForm(false)}>
                                    Cancelar
                                </Button>
                                <Button 
                                    onClick={handleNovaAnalise}
                                    disabled={loading}
                                    className="bg-green-600 hover:bg-green-700"
                                >
                                    {loading ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Analisando...
                                        </>
                                    ) : (
                                        <>
                                            <Brain className="w-4 h-4 mr-2" />
                                            Executar Análise IA
                                        </>
                                    )}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {/* Lista de Análises */}
                <div className="grid gap-6">
                    {analises.map((analise) => (
                        <Card key={analise.id} className="hover:shadow-xl transition-shadow">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div className="flex-1 mr-4">
                                        <CardTitle className="text-lg mb-2 line-clamp-2">
                                            {analise.tese_juridica}
                                        </CardTitle>
                                        <div className="flex items-center gap-3 text-sm text-slate-600">
                                            <Badge variant="outline">{analise.tribunal_alvo}</Badge>
                                            {analise.area_direito && (
                                                <Badge variant="outline">{analise.area_direito}</Badge>
                                            )}
                                            <Badge className={`${getConfidenceColor(analise.confidence_level)} border`}>
                                                Confiança: {(analise.confidence_level || 'media').toUpperCase()}
                                            </Badge>
                                        </div>
                                    </div>
                                    
                                    <div className={`px-6 py-4 rounded-xl text-center ${getProbabilidadeColor(analise.probabilidade_exito || 0)}`}>
                                        <div className="flex items-center justify-center mb-1">
                                            {getProbabilidadeIcon(analise.probabilidade_exito || 0)}
                                        </div>
                                        <div className="text-2xl font-bold">
                                            {analise.probabilidade_exito || 0}%
                                        </div>
                                        <div className="text-xs font-medium">
                                            Chance de Êxito
                                        </div>
                                    </div>
                                </div>
                            </CardHeader>
                            
                            <CardContent>
                                <div className="grid md:grid-cols-2 gap-6 mb-6">
                                    <div>
                                        <h4 className="font-semibold text-green-700 mb-3 flex items-center gap-2">
                                            <CheckCircle className="w-4 h-4" />
                                            Fatores Positivos ({analise.precedentes_favoraveis || 0} precedentes)
                                        </h4>
                                        <ul className="space-y-1">
                                            {(analise.fatores_positivos || []).map((fator, idx) => (
                                                <li key={idx} className="text-sm text-slate-700 flex items-start gap-2">
                                                    <span className="text-green-600 mt-1">•</span>
                                                    {fator}
                                                </li>
                                            ))}
                                            {(!analise.fatores_positivos || analise.fatores_positivos.length === 0) && (
                                                <li className="text-sm text-slate-500 italic">Nenhum fator positivo identificado</li>
                                            )}
                                        </ul>
                                    </div>
                                    
                                    <div>
                                        <h4 className="font-semibold text-red-700 mb-3 flex items-center gap-2">
                                            <AlertTriangle className="w-4 h-4" />
                                            Fatores de Risco ({analise.precedentes_desfavoraveis || 0} precedentes)
                                        </h4>
                                        <ul className="space-y-1">
                                            {(analise.fatores_negativos || []).map((fator, idx) => (
                                                <li key={idx} className="text-sm text-slate-700 flex items-start gap-2">
                                                    <span className="text-red-600 mt-1">•</span>
                                                    {fator}
                                                </li>
                                            ))}
                                            {(!analise.fatores_negativos || analise.fatores_negativos.length === 0) && (
                                                <li className="text-sm text-slate-500 italic">Nenhum fator de risco identificado</li>
                                            )}
                                        </ul>
                                    </div>
                                </div>

                                {analise.recomendacoes && analise.recomendacoes.length > 0 && (
                                    <div className="bg-blue-50 rounded-lg p-4 mb-4">
                                        <h4 className="font-semibold text-blue-800 mb-3 flex items-center gap-2">
                                            <Lightbulb className="w-4 h-4" />
                                            Recomendações Estratégicas
                                        </h4>
                                        <ul className="space-y-2">
                                            {analise.recomendacoes.map((rec, idx) => (
                                                <li key={idx} className="text-sm text-blue-700 flex items-start gap-2">
                                                    <span className="text-blue-600 mt-1">→</span>
                                                    {rec}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}

                                {(!analise.recomendacoes || analise.recomendacoes.length === 0) && (
                                    <div className="bg-gray-50 rounded-lg p-4 mb-4 text-center">
                                        <p className="text-sm text-gray-600 italic">
                                            Nenhuma recomendação específica disponível para esta análise
                                        </p>
                                    </div>
                                )}

                                {analise.fundamentacao_ia && (
                                    <div className="bg-slate-50 rounded-lg p-4">
                                        <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                                            <Brain className="w-4 h-4 text-purple-600" />
                                            Fundamentação da IA
                                        </h4>
                                        <p className="text-sm text-slate-700 leading-relaxed">
                                            {analise.fundamentacao_ia}
                                        </p>
                                    </div>
                                )}

                                {!analise.fundamentacao_ia && (
                                    <div className="bg-gray-50 rounded-lg p-4 text-center">
                                        <p className="text-sm text-gray-600 italic">
                                            Fundamentação em processamento...
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {analises.length === 0 && !loading && (
                    <Card>
                        <CardContent className="p-12 text-center">
                            <Target className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-slate-900 mb-2">
                                Nenhuma análise encontrada
                            </h3>
                            <p className="text-slate-500 mb-4">
                                Execute sua primeira análise de chances de êxito com nossa IA especializada.
                            </p>
                            <Button onClick={() => setShowForm(true)} className="bg-green-600 hover:bg-green-700">
                                <Brain className="w-4 h-4 mr-2" />
                                Primeira Análise
                            </Button>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
