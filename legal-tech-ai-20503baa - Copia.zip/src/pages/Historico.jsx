
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter, Calendar, Trash2, Star, FileText, Scale, MessageSquare, Upload } from 'lucide-react';
import { Consulta } from '@/api/entities';
import { Favorito } from '@/api/entities';

export default function HistoricoPage() {
    const [consultas, setConsultas] = useState([]);
    const [filteredConsultas, setFilteredConsultas] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [typeFilter, setTypeFilter] = useState('all');
    const [successFilter, setSuccessFilter] = useState('all');

    const loadHistorico = async () => {
        try {
            const data = await Consulta.list('-created_date', 100);
            setConsultas(data);
        } catch (error) {
            console.error('Erro ao carregar histórico:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadHistorico();
    }, []);

    const filterConsultas = useCallback(() => {
        let filtered = consultas;

        if (searchTerm) {
            filtered = filtered.filter(c => 
                c.termo_busca.toLowerCase().includes(searchTerm.toLowerCase()) ||
                c.tribunal?.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        if (typeFilter !== 'all') {
            filtered = filtered.filter(c => c.tipo === typeFilter);
        }

        if (successFilter !== 'all') {
            filtered = filtered.filter(c => c.sucesso === (successFilter === 'true'));
        }

        setFilteredConsultas(filtered);
    }, [consultas, searchTerm, typeFilter, successFilter]); // Dependencies for useCallback

    useEffect(() => {
        filterConsultas();
    }, [filterConsultas]); // Now depends only on the memoized filterConsultas function

    const handleDelete = async (consultaId) => {
        try {
            await Consulta.delete(consultaId);
            setConsultas(prev => prev.filter(c => c.id !== consultaId));
        } catch (error) {
            console.error('Erro ao deletar consulta:', error);
        }
    };

    const handleFavorite = async (consulta) => {
        try {
            await Favorito.create({
                tipo: consulta.tipo === 'chat' ? 'jurisprudencia' : consulta.tipo,
                titulo: `${consulta.tipo.toUpperCase()}: ${consulta.termo_busca}`,
                numero_processo: consulta.tipo === 'processo' ? consulta.termo_busca : undefined,
                tribunal: consulta.tribunal || 'N/A',
                dados: consulta.resultado,
                tags: [consulta.tipo, consulta.tribunal].filter(Boolean),
                anotacoes: `Favoritado em ${new Date().toLocaleDateString('pt-BR')}`
            });
            alert('Item adicionado aos favoritos!');
        } catch (error) {
            console.error('Erro ao favoritar:', error);
            alert('Erro ao favoritar item.');
        }
    };

    const getTypeIcon = (tipo) => {
        switch (tipo) {
            case 'chat': return <MessageSquare className="w-4 h-4" />;
            case 'processo': return <Scale className="w-4 h-4" />;
            case 'jurisprudencia': return <FileText className="w-4 h-4" />;
            case 'documento': return <Upload className="w-4 h-4" />;
            default: return <Search className="w-4 h-4" />;
        }
    };

    const getTypeColor = (tipo) => {
        switch (tipo) {
            case 'chat': return 'bg-blue-100 text-blue-800';
            case 'processo': return 'bg-green-100 text-green-800';
            case 'jurisprudencia': return 'bg-purple-100 text-purple-800';
            case 'documento': return 'bg-orange-100 text-orange-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-6xl mx-auto px-4">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900 mb-2">Histórico de Consultas</h1>
                    <p className="text-slate-600">Todas as suas consultas realizadas na LegalTech AI</p>
                </div>

                {/* Filtros */}
                <Card className="mb-6">
                    <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                            <div className="flex-1">
                                <Input
                                    placeholder="Buscar no histórico..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full"
                                />
                            </div>
                            <div className="flex gap-2">
                                <Select value={typeFilter} onValueChange={setTypeFilter}>
                                    <SelectTrigger className="w-40">
                                        <SelectValue placeholder="Tipo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="all">Todos os tipos</SelectItem>
                                        <SelectItem value="chat">Chat IA</SelectItem>
                                        <SelectItem value="processo">Processos</SelectItem>
                                        <SelectItem value="jurisprudencia">Jurisprudência</SelectItem>
                                        <SelectItem value="documento">Documentos</SelectItem>
                                    </SelectContent>
                                </Select>

                                <Select value={successFilter} onValueChange={setSuccessFilter}>
                                    <SelectTrigger className="w-32">
                                        <SelectValue placeholder="Status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="all">Todos</SelectItem>
                                        <SelectItem value="true">Sucesso</SelectItem>
                                        <SelectItem value="false">Erro</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="flex justify-between items-center mt-4">
                            <p className="text-sm text-slate-600">
                                {filteredConsultas.length} de {consultas.length} consultas
                            </p>
                            <Badge variant="outline">
                                Total de fontes CNJ: {consultas.reduce((acc, c) => acc + (c.fontes_cnj || 0), 0)}
                            </Badge>
                        </div>
                    </CardContent>
                </Card>

                {/* Lista de Consultas */}
                <div className="space-y-4">
                    {filteredConsultas.map((consulta, index) => (
                        <Card key={index} className="hover:shadow-md transition-shadow">
                            <CardContent className="p-6">
                                <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-2">
                                            <Badge className={getTypeColor(consulta.tipo)}>
                                                <div className="flex items-center gap-1">
                                                    {getTypeIcon(consulta.tipo)}
                                                    {consulta.tipo.toUpperCase()}
                                                </div>
                                            </Badge>
                                            {consulta.sucesso ? (
                                                <Badge variant="outline" className="text-green-600 border-green-200">
                                                    ✓ Sucesso
                                                </Badge>
                                            ) : (
                                                <Badge variant="destructive">
                                                    ✗ Erro
                                                </Badge>
                                            )}
                                            {consulta.fontes_cnj > 0 && (
                                                <Badge variant="outline" className="text-blue-600 border-blue-200">
                                                    {consulta.fontes_cnj} fontes CNJ
                                                </Badge>
                                            )}
                                        </div>

                                        <h3 className="font-semibold text-slate-900 mb-1">
                                            {consulta.termo_busca}
                                        </h3>

                                        <div className="flex items-center gap-4 text-sm text-slate-500">
                                            <span className="flex items-center gap-1">
                                                <Calendar className="w-4 h-4" />
                                                {new Date(consulta.created_date).toLocaleString('pt-BR')}
                                            </span>
                                            {consulta.tribunal && (
                                                <span>Tribunal: {consulta.tribunal}</span>
                                            )}
                                            {consulta.tempo_resposta && (
                                                <span>Tempo: {consulta.tempo_resposta}ms</span>
                                            )}
                                        </div>
                                    </div>

                                    <div className="flex gap-2">
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => handleFavorite(consulta)}
                                            className="text-orange-600 border-orange-200 hover:bg-orange-50"
                                        >
                                            <Star className="w-4 h-4" />
                                        </Button>
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => handleDelete(consulta.id)}
                                            className="text-red-600 border-red-200 hover:bg-red-50"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>

                                {/* Resumo do resultado */}
                                {consulta.resultado && (
                                    <div className="mt-4 p-3 bg-slate-50 rounded-lg">
                                        <p className="text-sm text-slate-600">
                                            <strong>Resumo:</strong>{' '}
                                            {typeof consulta.resultado === 'string' 
                                                ? consulta.resultado.substring(0, 200) 
                                                : JSON.stringify(consulta.resultado).substring(0, 200)
                                            }...
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {filteredConsultas.length === 0 && (
                    <Card>
                        <CardContent className="p-12 text-center">
                            <Search className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-slate-900 mb-2">
                                Nenhuma consulta encontrada
                            </h3>
                            <p className="text-slate-500">
                                {searchTerm || typeFilter !== 'all' || successFilter !== 'all' 
                                    ? 'Tente ajustar os filtros de busca.' 
                                    : 'Suas consultas aparecerão aqui conforme você usar a LegalTech AI.'
                                }
                            </p>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
