
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Upload, FileText, Loader2, CheckCircle, AlertCircle, X, FileCheck, Zap, Scale } from 'lucide-react';
import { InvokeLLM, UploadFile } from '@/api/integrations';
import { buscarJurisprudencia } from '@/api/functions';
import { judyPersonaSystemPrompt } from '@/components/personas/Judy'; // Caminho corrigido

export default function UploadPage() {
    const [file, setFile] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [resultado, setResultado] = useState(null);
    const [error, setError] = useState(null);
    const [progress, setProgress] = useState({ stage: '', percentage: 0 });

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        handleFileSelection(selectedFile);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        const droppedFile = e.dataTransfer.files[0];
        handleFileSelection(droppedFile);
    };

    const handleFileSelection = (selectedFile) => {
        if (selectedFile) {
            if (selectedFile.type !== "application/pdf") {
                setError("Apenas arquivos PDF são permitidos.");
                setFile(null);
            } else if (selectedFile.size > 10 * 1024 * 1024) { // Limite de 10MB
                setError("Arquivo muito grande. O limite para análise é de 10MB.");
                setFile(null);
            } else {
                setFile(selectedFile);
                setError(null);
                setResultado(null);
            }
        }
    };

    const handleDragOver = (e) => {
        e.preventDefault();
    };

    const clearFile = () => {
        setFile(null);
        setError(null);
        setResultado(null);
        setProgress({ stage: '', percentage: 0 });
    };

    const handleAnalise = async () => {
        if (!file) {
            setError("Por favor, selecione um arquivo para analisar.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setResultado(null);

        try {
            // Etapa 1: Upload do arquivo
            setProgress({ stage: 'Enviando arquivo...', percentage: 20 });
            const uploadResponse = await UploadFile({ file });
            
            if (!uploadResponse.file_url) {
                throw new Error('Falha no upload do arquivo');
            }

            // Etapa 2: Análise com IA (Judy)
            setProgress({ stage: 'Analisando documento...', percentage: 50 });
            
            const analisePrompt = `Analise o documento fornecido e, seguindo estritamente suas diretrizes de atuação, extraia as seguintes informações de forma estruturada:

1.  **Tipo de Documento**: Identifique a natureza jurídica do documento (ex: Petição Inicial, Contrato de Compra e Venda, Sentença, etc.).
2.  **Partes Envolvidas**: Liste o Autor/Requerente, o Réu/Requerido e outras partes envolvidas, se houver (ex: Terceiros Interessados, Litisconsortes, etc.).
3.  **Objeto Principal**: Descreva o objetivo central do documento em uma frase.
4.  **Pedidos Principais**: Liste os principais pedidos formulados no documento.
5.  **Fundamentos Jurídicos**: Cite os artigos de lei, súmulas, ou princípios jurídicos que servem de base para o documento.
6.  **Assuntos Jurídicos**: Identifique os temas ou classificações jurídicas principais que o documento aborda.
7.  **Valores Envolvidos**: Se aplicável, extraia qualquer valor monetário mencionado (ex: valor da causa, valor de contrato, indenização, etc.).
8.  **Pontos de Atenção**: Identifique até 5 pontos críticos ou cláusulas que merecem atenção especial, com foco em riscos ou oportunidades.
9.  **Termos para Busca de Jurisprudência**: Extraia de 3 a 5 termos jurídicos precisos do documento que seriam ideais para uma busca de jurisprudência no CNJ.
10. **Resumo da Análise**: Crie um resumo conciso e estratégico do documento, destacando os pontos mais relevantes para uma compreensão rápida.`;

            const analiseIA = await InvokeLLM({
                system: judyPersonaSystemPrompt, // Usar a persona da Judy
                prompt: analisePrompt,
                file_urls: [uploadResponse.file_url],
                model: 'claude-3-5-sonnet-20240620', // Usar um modelo mais avançado
                response_json_schema: {
                    type: "object",
                    properties: {
                        tipo_documento: { type: "string" },
                        partes: {
                            type: "object",
                            properties: { 
                                autor: { type: "string" }, 
                                reu: { type: "string" },
                                outros: { type: "array", items: { type: "string" } }
                            }
                        },
                        objeto_principal: { type: "string" },
                        pedidos: { type: "array", items: { type: "string" } },
                        fundamentos_juridicos: { type: "array", items: { type: "string" } },
                        assuntos: { type: "array", items: { type: "string" } },
                        valores: { type: "string" },
                        pontos_atencao: { type: "array", items: { type: "string" } },
                        termos_busca_cnj: { type: "array", items: { type: "string" } },
                        analise_resumo: { type: "string" }
                    },
                    required: ["tipo_documento", "partes", "objeto_principal", "termos_busca_cnj", "analise_resumo"]
                }
            });

            // Etapa 3: Buscar jurisprudência relacionada no CNJ
            setProgress({ stage: 'Consultando jurisprudência CNJ...', percentage: 70 });
            let jurisprudencias = [];
            if (analiseIA.termos_busca_cnj && analiseIA.termos_busca_cnj.length > 0) {
                for (const termo of analiseIA.termos_busca_cnj.slice(0, 2)) { // Limita a 2 buscas para agilidade
                    try {
                        const jurisResponse = await buscarJurisprudencia({ termo: termo, tribunal: 'tjsp', tamanho: 2 });
                        if (jurisResponse.data.success && jurisResponse.data.jurisprudencias) {
                            jurisprudencias.push(...jurisResponse.data.jurisprudencias);
                        }
                    } catch (e) { console.log('Erro na busca de jurisprudência:', e); }
                }
            }

            // Etapa 4: Análise final com contexto CNJ
            setProgress({ stage: 'Gerando análise final...', percentage: 90 });
            let contextoJurisprudencia = '';
            if (jurisprudencias.length > 0) {
                contextoJurisprudencia = `\n\nJURISPRUDÊNCIA RELEVANTE ENCONTRADA NO CNJ:\n\n`;
                jurisprudencias.slice(0, 3).forEach((juris, index) => {
                    contextoJurisprudencia += `${index + 1}. Processo ${juris.numeroProcesso} (${juris.tribunal})\nEmenta: ${juris.ementa.substring(0, 200)}...\n`;
                });
            }

            const parecerFinalPrompt = `Com base na análise estruturada do documento e na jurisprudência do CNJ, elabore um parecer jurídico final, seguindo o formato de resposta para consultas:

1.  **Contextualização**: Breve introdução sobre o documento.
2.  **Base Legal Aplicável**: Cite a legislação principal.
3.  **Jurisprudência Relevante**: Comente os precedentes encontrados.
4.  **Análise Técnica**: Interpretação fundamentada.
5.  **Recomendações Práticas**: Orientações e próximos passos.
6.  **Riscos e Considerações**: Pontos de atenção.`;
            
            const parecerFinal = await InvokeLLM({
                system: judyPersonaSystemPrompt,
                prompt: `DADOS DO DOCUMENTO:\n${JSON.stringify(analiseIA, null, 2)}\n\n${contextoJurisprudencia}\n\nINSTRUÇÃO:\n${parecerFinalPrompt}`,
                model: 'claude-3-5-sonnet-20240620'
            });

            setProgress({ stage: 'Concluído!', percentage: 100 });

            const resultadoFinal = {
                arquivo: { nome: file.name, tamanho: (file.size / 1024 / 1024).toFixed(1) + ' MB' },
                analise_estruturada: analiseIA,
                analise_completa: parecerFinal,
                jurisprudencia_cnj: jurisprudencias.slice(0, 5),
                total_precedentes: jurisprudencias.length,
                timestamp: new Date().toISOString()
            };

            setResultado(resultadoFinal);

        } catch (e) {
            setError("Ocorreu um erro ao analisar o documento. Tente novamente.");
            console.error("Erro na análise:", e);
        } finally {
            setIsLoading(false);
            setProgress({ stage: '', percentage: 0 });
        }
    };

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-6xl mx-auto px-4">
                <Card className="rounded-2xl shadow-xl bg-white">
                    <CardHeader className="text-center bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-2xl">
                        <CardTitle className="text-3xl font-bold mb-2 flex items-center justify-center gap-3">
                            <FileText className="w-8 h-8" />
                            Análise Avançada de Documentos
                        </CardTitle>
                        <p className="opacity-90 text-lg">
                            IA Especializada + Jurisprudência CNJ DataJud
                        </p>
                    </CardHeader>
                    <CardContent className="p-8">
                        {/* Upload Area */}
                        <div className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 mb-6 ${
                            file ? 'border-green-300 bg-green-50' : 'border-slate-300 bg-slate-50 hover:border-purple-400 hover:bg-purple-50'
                        }`}
                             onDrop={handleDrop}
                             onDragOver={handleDragOver}>
                            
                            <input 
                                type="file" 
                                id="file-input" 
                                accept=".pdf" 
                                className="hidden" 
                                onChange={handleFileChange} 
                            />
                            
                            {!file ? (
                                <label htmlFor="file-input" className="cursor-pointer">
                                    <Upload className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                                    <h3 className="text-xl font-semibold text-slate-700 mb-2">
                                        Selecione um documento PDF
                                    </h3>
                                    <p className="text-slate-500 mb-4">
                                        Arraste e solte ou clique para selecionar
                                    </p>
                                    <div className="text-sm text-slate-400">
                                        Máximo 10MB • Formato: PDF
                                    </div>
                                </label>
                            ) : (
                                <div className="flex items-center justify-center gap-4">
                                    <FileCheck className="w-12 h-12 text-green-600" />
                                    <div className="text-left">
                                        <h3 className="text-lg font-semibold text-green-800">
                                            {file.name}
                                        </h3>
                                        <p className="text-green-600">
                                            {(file.size / 1024 / 1024).toFixed(1)} MB
                                        </p>
                                    </div>
                                    <Button 
                                        variant="outline" 
                                        size="sm"
                                        onClick={clearFile}
                                        className="ml-4"
                                    >
                                        <X className="w-4 h-4" />
                                    </Button>
                                </div>
                            )}
                        </div>

                        {/* Progress Bar */}
                        {isLoading && (
                            <div className="mb-6 bg-blue-50 border border-blue-200 rounded-xl p-6">
                                <div className="flex items-center gap-3 mb-3">
                                    <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                                    <span className="font-semibold text-blue-800">
                                        {progress.stage}
                                    </span>
                                </div>
                                <div className="w-full bg-blue-200 rounded-full h-3">
                                    <div 
                                        className="bg-blue-600 h-3 rounded-full transition-all duration-500"
                                        style={{ width: `${progress.percentage}%` }}
                                    ></div>
                                </div>
                                <div className="text-sm text-blue-600 mt-2">
                                    {progress.percentage}% concluído
                                </div>
                            </div>
                        )}

                        {/* Action Button */}
                        <div className="flex justify-center mb-8">
                            <Button
                                onClick={handleAnalise}
                                disabled={!file || isLoading}
                                size="lg"
                                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-lg font-semibold rounded-xl"
                            >
                                {isLoading ? (
                                    <>
                                        <Loader2 className="w-5 h-5 animate-spin mr-3" />
                                        Analisando...
                                    </>
                                ) : (
                                    <>
                                        <Scale className="w-5 h-5 mr-3" />
                                        Analisar com IA + CNJ
                                    </>
                                )}
                            </Button>
                        </div>

                        {/* Error Message */}
                        {error && (
                            <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 animate-slideUp text-red-700 flex items-center gap-3">
                                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                                <span>{error}</span>
                            </div>
                        )}

                        {/* Results */}
                        {resultado && (
                            <div className="space-y-6 animate-slideUp">
                                {/* Header */}
                                <div className="bg-gradient-to-r from-green-100 to-blue-100 border border-green-200 rounded-xl p-6">
                                    <div className="flex items-center justify-between mb-4">
                                        <h3 className="text-2xl font-bold text-green-800 flex items-center gap-3">
                                            <CheckCircle className="w-8 h-8" />
                                            Análise Concluída
                                        </h3>
                                        <div className="flex gap-2">
                                            <span className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                                                IA Avançada
                                            </span>
                                            <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                                                {resultado.total_precedentes} Precedentes CNJ
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div className="grid md:grid-cols-3 gap-4">
                                        <div className="bg-white p-4 rounded-lg border text-center">
                                            <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                                            <div className="font-semibold text-sm">{resultado.arquivo.nome}</div>
                                            <div className="text-xs text-gray-500">{resultado.arquivo.tamanho}</div>
                                        </div>
                                        <div className="bg-white p-4 rounded-lg border text-center">
                                            <Zap className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                                            <div className="font-semibold text-sm">Análise IA</div>
                                            <div className="text-xs text-gray-500">Completa</div>
                                        </div>
                                        <div className="bg-white p-4 rounded-lg border text-center">
                                            <Scale className="w-8 h-8 text-green-600 mx-auto mb-2" />
                                            <div className="font-semibold text-sm">Jurisprudência</div>
                                            <div className="text-xs text-gray-500">{resultado.total_precedentes} encontrados</div>
                                        </div>
                                    </div>
                                </div>

                                {/* Análise Estruturada */}
                                {resultado.analise_estruturada && (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="text-lg text-blue-800">📊 Dados Estruturados</CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-4">
                                            <div className="grid md:grid-cols-2 gap-4">
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Tipo do Documento:</h4>
                                                    <p className="text-sm bg-blue-50 p-2 rounded">{resultado.analise_estruturada.tipo_documento || 'Não especificado'}</p>
                                                </div>
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Objeto Principal:</h4>
                                                    <p className="text-sm bg-green-50 p-2 rounded">{resultado.analise_estruturada.objeto_principal || 'Não especificado'}</p>
                                                </div>
                                            </div>
                                            
                                            {resultado.analise_estruturada.partes && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Partes Envolvidas:</h4>
                                                    <ul className="text-sm space-y-1">
                                                        {resultado.analise_estruturada.partes.autor && (
                                                            <li className="flex items-start gap-2">
                                                                <span className="text-blue-600">•</span>
                                                                <span><strong>Autor/Requerente:</strong> {resultado.analise_estruturada.partes.autor}</span>
                                                            </li>
                                                        )}
                                                        {resultado.analise_estruturada.partes.reu && (
                                                            <li className="flex items-start gap-2">
                                                                <span className="text-blue-600">•</span>
                                                                <span><strong>Réu/Requerido:</strong> {resultado.analise_estruturada.partes.reu}</span>
                                                            </li>
                                                        )}
                                                        {resultado.analise_estruturada.partes.outros && resultado.analise_estruturada.partes.outros.length > 0 && (
                                                            resultado.analise_estruturada.partes.outros.map((parte, index) => (
                                                                <li key={index} className="flex items-start gap-2">
                                                                    <span className="text-blue-600">•</span>
                                                                    <span><strong>Outros:</strong> {parte}</span>
                                                                </li>
                                                            ))
                                                        )}
                                                    </ul>
                                                </div>
                                            )}

                                            {resultado.analise_estruturada.pedidos && resultado.analise_estruturada.pedidos.length > 0 && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Pedidos Principais:</h4>
                                                    <ul className="text-sm space-y-1 list-disc list-inside">
                                                        {resultado.analise_estruturada.pedidos.map((pedido, index) => (
                                                            <li key={index}>{pedido}</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            )}

                                            {resultado.analise_estruturada.fundamentos_juridicos && resultado.analise_estruturada.fundamentos_juridicos.length > 0 && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Fundamentos Jurídicos:</h4>
                                                    <ul className="text-sm space-y-1 list-disc list-inside">
                                                        {resultado.analise_estruturada.fundamentos_juridicos.map((fundamento, index) => (
                                                            <li key={index}>{fundamento}</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            )}

                                            {resultado.analise_estruturada.assuntos && resultado.analise_estruturada.assuntos.length > 0 && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Assuntos Jurídicos:</h4>
                                                    <div className="flex flex-wrap gap-2 text-sm">
                                                        {resultado.analise_estruturada.assuntos.map((assunto, index) => (
                                                            <span key={index} className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full">{assunto}</span>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}

                                            {resultado.analise_estruturada.valores && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Valores Envolvidos:</h4>
                                                    <p className="text-sm bg-yellow-50 p-2 rounded font-medium">{resultado.analise_estruturada.valores}</p>
                                                </div>
                                            )}

                                            {resultado.analise_estruturada.pontos_atencao && resultado.analise_estruturada.pontos_atencao.length > 0 && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Pontos de Atenção:</h4>
                                                    <ul className="text-sm space-y-1 list-disc list-inside">
                                                        {resultado.analise_estruturada.pontos_atencao.map((ponto, index) => (
                                                            <li key={index} className="text-orange-700">{ponto}</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            )}

                                            {resultado.analise_estruturada.termos_busca_cnj && resultado.analise_estruturada.termos_busca_cnj.length > 0 && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Termos para Busca de Jurisprudência:</h4>
                                                    <div className="flex flex-wrap gap-2 text-sm">
                                                        {resultado.analise_estruturada.termos_busca_cnj.map((termo, index) => (
                                                            <span key={index} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full">{termo}</span>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}

                                            {resultado.analise_estruturada.analise_resumo && (
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-2">Resumo da Análise:</h4>
                                                    <p className="text-sm bg-slate-50 p-3 rounded leading-relaxed">{resultado.analise_estruturada.analise_resumo}</p>
                                                </div>
                                            )}

                                        </CardContent>
                                    </Card>
                                )}

                                {/* Análise Completa */}
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="text-lg text-purple-800">⚖️ Parecer Jurídico Final</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="prose prose-sm max-w-none text-gray-700">
                                            <div className="whitespace-pre-wrap bg-purple-50 p-4 rounded-lg border">
                                                {resultado.analise_completa}
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Jurisprudência CNJ */}
                                {resultado.jurisprudencia_cnj?.length > 0 && (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="text-lg text-green-800">🏛️ Precedentes CNJ Relacionados</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-4">
                                                {resultado.jurisprudencia_cnj.map((juris, index) => (
                                                    <div key={index} className="border rounded-lg p-4 bg-green-50">
                                                        <div className="flex justify-between items-start mb-2">
                                                            <h5 className="font-semibold text-green-800">
                                                                Processo {juris.numeroProcesso}
                                                            </h5>
                                                            <span className="bg-green-600 text-white px-2 py-1 rounded text-xs">
                                                                {juris.tribunal}
                                                            </span>
                                                        </div>
                                                        {juris.ementa && (
                                                            <p className="text-sm text-gray-700 leading-relaxed">
                                                                <strong>Ementa:</strong> {juris.ementa}
                                                            </p>
                                                        )}
                                                        <div className="flex gap-2 mt-2 flex-wrap">
                                                            {juris.assuntos?.slice(0, 3).map((assunto, idx) => (
                                                                <span key={idx} className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                                                                    {assunto}
                                                                </span>
                                                            ))}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </CardContent>
                                    </Card>
                                )}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
