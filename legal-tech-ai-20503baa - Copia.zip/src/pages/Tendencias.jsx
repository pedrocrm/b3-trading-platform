
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, BarChart3, Calendar, Target, Brain } from 'lucide-react';
import { TendenciaJurisprudencial } from '@/api/entities';
import { analisarTendencias } from '@/api/functions';
import { filtrosJurimetricos } from '@/api/functions';

export default function TendenciasPage() {
    const [tendencias, setTendencias] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [tribunalFilter, setTribunalFilter] = useState('all');
    const [dadosJurimetricos, setDadosJurimetricos] = useState(null);

    useEffect(() => {
        loadTendencias();
        loadDadosJurimetricos();
    }, []);

    const loadTendencias = async () => {
        try {
            const data = await TendenciaJurisprudencial.list('-created_date', 20);
            setTendencias(data);
        } catch (error) {
            console.error('Erro ao carregar tendências:', error);
        }
    };

    const loadDadosJurimetricos = async () => {
        try {
            const response = await filtrosJurimetricos({ tribunal: 'tjsp', periodo: '12m' });
            if (response.data && response.data.success) {
                setDadosJurimetricos(response.data.jurimetria);
            }
        } catch (error) {
            console.error('Erro ao carregar dados jurimétricos:', error);
        }
    };

    const handleAnalisarNovasTendencias = async () => {
        if (!searchTerm || searchTerm.trim().length < 3) {
            alert('Por favor, digite pelo menos 3 caracteres para o assunto jurídico.');
            return;
        }

        setLoading(true);
        try {
            const response = await analisarTendencias({
                assunto: searchTerm.trim(),
                tribunal: tribunalFilter === 'all' ? 'tjsp' : tribunalFilter
            });

            console.log('Resposta completa:', response); // Debug

            // Corrigir o acesso aos dados da resposta
            const data = response.data || response;
            
            if (data && data.success) {
                await loadTendencias();
                setSearchTerm('');
                
                // Mostrar detalhes da análise
                const analise = data.analise || {};
                const jurisprudenciasCount = analise.jurisprudencias_analisadas || 'várias';
                const tendencia = analise.tendencia || 'analisada';
                const confianca = analise.confidence_score || 'calculada';
                const procedencia = analise.percentual_procedencia || 'estimada';
                
                alert(`✅ Análise concluída com sucesso!
                
📊 ${jurisprudenciasCount} jurisprudências analisadas do CNJ
📈 Tendência: ${tendencia.toUpperCase()}
💯 Confiança: ${confianca}%
⚖️ Procedência: ${procedencia}%

${data.message || 'Análise processada com êxito'}`);
            } else {
                throw new Error(data?.message || 'Erro na análise');
            }
        } catch (error) {
            console.error('Erro ao analisar tendências:', error);
            
            // Mostrar erro específico para o usuário
            let errorMessage = 'Erro desconhecido';
            if (error.response?.data?.message) {
                errorMessage = error.response.data.message;
            } else if (error.message) {
                errorMessage = error.message;
            }
            
            alert(`❌ Erro na análise: ${errorMessage}
            
💡 Dicas:
- Verifique se o termo existe na jurisprudência
- Tente termos mais gerais (ex: "dano moral" em vez de "dano moral por negativação indevida")
- Teste com outros tribunais`);
        } finally {
            setLoading(false);
        }
    };

    const getTrendIcon = (tendencia) => {
        switch (tendencia) {
            case 'favoravel':
            case 'crescente':
                return <TrendingUp className="w-5 h-5 text-green-600" />;
            case 'desfavoravel':
            case 'decrescente':
                return <TrendingDown className="w-5 h-5 text-red-600" />;
            default:
                return <Minus className="w-5 h-5 text-gray-600" />;
        }
    };

    const getTrendColor = (tendencia) => {
        switch (tendencia) {
            case 'favoravel':
            case 'crescente':
                return 'bg-green-100 text-green-800 border-green-200';
            case 'desfavoravel':
            case 'decrescente':
                return 'bg-red-100 text-red-800 border-red-200';
            default:
                return 'bg-gray-100 text-gray-800 border-gray-200';
        }
    };

    const filteredTendencias = tendencias.filter(t => {
        const matchesSearch = !searchTerm || t.assunto.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesTribunal = tribunalFilter === 'all' || t.tribunal === tribunalFilter.toUpperCase();
        return matchesSearch && matchesTribunal;
    });

    return (
        <div className="py-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
            <div className="max-w-7xl mx-auto px-4">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-slate-900 mb-3 flex items-center gap-3">
                        <BarChart3 className="w-10 h-10 text-blue-600" />
                        Análise de Tendências Jurisprudenciais
                    </h1>
                    <p className="text-xl text-slate-600">
                        Identificação de padrões e tendências nas decisões dos tribunais brasileiros
                    </p>
                </div>

                <Card className="mb-8">
                    <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                            <Input
                                placeholder="Digite o assunto jurídico para análise... (ex: danos morais, ICMS, rescisão contratual)"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="flex-1"
                                minLength={3}
                            />
                            <Select value={tribunalFilter} onValueChange={setTribunalFilter}>
                                <SelectTrigger className="w-48">
                                    <SelectValue placeholder="Tribunal" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">Todos os Tribunais</SelectItem>
                                    <SelectItem value="tjsp">TJSP</SelectItem>
                                    <SelectItem value="tjrj">TJRJ</SelectItem>
                                    <SelectItem value="tjmg">TJMG</SelectItem>
                                    <SelectItem value="tjrs">TJRS</SelectItem>
                                </SelectContent>
                            </Select>
                            <Button 
                                onClick={handleAnalisarNovasTendencias}
                                disabled={loading || !searchTerm?.trim()}
                                className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap"
                            >
                                {loading ? (
                                    <>
                                        <Brain className="w-4 h-4 mr-2 animate-spin" />
                                        Analisando...
                                    </>
                                ) : (
                                    <>
                                        <Brain className="w-4 h-4 mr-2" />
                                        Nova Análise IA
                                    </>
                                )}
                            </Button>
                        </div>
                        {searchTerm && searchTerm.trim().length > 0 && searchTerm.trim().length < 3 && (
                            <p className="text-sm text-red-600 mt-2">
                                O assunto deve ter pelo menos 3 caracteres
                            </p>
                        )}
                    </CardContent>
                </Card>

                {dadosJurimetricos && (
                    <div className="grid md:grid-cols-4 gap-6 mb-8">
                        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                            <CardContent className="p-6 text-center">
                                <div className="text-3xl font-bold mb-2">
                                    {dadosJurimetricos.periodo_analise.total_processos.toLocaleString()}
                                </div>
                                <div className="text-blue-100">Processos Analisados</div>
                            </CardContent>
                        </Card>
                        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                            <CardContent className="p-6 text-center">
                                <div className="text-3xl font-bold mb-2">
                                    {dadosJurimetricos.classes_processuais.length}
                                </div>
                                <div className="text-green-100">Classes Processuais</div>
                            </CardContent>
                        </Card>
                        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                            <CardContent className="p-6 text-center">
                                <div className="text-3xl font-bold mb-2">
                                    {dadosJurimetricos.assuntos_principais.length}
                                </div>
                                <div className="text-purple-100">Assuntos Principais</div>
                            </CardContent>
                        </Card>
                        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
                            <CardContent className="p-6 text-center">
                                <div className="text-3xl font-bold mb-2">
                                    {dadosJurimetricos.orgaos_julgadores.length}
                                </div>
                                <div className="text-orange-100">Órgãos Julgadores</div>
                            </CardContent>
                        </Card>
                    </div>
                )}

                <div className="grid gap-6">
                    {filteredTendencias.map((tendencia) => (
                        <Card key={tendencia.id} className="hover:shadow-lg transition-shadow">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-xl text-slate-900 mb-2">
                                            {tendencia.assunto}
                                        </CardTitle>
                                        <div className="flex items-center gap-3 text-sm text-slate-600">
                                            <Badge variant="outline">{tendencia.tribunal}</Badge>
                                            <span className="flex items-center gap-1">
                                                <Calendar className="w-4 h-4" />
                                                {new Date(tendencia.periodo_inicio).toLocaleDateString()} - {new Date(tendencia.periodo_fim).toLocaleDateString()}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <Badge className={`${getTrendColor(tendencia.tendencia)} border mb-2`}>
                                            <div className="flex items-center gap-1">
                                                {getTrendIcon(tendencia.tendencia)}
                                                {tendencia.tendencia.toUpperCase()}
                                            </div>
                                        </Badge>
                                        <div className="text-sm text-slate-500">
                                            Confiança: {tendencia.confidence_score}%
                                        </div>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="grid md:grid-cols-3 gap-6 mb-4">
                                    <div className="text-center">
                                        <div className="text-2xl font-bold text-slate-900">
                                            {tendencia.percentual_procedencia}%
                                        </div>
                                        <div className="text-sm text-slate-500">Taxa de Procedência</div>
                                    </div>
                                    <div className="text-center">
                                        <div className="text-2xl font-bold text-slate-900">
                                            {tendencia.total_decisoes}
                                        </div>
                                        <div className="text-sm text-slate-500">Decisões Analisadas</div>
                                    </div>
                                    <div className="text-center">
                                        <div className="text-2xl font-bold text-slate-900">
                                            {tendencia.orgaos_julgadores.length}
                                        </div>
                                        <div className="text-sm text-slate-500">Órgãos Julgadores</div>
                                    </div>
                                </div>

                                {tendencia.analise_ia && (
                                    <div className="bg-slate-50 rounded-lg p-4 mb-4">
                                        <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                                            <Brain className="w-4 h-4 text-blue-600" />
                                            Análise da IA
                                        </h4>
                                        <p className="text-sm text-slate-700 leading-relaxed">
                                            {tendencia.analise_ia}
                                        </p>
                                    </div>
                                )}

                                {tendencia.palavras_chave && tendencia.palavras_chave.length > 0 && (
                                    <div>
                                        <h4 className="font-medium text-slate-900 mb-2">Palavras-chave:</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {tendencia.palavras_chave.slice(0, 8).map((palavra, idx) => (
                                                <Badge key={idx} variant="secondary" className="text-xs">
                                                    {palavra}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {filteredTendencias.length === 0 && !loading && (
                    <Card>
                        <CardContent className="p-12 text-center">
                            <Target className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-slate-900 mb-2">
                                Nenhuma tendência encontrada
                            </h3>
                            <p className="text-slate-500 mb-4">
                                Execute uma nova análise para identificar tendências jurisprudenciais.
                            </p>
                            <Button 
                                onClick={() => setSearchTerm('')} 
                                disabled={loading}
                                variant="outline"
                            >
                                <Brain className="w-4 h-4 mr-2" />
                                Limpar Filtros
                            </Button>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
