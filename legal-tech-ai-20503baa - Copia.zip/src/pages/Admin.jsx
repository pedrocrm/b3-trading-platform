
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
    Activity,
    AlertCircle,
    CheckCircle2,
    Clock,
    Database,
    FileText,
    RefreshCw,
    TrendingUp,
    Users,
    Wifi,
    WifiOff
} from 'lucide-react';
import { sistemaHealth } from '@/api/functions';
import { logSistema } from '@/api/functions';

export default function AdminPage() {
    const [healthData, setHealthData] = useState(null);
    const [logsData, setLogsData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [selectedPeriod, setSelectedPeriod] = useState('7d');
    const [selectedLogType, setSelectedLogType] = useState('todos');

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const [healthResponse, logsResponse] = await Promise.all([
                sistemaHealth(),
                logSistema({
                    tipo: selectedLogType === 'todos' ? undefined : selectedLogType,
                    periodo: selectedPeriod
                })
            ]);

            if (healthResponse.status === 200 || healthResponse.status === 503) {
                setHealthData(healthResponse.data);
            }

            if (logsResponse.data.success) {
                setLogsData(logsResponse.data);
            }
        } catch (error) {
            console.error('Erro ao carregar dados admin:', error);
        } finally {
            setLoading(false);
        }
    }, [selectedPeriod, selectedLogType]); // Dependencies for useCallback

    useEffect(() => {
        loadData();
    }, [loadData]); // Now useEffect depends on the memoized loadData

    const getStatusIcon = (status) => {
        switch (status) {
            case 'HEALTHY':
            case 'OK':
                return <CheckCircle2 className="w-5 h-5 text-green-600" />;
            case 'DEGRADED':
                return <AlertCircle className="w-5 h-5 text-yellow-600" />;
            case 'ERROR':
                return <AlertCircle className="w-5 h-5 text-red-600" />;
            default:
                return <Clock className="w-5 h-5 text-gray-600" />;
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'HEALTHY':
            case 'OK':
                return 'bg-green-100 text-green-800';
            case 'DEGRADED':
                return 'bg-yellow-100 text-yellow-800';
            case 'ERROR':
                return 'bg-red-100 text-red-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="flex items-center gap-2">
                    <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
                    <span>Carregando dados do sistema...</span>
                </div>
            </div>
        );
    }

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-7xl mx-auto px-4">
                <div className="mb-8">
                    <div className="flex justify-between items-center">
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900 mb-2">
                                Administração do Sistema
                            </h1>
                            <p className="text-slate-600">
                                Monitoramento e logs da Lexusai
                            </p>
                        </div>
                        <Button
                            onClick={loadData}
                            variant="outline"
                            className="flex items-center gap-2"
                        >
                            <RefreshCw className="w-4 h-4" />
                            Atualizar
                        </Button>
                    </div>
                </div>

                {/* Status Geral do Sistema */}
                {healthData && (
                    <div className="mb-8">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Activity className="w-5 h-5" />
                                    Status do Sistema
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                                    <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
                                        {getStatusIcon(healthData.overall_status)}
                                        <div>
                                            <div className="font-semibold">Status Geral</div>
                                            <Badge className={getStatusColor(healthData.overall_status)}>
                                                {healthData.overall_status}
                                            </Badge>
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
                                        {healthData.cnj_connectivity.available ?
                                            <Wifi className="w-5 h-5 text-green-600" /> :
                                            <WifiOff className="w-5 h-5 text-red-600" />
                                        }
                                        <div>
                                            <div className="font-semibold">CNJ DataJud</div>
                                            <Badge className={healthData.cnj_connectivity.available ?
                                                'bg-green-100 text-green-800' :
                                                'bg-red-100 text-red-800'
                                            }>
                                                {healthData.cnj_connectivity.available ? 'Conectado' : 'Offline'}
                                            </Badge>
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
                                        <Database className="w-5 h-5 text-blue-600" />
                                        <div>
                                            <div className="font-semibold">Banco de Dados</div>
                                            <Badge className={healthData.database.connected ?
                                                'bg-green-100 text-green-800' :
                                                'bg-red-100 text-red-800'
                                            }>
                                                {healthData.database.connected ? 'Conectado' : 'Erro'}
                                            </Badge>
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
                                        <Clock className="w-5 h-5 text-purple-600" />
                                        <div>
                                            <div className="font-semibold">Tempo Resposta</div>
                                            <div className="text-sm text-slate-600">
                                                {healthData.response_time_ms}ms
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <h4 className="font-semibold mb-3">Entidades do Sistema</h4>
                                        <div className="space-y-2">
                                            {Object.entries(healthData.entidades).map(([entidade, status]) => (
                                                <div key={entidade} className="flex justify-between items-center p-2 bg-white rounded border">
                                                    <span className="text-sm font-medium">{entidade}</span>
                                                    <Badge className={getStatusColor(status)} size="sm">
                                                        {status}
                                                    </Badge>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <div>
                                        <h4 className="font-semibold mb-3">Informações do Sistema</h4>
                                        <div className="space-y-2 text-sm">
                                            <div className="flex justify-between p-2 bg-white rounded border">
                                                <span>Plataforma:</span>
                                                <span className="font-medium">{healthData.platform}</span>
                                            </div>
                                            <div className="flex justify-between p-2 bg-white rounded border">
                                                <span>Deno Version:</span>
                                                <span className="font-medium">{healthData.deno_version}</span>
                                            </div>
                                            <div className="flex justify-between p-2 bg-white rounded border">
                                                <span>Server Time:</span>
                                                <span className="font-medium">{healthData.server_time}</span>
                                            </div>
                                            <div className="flex justify-between p-2 bg-white rounded border">
                                                <span>Configurações:</span>
                                                <span className="font-medium">
                                                    {healthData.configuracoes.loaded} carregadas
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}

                {/* Logs e Estatísticas */}
                {logsData && (
                    <div className="grid lg:grid-cols-3 gap-6 mb-8">
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">Estatísticas Gerais</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center">
                                        <span>Total de Logs:</span>
                                        <Badge variant="outline">{logsData.estatisticas.total_logs}</Badge>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span>Sucessos:</span>
                                        <Badge className="bg-green-100 text-green-800">
                                            {logsData.estatisticas.sucessos}
                                        </Badge>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span>Erros:</span>
                                        <Badge className="bg-red-100 text-red-800">
                                            {logsData.estatisticas.erros}
                                        </Badge>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span>Tempo Médio:</span>
                                        <span className="text-sm">
                                            {Math.round(logsData.estatisticas.tempo_medio_resposta)}ms
                                        </span>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="lg:col-span-2">
                            <CardHeader>
                                <CardTitle className="text-lg">Logs por Tipo</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 gap-4">
                                    {Object.entries(logsData.estatisticas.por_tipo).map(([tipo, stats]) => (
                                        <div key={tipo} className="p-3 bg-slate-50 rounded-lg">
                                            <div className="font-medium capitalize mb-2">{tipo}</div>
                                            <div className="space-y-1 text-sm">
                                                <div>Total: <span className="font-medium">{stats.total}</span></div>
                                                <div>Sucessos: <span className="text-green-600">{stats.sucessos}</span></div>
                                                <div>Tempo: <span className="text-blue-600">{Math.round(stats.tempo_medio)}ms</span></div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}

                {/* Filtros e Lista de Logs */}
                <Card>
                    <CardHeader>
                        <div className="flex justify-between items-center">
                            <CardTitle className="flex items-center gap-2">
                                <FileText className="w-5 h-5" />
                                Logs do Sistema
                            </CardTitle>
                            <div className="flex gap-2">
                                <Select value={selectedLogType} onValueChange={setSelectedLogType}>
                                    <SelectTrigger className="w-32">
                                        <SelectValue placeholder="Tipo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="todos">Todos</SelectItem>
                                        <SelectItem value="chat">Chat</SelectItem>
                                        <SelectItem value="processo">Processo</SelectItem>
                                        <SelectItem value="jurisprudencia">Jurisprudência</SelectItem>
                                        <SelectItem value="upload">Upload</SelectItem>
                                        <SelectItem value="error">Erros</SelectItem>
                                        <SelectItem value="sistema">Sistema</SelectItem>
                                    </SelectContent>
                                </Select>

                                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                                    <SelectTrigger className="w-32">
                                        <SelectValue placeholder="Período" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="1d">Último dia</SelectItem>
                                        <SelectItem value="7d">7 dias</SelectItem>
                                        <SelectItem value="30d">30 dias</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent>
                        {logsData && logsData.logs.length > 0 ? (
                            <div className="space-y-3 max-h-96 overflow-y-auto">
                                {logsData.logs.slice(0, 50).map((log, index) => (
                                    <div key={index} className="p-4 border rounded-lg">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center gap-2">
                                                <Badge className={getStatusColor(log.sucesso ? 'OK' : 'ERROR')} size="sm">
                                                    {log.tipo.toUpperCase()}
                                                </Badge>
                                                <span className="font-medium">{log.endpoint}</span>
                                            </div>
                                            <div className="text-xs text-slate-500">
                                                {new Date(log.created_date).toLocaleString('pt-BR')}
                                            </div>
                                        </div>

                                        <div className="text-sm text-slate-600">
                                            {log.erro_detalhes ? (
                                                <span className="text-red-600">{log.erro_detalhes}</span>
                                            ) : (
                                                <span>Operação realizada com sucesso</span>
                                            )}
                                        </div>

                                        <div className="flex justify-between items-center mt-2 text-xs text-slate-500">
                                            <span>Tempo: {log.tempo_resposta || 0}ms</span>
                                            {log.fontes_cnj > 0 && (
                                                <span className="text-green-600">
                                                    {log.fontes_cnj} fonte(s) CNJ
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-8 text-slate-500">
                                Nenhum log encontrado para os critérios selecionados.
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
