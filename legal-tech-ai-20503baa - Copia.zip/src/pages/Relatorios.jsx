
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { FileText, Download, Loader2, Calendar, CheckCircle, AlertCircle, Plus } from 'lucide-react';
import { Relatorio } from '@/api/entities';
import { gerarRelatorio } from '@/api/functions';

export default function RelatoriosPage() {
    const [relatorios, setRelatorios] = useState([]);
    const [loading, setLoading] = useState(true);
    const [generating, setGenerating] = useState(false);

    useEffect(() => {
        loadRelatorios();
    }, []);

    const loadRelatorios = async () => {
        try {
            const data = await Relatorio.list('-created_date', 50);
            setRelatorios(data);
        } catch (error) {
            console.error('Erro ao carregar relatórios:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleGerarRelatorio = async () => {
        setGenerating(true);
        try {
            const response = await gerarRelatorio({
                tipo: 'dashboard',
                titulo: `Relatório LegalTech AI - ${new Date().toLocaleDateString('pt-BR')}`,
                dados_origem: { tipo: 'dashboard', timestamp: new Date().toISOString() }
            });

            if (response.data.success) {
                loadRelatorios(); // Recarrega a lista
                alert('Relatório gerado com sucesso!');
            }
        } catch (error) {
            console.error('Erro ao gerar relatório:', error);
            alert('Erro ao gerar relatório.');
        } finally {
            setGenerating(false);
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'concluido': return <CheckCircle className="w-4 h-4 text-green-600" />;
            case 'erro': return <AlertCircle className="w-4 h-4 text-red-600" />;
            default: return <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />;
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'concluido': return 'bg-green-100 text-green-800';
            case 'erro': return 'bg-red-100 text-red-800';
            default: return 'bg-blue-100 text-blue-800';
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-6xl mx-auto px-4">
                <div className="mb-8">
                    <div className="flex justify-between items-center">
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900 mb-2 flex items-center gap-3">
                                <FileText className="w-8 h-8 text-blue-600" />
                                Relatórios
                            </h1>
                            <p className="text-slate-600">Relatórios automáticos gerados pela LegalTech AI</p>
                        </div>
                        <Button 
                            onClick={handleGerarRelatorio}
                            disabled={generating}
                            className="bg-blue-600 hover:bg-blue-700"
                        >
                            {generating ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Gerando...
                                </>
                            ) : (
                                <>
                                    <Plus className="w-4 h-4 mr-2" />
                                    Gerar Relatório
                                </>
                            )}
                        </Button>
                    </div>
                </div>

                {/* Lista de Relatórios */}
                <div className="grid gap-4">
                    {relatorios.map((relatorio, index) => (
                        <Card key={index} className="hover:shadow-md transition-shadow">
                            <CardContent className="p-6">
                                <div className="flex justify-between items-start">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-3">
                                            <Badge className={getStatusColor(relatorio.status)}>
                                                <div className="flex items-center gap-1">
                                                    {getStatusIcon(relatorio.status)}
                                                    {relatorio.status.toUpperCase()}
                                                </div>
                                            </Badge>
                                            <Badge variant="outline">
                                                {relatorio.tipo.toUpperCase()}
                                            </Badge>
                                        </div>

                                        <h3 className="text-lg font-semibold text-slate-900 mb-2">
                                            {relatorio.titulo}
                                        </h3>

                                        <div className="flex items-center gap-4 text-sm text-slate-500 mb-3">
                                            <span className="flex items-center gap-1">
                                                <Calendar className="w-4 h-4" />
                                                {new Date(relatorio.created_date).toLocaleString('pt-BR')}
                                            </span>
                                        </div>

                                        {relatorio.conteudo && (
                                            <div className="bg-slate-50 rounded-lg p-3">
                                                <p className="text-sm text-slate-700">
                                                    {relatorio.conteudo.substring(0, 200)}...
                                                </p>
                                            </div>
                                        )}
                                    </div>

                                    <div className="flex gap-2 ml-4">
                                        {relatorio.arquivo_url && relatorio.status === 'concluido' && (
                                            <Button
                                                size="sm"
                                                variant="outline"
                                                onClick={() => window.open(relatorio.arquivo_url, '_blank')}
                                                className="text-blue-600 border-blue-200 hover:bg-blue-50"
                                            >
                                                <Download className="w-4 h-4" />
                                                Download PDF
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {relatorios.length === 0 && (
                    <Card>
                        <CardContent className="p-12 text-center">
                            <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-slate-900 mb-2">
                                Nenhum relatório encontrado
                            </h3>
                            <p className="text-slate-500 mb-4">
                                Gere seu primeiro relatório para começar.
                            </p>
                            <Button 
                                onClick={handleGerarRelatorio}
                                disabled={generating}
                                className="bg-blue-600 hover:bg-blue-700"
                            >
                                <Plus className="w-4 h-4 mr-2" />
                                Gerar Primeiro Relatório
                            </Button>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
