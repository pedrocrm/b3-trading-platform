

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Home,
  MessageSquare,
  Search,
  Upload,
  Wifi,
  WifiOff,
  Loader2,
  BarChart3,
  History,
  Star,
  FileText,
  Zap,
  Gavel,
  Target // Added Target icon
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger
} from "@/components/ui/sidebar";
import { checkCNJStatus } from "@/api/functions";
import { Toaster } from "@/components/ui/sonner";

const navigationItems = [
  { title: "Início", url: createPageUrl("Home"), icon: Home },
  { title: "Chat IA", url: createPageUrl("Chat"), icon: MessageSquare },
  { title: "Pesquisa Avançada", url: createPageUrl("Search"), icon: Search },
  { title: "Analisar Documento", url: createPageUrl("Upload"), icon: Upload },
  { title: "Chances de Êxito", url: createPageUrl("ChancesExito"), icon: Target }, // New item
  { title: "Tendências", url: createPageUrl("Tendencias"), icon: BarChart3 },      // New item
  { title: "Processamento Lote", url: createPageUrl("BatchProcessor"), icon: Zap },
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: BarChart3 },
  { title: "Histórico", url: createPageUrl("Historico"), icon: History },
  { title: "Favoritos", url: createPageUrl("Favoritos"), icon: Star },
  { title: "Relatórios", url: createPageUrl("Relatorios"), icon: FileText },
];

const CNJStatusIndicator = () => {
    const [status, setStatus] = useState({ state: 'checking', message: 'Verificando...' });

    useEffect(() => {
        const verifyStatus = async () => {
            try {
                const { data, status: httpStatus } = await checkCNJStatus();
                if (httpStatus === 200 && data.success) {
                    setStatus({ state: 'connected', message: 'CNJ Conectado' });
                } else {
                    setStatus({ state: 'error', message: 'CNJ Offline' });
                }
            } catch (error) {
                console.error("CNJ connection check failed:", error);
                setStatus({ state: 'error', message: 'CNJ Offline' });
            }
        };

        verifyStatus();
        const intervalId = setInterval(verifyStatus, 300000);

        return () => clearInterval(intervalId);
    }, []);

    const statusConfig = {
        checking: { icon: <Loader2 className="w-3 h-3 animate-spin text-yellow-600" />, text: "Verificando CNJ...", color: "bg-yellow-100 text-yellow-800" },
        connected: { icon: <Wifi className="w-3 h-3 text-green-600" />, text: "CNJ Conectado", color: "bg-green-100 text-green-800" },
        error: { icon: <WifiOff className="w-3 h-3 text-red-600" />, text: "CNJ Offline", color: "bg-red-100 text-red-800" },
    };

    const currentStatus = statusConfig[status.state];

    return (
        <div className={`mt-4 flex items-center justify-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${currentStatus.color}`}>
            {currentStatus.icon}
            <span>{currentStatus.text}</span>
        </div>
    );
};

const WhatsAppWidget = () => {
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const showTimer = setTimeout(() => setShowPopup(true), 5000);
    const hideTimer = setTimeout(() => setShowPopup(false), 20000); // Show for 15s

    return () => {
      clearTimeout(showTimer);
      clearTimeout(hideTimer);
    };
  }, []);

  return (
    <>
      <style>{`
        .whatsapp-float {
          position: fixed;
          width: 60px;
          height: 60px;
          bottom: 40px;
          right: 40px;
          background-color: #25d366;
          color: #FFF;
          border-radius: 50px;
          text-align: center;
          font-size: 30px;
          box-shadow: 2px 2px 3px #999;
          z-index: 100;
          animation: pulse 2s infinite;
          transition: transform 0.3s;
        }

        .whatsapp-float:hover {
          transform: scale(1.1);
        }

        .my-float {
          margin-top: 16px;
          width: 28px;
          height: 28px;
        }

        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }

        .whatsapp-popup {
          position: fixed;
          bottom: 110px;
          right: 40px;
          background: white;
          padding: 15px;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0,0,0,0.3);
          z-index: 99;
          max-width: 250px;
          transition: opacity 0.5s, transform 0.5s;
          opacity: 0;
          transform: translateY(10px);
          pointer-events: none;
        }
        
        .whatsapp-popup.visible {
            opacity: 1;
            transform: translateY(0);
            pointer-events: auto; /* Enable interactions when visible */
        }
      `}</style>

      <div className={`whatsapp-popup ${showPopup ? 'visible' : ''}`}>
        <p style={{ margin: 0, color: '#333' }}>
          🟢 <strong>Estamos online!</strong><br />
          <small>Clique para falar conosco</small>
        </p>
      </div>

      <a 
         href="https://api.whatsapp.com/send?phone=5511999999999&text=Olá!%20Vim%20do%20site%20e%20gostaria%20de%20mais%20informações." 
         className="whatsapp-float" 
         target="_blank"
         rel="noopener noreferrer"
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="white" className="my-float">
          <path d="M380.9 97.1C346.4 62.6 292.6 40.5 235.1 40.5 134.6 40.5 52.3 122.8 52.3 223.3c0 32.3 8.4 63.6 24.2 92.2L20.7 491.3l98.3-25.8c27.8 14.5 58.7 22.2 90.2 22.2 100.5 0 182.8-82.3 182.8-182.8 0-57.5-22.1-111.3-56.6-145.6zM235.1 449.1c-29.4 0-57.9-7.8-82.8-22.3l-5.9-3.5-61.6 16.2 16.5-60.2-3.8-6.1c-15.8-25.3-24-54.9-24-86.1 0-84.1 68.4-152.5 152.5-152.5 42.1 0 81.6 16.5 110.6 45.4 29 29 45.3 68.5 45.3 110.5 0 84.1-68.4 152.5-152.5 152.5zM325.2 304.3c-6.2-3.1-36.9-18.2-42.6-20.3-5.7-2.1-9.8-3.1-13.9 3.1-4.1 6.2-16.2 20.3-19.8 24.3-3.7 4.1-7.3 4.6-13.5 1.5-6.2-3.1-26.1-9.6-49.7-30.6-18.5-16.4-31-36.6-34.6-42.8-3.7-6.2-0.4-9.6 2.8-12.7 2.8-2.8 6.2-7.3 9.3-11.0 3.1-3.7 4.1-6.2 6.2-10.3 2.1-4.1 1.0-7.8-0.5-10.9-1.5-3.1-13.9-33.5-19-45.8-5.2-12.3-10.4-10.6-14.5-10.8-3.7-0.2-7.8-0.2-12-0.2-4.1 0-10.9 1.5-16.6 7.8-5.7 6.2-22.1 21.5-22.1 52.4 0 30.9 22.6 60.8 25.8 65.0 3.1 4.1 44.2 67.3 107.2 94.8 15.3 6.8 27.2 10.9 36.4 13.9 9.2 3.1 17.7 2.6 24.4 1.5 7.8-1.2 24.4-10.0 27.8-19.7 3.4-9.7 3.4-18.1 2.3-19.7-1.1-1.6-4.2-2.6-9.3-5.7z"/>
        </svg>
      </a>
    </>
  );
};

export default function Layout({ children }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-slate-100 font-sans">
        <Sidebar className="border-r border-slate-200 bg-white">
          <SidebarHeader>
            <div className="flex items-center gap-3 p-4">
              <div className="bg-gradient-to-br from-blue-600 to-green-600 p-2 rounded-lg">
                <Gavel className="w-6 h-6 text-white" />
              </div>
              <h1 className="font-bold text-xl text-slate-800">LegalTech AI</h1>
            </div>
          </SidebarHeader>
          <SidebarContent className="p-3">
            {navigationItems.map((item) => (
              <Link
                key={item.title}
                to={item.url}
                className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-slate-700 transition-colors hover:bg-slate-100 hover:text-slate-900 ${
                  location.pathname === item.url ? "bg-slate-100 text-slate-900 font-medium" : ""
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.title}</span>
              </Link>
            ))}
          </SidebarContent>
          <SidebarFooter className="border-t border-slate-100 p-4">
            <CNJStatusIndicator />
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col bg-slate-50">
          <header className="bg-white border-b border-slate-200 px-6 py-4 md:hidden">
            <div className="flex items-center justify-between">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors" />
              <div className="font-bold text-lg">LegalTech AI</div>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
            <Toaster position="top-right" richColors />
          </div>
        </main>
        <WhatsAppWidget />
      </div>
    </SidebarProvider>
  );
}

