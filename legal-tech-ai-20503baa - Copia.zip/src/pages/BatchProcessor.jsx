
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Loader2, Zap, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { anthropicBatch } from '@/api/functions';

export default function BatchProcessorPage() {
    const [requests, setRequests] = useState([
        { 
            custom_id: "consulta_1", 
            content: "Analise juridicamente: dano moral por negativação indevida",
            model: "claude-3-5-haiku-20241022"
        }
    ]);
    const [batchId, setBatchId] = useState('');
    const [batchStatus, setBatchStatus] = useState(null);
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(false);

    const addRequest = () => {
        setRequests([...requests, { 
            custom_id: `consulta_${requests.length + 1}`, 
            content: "",
            model: "claude-3-5-haiku-20241022"
        }]);
    };

    const updateRequest = (index, field, value) => {
        const newRequests = [...requests];
        newRequests[index][field] = value;
        setRequests(newRequests);
    };

    const removeRequest = (index) => {
        setRequests(requests.filter((_, i) => i !== index));
    };

    const createBatch = async () => {
        setLoading(true);
        try {
            const response = await anthropicBatch({
                operation: "create",
                requests: requests.filter(req => req.content.trim())
            });

            if (response.data.success) {
                setBatchId(response.data.batch_id);
                setBatchStatus(response.data);
                alert('Lote criado com sucesso!');
            } else {
                alert('Erro: ' + response.data.message);
            }
        } catch (error) {
            alert('Erro ao criar lote: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const checkStatus = async () => {
        if (!batchId) return;
        
        setLoading(true);
        try {
            const response = await anthropicBatch({
                operation: "status",
                batch_id: batchId
            });

            if (response.data.success) {
                setBatchStatus(response.data);
            }
        } catch (error) {
            alert('Erro ao verificar status: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const getResults = async () => {
        if (!batchId) return;
        
        setLoading(true);
        try {
            const response = await anthropicBatch({
                operation: "results",
                batch_id: batchId
            });

            if (response.data.success) {
                setResults(response.data.results);
            }
        } catch (error) {
            alert('Erro ao obter resultados: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'in_progress': return <Loader2 className="w-4 h-4 animate-spin text-blue-600" />;
            case 'ended': return <CheckCircle className="w-4 h-4 text-green-600" />;
            case 'canceled': return <AlertCircle className="w-4 h-4 text-red-600" />;
            default: return <Clock className="w-4 h-4 text-gray-600" />;
        }
    };

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-6xl mx-auto px-4">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900 mb-2 flex items-center gap-3">
                        <Zap className="w-8 h-8 text-purple-600" />
                        Processamento em Lote IA
                    </h1>
                    <p className="text-slate-600">Processe múltiplas consultas jurídicas simultaneamente com Claude</p>
                </div>

                {/* Configurar Requests */}
                <Card className="mb-6">
                    <CardHeader>
                        <CardTitle>Configurar Consultas</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {requests.map((req, index) => (
                            <div key={index} className="p-4 border rounded-lg space-y-3">
                                <div className="flex justify-between items-center">
                                    <Input
                                        placeholder="ID personalizado"
                                        value={req.custom_id}
                                        onChange={(e) => updateRequest(index, 'custom_id', e.target.value)}
                                        className="w-48"
                                    />
                                    <Button 
                                        variant="outline" 
                                        size="sm"
                                        onClick={() => removeRequest(index)}
                                    >
                                        Remover
                                    </Button>
                                </div>
                                
                                <Textarea
                                    placeholder="Digite sua consulta jurídica..."
                                    value={req.content}
                                    onChange={(e) => updateRequest(index, 'content', e.target.value)}
                                    rows={3}
                                />
                                
                                <select 
                                    value={req.model}
                                    onChange={(e) => updateRequest(index, 'model', e.target.value)}
                                    className="px-3 py-2 border rounded-md"
                                >
                                    <option value="claude-3-5-haiku-20241022">Claude 3.5 Haiku (Rápido)</option>
                                    <option value="claude-3-5-sonnet-20240620">Claude 3.5 Sonnet (Balanceado)</option>
                                    <option value="claude-3-opus-20240229">Claude 3 Opus (Poderoso)</option>
                                </select>
                            </div>
                        ))}
                        
                        <div className="flex gap-2">
                            <Button onClick={addRequest} variant="outline">
                                Adicionar Consulta
                            </Button>
                            <Button 
                                onClick={createBatch} 
                                disabled={loading || !requests.some(r => r.content.trim())}
                                className="bg-purple-600 hover:bg-purple-700"
                            >
                                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                                Criar Lote ({requests.filter(r => r.content.trim()).length} consultas)
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {/* Status do Lote */}
                {batchId && (
                    <Card className="mb-6">
                        <CardHeader>
                            <CardTitle>Status do Lote</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div className="flex items-center gap-3">
                                    <Badge variant="outline">ID: {batchId}</Badge>
                                    {batchStatus && (
                                        <Badge className="flex items-center gap-2">
                                            {getStatusIcon(batchStatus.status)}
                                            {batchStatus.status}
                                        </Badge>
                                    )}
                                </div>
                                
                                {batchStatus && (
                                    <div className="grid md:grid-cols-3 gap-4">
                                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                                            <div className="font-bold text-lg">{batchStatus.request_counts?.processing || 0}</div>
                                            <div className="text-sm text-gray-600">Processando</div>
                                        </div>
                                        <div className="text-center p-3 bg-green-50 rounded-lg">
                                            <div className="font-bold text-lg">{batchStatus.request_counts?.succeeded || 0}</div>
                                            <div className="text-sm text-gray-600">Concluídos</div>
                                        </div>
                                        <div className="text-center p-3 bg-red-50 rounded-lg">
                                            <div className="font-bold text-lg">{batchStatus.request_counts?.errored || 0}</div>
                                            <div className="text-sm text-gray-600">Com Erro</div>
                                        </div>
                                    </div>
                                )}
                                
                                <div className="flex gap-2">
                                    <Button onClick={checkStatus} variant="outline">
                                        Atualizar Status
                                    </Button>
                                    {batchStatus?.status === 'ended' && (
                                        <Button onClick={getResults} className="bg-green-600 hover:bg-green-700">
                                            Obter Resultados
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {/* Resultados */}
                {results.length > 0 && (
                    <Card>
                        <CardHeader>
                            <CardTitle>Resultados ({results.length})</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {results.map((result, index) => (
                                    <div key={index} className="p-4 border rounded-lg">
                                        <div className="flex justify-between items-start mb-3">
                                            <Badge variant="outline">{result.custom_id}</Badge>
                                            <Badge className={result.result.type === 'succeeded' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                                                {result.result.type}
                                            </Badge>
                                        </div>
                                        
                                        {result.result.type === 'succeeded' ? (
                                            <div className="bg-slate-50 p-3 rounded-lg">
                                                <p className="whitespace-pre-wrap">
                                                    {result.result.message?.content?.[0]?.text || 'Sem resposta'}
                                                </p>
                                            </div>
                                        ) : (
                                            <div className="bg-red-50 p-3 rounded-lg text-red-700">
                                                <p>Erro: {result.result.error?.message || 'Erro desconhecido'}</p>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
