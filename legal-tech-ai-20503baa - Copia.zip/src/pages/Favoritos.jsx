
import React, { useState, useEffect, useCallback } from 'react';
import { Pasta } from '@/api/entities';
import { Jurisprudencia } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Loader2, Folder, FileText, PlusCircle, Trash2, ExternalLink, StickyNote } from 'lucide-react';
import { toast } from 'sonner';
import AddAnnotationDialog from '../components/annotations/AddAnnotationDialog';
import AnnotationsList from '../components/annotations/AnnotationsList';

export default function FavoritosPage() {
    const [pastas, setPastas] = useState([]);
    const [casos, setCasos] = useState({}); // { pastaId: [casos...] }
    const [loading, setLoading] = useState(true);
    const [user, setUser] = useState(null);
    const [newPastaName, setNewPastaName] = useState('');
    const [isCreating, setIsCreating] = useState(false);
    const [loadingCasos, setLoadingCasos] = useState({});

    // Estados para anotações
    const [showAddAnnotation, setShowAddAnnotation] = useState(false);
    const [selectedCasoForAnnotation, setSelectedCasoForAnnotation] = useState(null);
    const [annotationRefresh, setAnnotationRefresh] = useState(0);

    const loadPastas = useCallback(async (email) => {
        setLoading(true);
        try {
            const data = await Pasta.filter({ created_by: email }, "-updated_date");
            setPastas(data);
        } catch (error) {
            console.error('Erro ao carregar pastas:', error);
            toast.error("Falha ao carregar suas pastas.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        const fetchInitialData = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                await loadPastas(currentUser.email);
            } catch (error) {
                toast.error("Faça login para ver e gerenciar suas pastas.");
                setLoading(false);
            }
        };
        fetchInitialData();
    }, [loadPastas]);

    const handleCreatePasta = async () => {
        if (!newPastaName.trim()) {
            toast.warning("O nome da pasta não pode ser vazio.");
            return;
        }
        if (!user) return;
        setIsCreating(true);
        try {
            await Pasta.create({ nome: newPastaName, descricao: "" });
            toast.success(`Pasta "${newPastaName}" criada com sucesso!`);
            setNewPastaName('');
            await loadPastas(user.email);
        } catch (error) {
            console.error('Erro ao criar pasta:', error);
            toast.error("Falha ao criar pasta.");
        } finally {
            setIsCreating(false);
        }
    };

    const handleLoadCasos = async (pastaId) => {
        if (casos[pastaId] || loadingCasos[pastaId]) return;

        setLoadingCasos(prev => ({ ...prev, [pastaId]: true }));
        try {
            const pasta = pastas.find(p => p.id === pastaId);
            if (!pasta || !pasta.itens_salvos || pasta.itens_salvos.length === 0) {
                setCasos(prev => ({ ...prev, [pastaId]: [] }));
                return;
            }

            const ids = pasta.itens_salvos.map(item => item.id_item);
            
            const promises = ids.map(id => Jurisprudencia.filter({ processo: id }));
            const results = await Promise.all(promises);
            const casosFiltrados = results.flat().filter(Boolean);

            setCasos(prev => ({ ...prev, [pastaId]: casosFiltrados }));

        } catch (error) {
            console.error('Erro ao carregar casos:', error);
            toast.error("Não foi possível carregar os casos desta pasta.");
        } finally {
            setLoadingCasos(prev => ({ ...prev, [pastaId]: false }));
        }
    };

    const handleRemoveCaso = async (pastaId, casoProcesso) => {
        try {
            const pasta = await Pasta.get(pastaId);
            const novosItens = pasta.itens_salvos.filter(item => item.id_item !== casoProcesso);
            await Pasta.update(pastaId, { itens_salvos: novosItens });

            setCasos(prev => ({
                ...prev,
                [pastaId]: prev[pastaId].filter(c => c.processo !== casoProcesso)
            }));
            
            toast.success("Caso removido da pasta.");
        } catch(error) {
            console.error("Erro ao remover caso:", error);
            toast.error("Falha ao remover o caso da pasta.");
        }
    };
    
    const handleRemovePasta = async (pastaId) => {
        if (!confirm("Tem certeza que deseja apagar esta pasta e todo o seu conteúdo?")) return;
        
        try {
            await Pasta.delete(pastaId);
            setPastas(prev => prev.filter(p => p.id !== pastaId));
            toast.success("Pasta removida com sucesso.");
        } catch(error) {
            console.error("Erro ao remover pasta:", error);
            toast.error("Falha ao remover a pasta.");
        }
    };

    const handleAddAnnotation = (caso) => {
        setSelectedCasoForAnnotation(caso);
        setShowAddAnnotation(true);
    };

    const handleAnnotationAdded = () => {
        setAnnotationRefresh(prev => prev + 1);
    };

    if (!user && !loading) {
        return (
            <div className="py-8 bg-slate-50 min-h-screen text-center">
                 <h1 className="text-xl font-bold text-slate-800">Acesso Negado</h1>
                 <p className="text-slate-600">Por favor, faça login para acessar suas pastas.</p>
            </div>
        )
    }

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-6xl mx-auto px-4">
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
                        <Folder className="w-8 h-8 text-blue-600" />
                        Minhas Pastas
                    </h1>
                </div>

                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle className="text-lg">Criar Nova Pasta</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="flex gap-2">
                            <Input
                                placeholder="Nome da nova pasta..."
                                value={newPastaName}
                                onChange={(e) => setNewPastaName(e.target.value)}
                            />
                            <Button onClick={handleCreatePasta} disabled={isCreating}>
                                {isCreating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlusCircle className="mr-2 h-4 w-4" />}
                                Criar
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {loading ? (
                    <div className="text-center py-10">
                        <Loader2 className="mx-auto h-12 w-12 animate-spin text-blue-600" />
                        <p className="mt-4 text-slate-600">Carregando suas pastas...</p>
                    </div>
                ) : pastas.length === 0 ? (
                    <div className="text-center py-10 bg-white rounded-lg shadow">
                        <Folder className="mx-auto h-12 w-12 text-slate-400" />
                        <h3 className="mt-4 text-lg font-medium text-slate-800">Nenhuma pasta encontrada</h3>
                        <p className="mt-1 text-sm text-slate-500">Crie sua primeira pasta para começar a organizar seus casos.</p>
                    </div>
                ) : (
                    <Accordion type="single" collapsible className="w-full space-y-2">
                        {pastas.map(pasta => (
                            <AccordionItem key={pasta.id} value={pasta.id} className="bg-white rounded-lg border">
                                <AccordionTrigger 
                                    className="px-6 py-4 hover:no-underline"
                                    onClick={() => handleLoadCasos(pasta.id)}
                                >
                                    <div className="flex justify-between items-center w-full">
                                        <div className="flex items-center gap-3">
                                            <Folder className="w-5 h-5 text-blue-500" />
                                            <span className="font-semibold text-lg">{pasta.nome}</span>
                                            <Badge variant="secondary">{(pasta.itens_salvos || []).length} itens</Badge>
                                        </div>
                                        <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleRemovePasta(pasta.id);}}>
                                            <Trash2 className="w-4 h-4 text-red-500"/>
                                        </Button>
                                    </div>
                                </AccordionTrigger>
                                <AccordionContent className="p-4 bg-slate-50/50">
                                    {loadingCasos[pasta.id] ? (
                                        <p className="text-center p-4"><Loader2 className="h-5 w-5 animate-spin inline-block mr-2" /> Carregando casos...</p>
                                    ) : !casos[pasta.id] || casos[pasta.id].length === 0 ? (
                                        <p className="text-center p-4 text-slate-500">Esta pasta está vazia.</p>
                                    ) : (
                                        <div className="space-y-6">
                                            {casos[pasta.id].map(caso => (
                                                <div key={caso.id} className="space-y-4">
                                                    <Card className="bg-white">
                                                        <CardHeader>
                                                            <CardTitle className="text-base flex items-center justify-between">
                                                                <span className="flex items-center gap-2">
                                                                    <FileText className="w-4 h-4 text-green-600" />
                                                                    {caso.processo}
                                                                </span>
                                                                <Badge variant="outline">{caso.tribunal}</Badge>
                                                            </CardTitle>
                                                        </CardHeader>
                                                        <CardContent>
                                                            <p className="text-sm text-slate-600 line-clamp-2 mb-4">{caso.ementa}</p>
                                                        </CardContent>
                                                        <CardFooter className="flex justify-between">
                                                            <Button variant="outline" size="sm" onClick={() => handleAddAnnotation(caso)}>
                                                                <StickyNote className="w-4 h-4 mr-2" /> Adicionar Nota
                                                            </Button>
                                                            <div className="flex gap-2">
                                                                <Button variant="outline" size="sm" asChild>
                                                                    <a href={`https://www.google.com/search?q=${caso.processo}`} target="_blank" rel="noopener noreferrer">
                                                                        <ExternalLink className="w-4 h-4 mr-2" /> Ver processo
                                                                    </a>
                                                                </Button>
                                                                <Button variant="destructive" size="sm" onClick={() => handleRemoveCaso(pasta.id, caso.processo)}>
                                                                    <Trash2 className="w-4 h-4 mr-2" /> Remover
                                                                </Button>
                                                            </div>
                                                        </CardFooter>
                                                    </Card>

                                                    {/* Lista de Anotações para este caso */}
                                                    <Card className="bg-orange-50/30 border-orange-200">
                                                        <CardContent className="p-4">
                                                            <AnnotationsList 
                                                                caso={caso} 
                                                                refreshTrigger={annotationRefresh}
                                                            />
                                                        </CardContent>
                                                    </Card>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </AccordionContent>
                            </AccordionItem>
                        ))}
                    </Accordion>
                )}
            </div>

            <AddAnnotationDialog
                open={showAddAnnotation}
                onOpenChange={setShowAddAnnotation}
                caso={selectedCasoForAnnotation}
                onAnnotationAdded={handleAnnotationAdded}
            />
        </div>
    );
}
