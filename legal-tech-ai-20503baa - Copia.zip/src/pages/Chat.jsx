
import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Bot, User, Loader2 } from 'lucide-react'; // Added Loader2
import { InvokeLLM } from '@/api/integrations';
import { buscarJurisprudencia } from '@/api/functions';
// Added Card components
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// Corrigido o caminho da importação da entidade Consulta
import { Consulta } from '@/api/entities';
import { judyPersonaSystemPrompt } from '@/components/personas/Judy'; // Caminho corrigido

export default function ChatPage() {
    const [messages, setMessages] = useState([
        {
            role: 'assistant',
            content: 'Olá! Sou Judy, sua assistente jurídica especialista. Como posso ajudá-lo hoje a navegar pelas complexidades do direito brasileiro com análises precisas e fundamentadas?'
        }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [selectedTribunal, setSelectedTribunal] = useState('tjsp'); // New state for selected tribunal
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    // Define available tribunals
    const tribunais = [
        { value: 'tjsp', label: 'TJSP - São Paulo' },
        { value: 'tjrj', label: 'TJRJ - Rio de Janeiro' },
        { value: 'tjmg', label: 'TJMG - Minas Gerais' },
        { value: 'tjrs', label: 'TJRS - Rio Grande do Sul' },
        { value: 'tjpr', label: 'TJPR - Paraná' },
        { value: 'tjsc', label: 'TJSC - Santa Catarina' },
        { value: 'tjdft', label: 'TJDFT - Distrito Federal' }
    ];

    const handleSendMessage = async () => {
        if (!input.trim()) return;

        const userMessage = { role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        const currentInput = input;
        setInput('');
        setIsLoading(true);

        const startTime = Date.now();

        try {
            // Detectar se é consulta sobre jurisprudência com mais termos
            const isJurisprudenceQuery = /jurisprud[eê]ncia|decis[õa]o|acórd[ãa]o|entendimento|precedente|julgado|súmula/i.test(currentInput);

            let context = '';
            let cnjSources = 0; // To track how many CNJ sources were used

            if (isJurisprudenceQuery) {
                try {
                    const jurisprudenceResponse = await buscarJurisprudencia({
                        termo: currentInput,
                        tribunal: selectedTribunal, // Use selected tribunal
                        tamanho: 5 // Request more results
                    });

                    if (jurisprudenceResponse.data.success && jurisprudenceResponse.data.jurisprudencias.length > 0) {
                        cnjSources = jurisprudenceResponse.data.jurisprudencias.length;
                        context = `\n\nDADOS OFICIAIS DO CNJ DATAJUD sobre "${currentInput}":\n\n`;

                        jurisprudenceResponse.data.jurisprudencias.forEach((juris, index) => {
                            context += `${index + 1}. **${juris.tribunal} - Processo ${juris.numeroProcesso}**\n`;
                            context += `   • Órgão: ${juris.orgaoJulgador || 'N/A'}\n`; // Added orgaoJulgador
                            context += `   • Assuntos: ${juris.assuntos.join(', ')}\n`;
                            if (juris.ementa) {
                                context += `   • Ementa: ${juris.ementa.substring(0, 400)}...\n`; // Longer ementa preview
                            }
                            context += `   • Relevância: ${juris.relevancia}\n\n`; // Added relevancia
                        });

                        // Added total results and tribunal name
                        context += `\nTotal encontrado: ${jurisprudenceResponse.data.total} precedentes no ${jurisprudenceResponse.data.tribunal_nome}\n`;
                    }
                } catch (error) {
                    console.log('Erro ao buscar jurisprudência:', error);
                }
            }

            const response = await InvokeLLM({
                system: judyPersonaSystemPrompt, // Usar a persona da Judy
                prompt: `Com base nos dados do CNJ e no seu conhecimento, responda à seguinte pergunta do usuário, seguindo estritamente suas diretrizes de atuação como advogada especialista.

PERGUNTA DO USUÁRIO: "${currentInput}"

${context}

${context ? 'IMPORTANTE: Baseie sua resposta nos dados oficiais do CNJ fornecidos acima. Cite os números dos processos e tribunais específicos.' : 'Forneça uma resposta completa baseada no conhecimento jurídico brasileiro.'}`,
                model: 'claude-3-5-sonnet-20240620' // Usar um modelo mais avançado
            });

            const responseTime = Date.now() - startTime;

            // Salvar consulta no histórico
            try {
                await Consulta.create({
                    tipo: 'chat',
                    termo_busca: currentInput,
                    tribunal: selectedTribunal,
                    resultado: { pergunta: currentInput, resposta: response },
                    sucesso: true,
                    tempo_resposta: responseTime,
                    fontes_cnj: cnjSources
                });
            } catch (error) {
                console.log('Erro ao salvar consulta:', error);
            }

            const assistantMessage = {
                role: 'assistant',
                content: response,
                metadata: { // Added metadata for UI display
                    cnjSources,
                    tribunal: selectedTribunal,
                    timestamp: new Date().toISOString()
                }
            };
            setMessages(prev => [...prev, assistantMessage]);
        } catch (error) {
            const errorMessage = {
                role: 'assistant',
                content: '❌ Desculpe, ocorreu um erro ao processar sua solicitação. Verifique sua conexão e tente novamente.'
            };
            setMessages(prev => [...prev, errorMessage]);

            // Salvar erro no histórico
            try {
                await Consulta.create({
                    tipo: 'chat',
                    termo_busca: currentInput,
                    tribunal: selectedTribunal,
                    resultado: { pergunta: currentInput, erro: error.message },
                    sucesso: false,
                    tempo_resposta: Date.now() - startTime,
                    fontes_cnj: 0
                });
            } catch (saveError) {
                console.log('Erro ao salvar erro:', saveError);
            }

            console.error("Erro ao chamar a IA:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const setQuickMessage = (message) => {
        setInput(message);
    };

    // More diverse quick questions with categories and icons
    const quickQuestions = [
        {
            text: `Jurisprudência sobre dano moral no ${tribunais.find(t => t.value === selectedTribunal)?.label.split(' - ')[0]}`,
            category: 'Jurisprudência',
            icon: '⚖️'
        },
        {
            text: 'Entendimento recente sobre direitos trabalhistas',
            category: 'Trabalhista',
            icon: '👷'
        },
        {
            text: 'Precedentes sobre responsabilidade civil',
            category: 'Civil',
            icon: '📋'
        },
        {
            text: 'Decisões sobre direito do consumidor',
            category: 'Consumidor',
            icon: '🛒'
        },
        {
            text: 'Jurisprudência recente sobre contratos',
            category: 'Contratos',
            icon: '📄'
        },
        {
            text: 'Entendimento sobre pensão alimentícia',
            category: 'Família',
            icon: '👨‍👩‍👧‍👦'
        }
    ];

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-6xl mx-auto px-4">
                <Card className="rounded-2xl shadow-xl bg-white">
                    <CardHeader className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white rounded-t-2xl p-6 md:p-8"> {/* Improved header styling */}
                        <div className="flex items-center justify-between">
                            <div>
                                <CardTitle className="text-3xl font-bold mb-2 flex items-center gap-3">
                                    <Bot className="w-8 h-8" />
                                    Chat IA Jurídica
                                </CardTitle>
                                <p className="opacity-90 text-lg">
                                    Integrado com dados oficiais CNJ DataJud
                                </p>
                            </div>
                            <div className="text-right">
                                <div className="flex items-center space-x-2 mb-2">
                                    <span className="w-3 h-3 bg-green-300 rounded-full animate-pulse"></span>
                                    <span className="text-sm font-medium">CNJ Online</span>
                                </div>
                                {/* Tribunal selection dropdown */}
                                <select
                                    value={selectedTribunal}
                                    onChange={(e) => setSelectedTribunal(e.target.value)}
                                    className="bg-white/20 text-white border border-white/30 rounded px-3 py-1 text-sm backdrop-blur"
                                >
                                    {tribunais.map(t => (
                                        <option key={t.value} value={t.value} className="text-gray-900">
                                            {t.label}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="p-6">
                        <div id="chat-messages" className="h-96 overflow-y-auto border border-slate-200 rounded-xl p-4 mb-6 bg-slate-50 space-y-4 custom-scroll">
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex items-start gap-4 animate-slideUp ${
                                    msg.role === 'user' ? 'justify-end' : '' // Align user messages to the right
                                }`}>
                                    {msg.role === 'assistant' && (
                                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-600 to-emerald-600 flex items-center justify-center flex-shrink-0">
                                            <Bot className="w-5 h-5 text-white" />
                                        </div>
                                    )}
                                    <div className={`px-4 py-3 rounded-2xl max-w-[85%] ${
                                        msg.role === 'user'
                                            ? 'bg-slate-700 text-white rounded-br-md' // User message styling
                                            : 'bg-white text-slate-800 shadow-sm border' // Assistant message styling
                                    }`}>
                                        <div className="text-sm whitespace-pre-wrap leading-relaxed">
                                            {msg.content}
                                        </div>
                                        {/* Display CNJ source metadata if available */}
                                        {msg.metadata?.cnjSources > 0 && (
                                            <div className="mt-3 pt-3 border-t border-slate-200">
                                                <div className="flex items-center gap-2 text-xs text-green-700 bg-green-50 px-2 py-1 rounded-full w-fit">
                                                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                                                    {msg.metadata.cnjSources} fonte(s) CNJ DataJud • {msg.metadata.tribunal.toUpperCase()}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                    {msg.role === 'user' && (
                                        <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                                            <User className="w-5 h-5 text-white" />
                                        </div>
                                    )}
                                </div>
                            ))}

                            {isLoading && (
                                <div className="flex items-start gap-4 animate-slideUp">
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-600 to-emerald-600 flex items-center justify-center">
                                        <Bot className="w-5 h-5 text-white" />
                                    </div>
                                    <div className="px-4 py-3 rounded-2xl bg-white shadow-sm border">
                                        <div className="flex items-center gap-3 text-sm">
                                            <div className="flex gap-1">
                                                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                                                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                                                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                                            </div>
                                            <span className="text-slate-600">Consultando IA + CNJ DataJud...</span>
                                        </div>
                                    </div>
                                </div>
                            )}
                            <div ref={messagesEndRef} />
                        </div>

                        <div className="space-y-4">
                            <div className="flex space-x-4">
                                <Input
                                    type="text"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    // Handle Enter key for sending, but allow Shift+Enter for new line
                                    onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                                    placeholder="Digite sua pergunta jurídica..."
                                    className="flex-1 border-slate-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent h-12 text-base"
                                    disabled={isLoading}
                                />
                                <Button
                                    onClick={handleSendMessage}
                                    disabled={isLoading || !input.trim()} // Disable if input is empty
                                    className="bg-blue-600 text-white px-8 py-3 rounded-xl hover:bg-blue-700 transition-all font-medium h-12 min-w-[100px]"
                                >
                                    {isLoading ? (
                                        <Loader2 className="w-5 h-5 animate-spin" /> // Show spinner when loading
                                    ) : (
                                        'Enviar'
                                    )}
                                </Button>
                            </div>

                            <div>
                                <p className="text-sm text-slate-600 mb-3 font-medium">
                                    💡 Perguntas sugeridas com dados do {tribunais.find(t => t.value === selectedTribunal)?.label}: {/* Dynamic tribunal name */}
                                </p>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2"> {/* Grid layout for suggestions */}
                                    {quickQuestions.map((question, index) => (
                                        <Button
                                            key={index}
                                            onClick={() => setQuickMessage(question.text)}
                                            variant="outline"
                                            size="sm"
                                            className="text-left justify-start p-3 h-auto hover:bg-slate-50 border-slate-200 rounded-lg"
                                        >
                                            <div>
                                                <div className="flex items-center gap-2 mb-1">
                                                    <span>{question.icon}</span>
                                                    <span className="text-xs font-medium text-slate-500">{question.category}</span>
                                                </div>
                                                <div className="text-sm text-slate-700">{question.text}</div>
                                            </div>
                                        </Button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
