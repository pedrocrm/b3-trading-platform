
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Search, FileText, Scale, Clock, CheckCircle, Users, Calendar } from 'lucide-react';
import { Consulta } from '@/api/entities';
import { Favorito } from '@/api/entities';
import { Relatorio } from '@/api/entities';

export default function DashboardPage() {
    const [stats, setStats] = useState({
        consultas: [],
        favoritos: [],
        relatorios: [],
        loading: true
    });

    useEffect(() => {
        loadDashboardData();
    }, []);

    const loadDashboardData = async () => {
        try {
            const [consultasData, favoritosData, relatoriosData] = await Promise.all([
                Consulta.list('-created_date', 50),
                Favorito.list('-created_date', 20),
                Relatorio.list('-created_date', 10)
            ]);

            setStats({
                consultas: consultasData,
                favoritos: favoritosData,
                relatorios: relatoriosData,
                loading: false
            });
        } catch (error) {
            console.error('Erro ao carregar dashboard:', error);
            setStats(prev => ({ ...prev, loading: false }));
        }
    };

    if (stats.loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    // Calcular métricas
    const totalConsultas = stats.consultas.length;
    const consultasSucesso = stats.consultas.filter(c => c.sucesso).length;
    const tempoMedio = stats.consultas.reduce((acc, c) => acc + (c.tempo_resposta || 0), 0) / totalConsultas || 0;
    const fontesCNJTotal = stats.consultas.reduce((acc, c) => acc + (c.fontes_cnj || 0), 0);

    // Dados para gráficos
    const consultasPorTipo = [
        { name: 'Chat IA', value: stats.consultas.filter(c => c.tipo === 'chat').length, fill: '#3b82f6' },
        { name: 'Processos', value: stats.consultas.filter(c => c.tipo === 'processo').length, fill: '#10b981' },
        { name: 'Jurisprudência', value: stats.consultas.filter(c => c.tipo === 'jurisprudencia').length, fill: '#8b5cf6' },
        { name: 'Documentos', value: stats.consultas.filter(c => c.tipo === 'documento').length, fill: '#f59e0b' }
    ];

    const consultasPorDia = stats.consultas
        .reduce((acc, consulta) => {
            const data = new Date(consulta.created_date).toLocaleDateString('pt-BR');
            acc[data] = (acc[data] || 0) + 1;
            return acc;
        }, {});

    const dadosTemporais = Object.entries(consultasPorDia)
        .map(([data, quantidade]) => ({ data, quantidade }))
        .slice(-7)
        .reverse();

    return (
        <div className="py-8 bg-slate-50 min-h-screen">
            <div className="max-w-7xl mx-auto px-4">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900 mb-2">Dashboard Analytics</h1>
                    <p className="text-slate-600">Análise completa do uso da LegalTech AI com dados CNJ</p>
                </div>

                {/* Cards de Métricas */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">Total de Consultas</p>
                                    <p className="text-2xl font-bold text-slate-900">{totalConsultas}</p>
                                    <p className="text-xs text-green-600 flex items-center mt-1">
                                        <TrendingUp className="w-3 h-3 mr-1" />
                                        {Math.round((consultasSucesso / totalConsultas) * 100)}% sucesso
                                    </p>
                                </div>
                                <Search className="w-8 h-8 text-blue-600" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">Fontes CNJ</p>
                                    <p className="text-2xl font-bold text-slate-900">{fontesCNJTotal}</p>
                                    <p className="text-xs text-blue-600 flex items-center mt-1">
                                        <Scale className="w-3 h-3 mr-1" />
                                        Dados oficiais
                                    </p>
                                </div>
                                <Scale className="w-8 h-8 text-green-600" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">Tempo Médio</p>
                                    <p className="text-2xl font-bold text-slate-900">{Math.round(tempoMedio)}ms</p>
                                    <p className="text-xs text-slate-500 flex items-center mt-1">
                                        <Clock className="w-3 h-3 mr-1" />
                                        Resposta rápida
                                    </p>
                                </div>
                                <Clock className="w-8 h-8 text-purple-600" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">Favoritos</p>
                                    <p className="text-2xl font-bold text-slate-900">{stats.favoritos.length}</p>
                                    <p className="text-xs text-orange-600 flex items-center mt-1">
                                        <CheckCircle className="w-3 h-3 mr-1" />
                                        Itens salvos
                                    </p>
                                </div>
                                <FileText className="w-8 h-8 text-orange-600" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Gráficos */}
                <div className="grid lg:grid-cols-2 gap-6 mb-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <BarChart className="w-5 h-5" />
                                Consultas por Tipo
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <PieChart>
                                    <Pie
                                        data={consultasPorTipo}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={60}
                                        outerRadius={120}
                                        dataKey="value"
                                    >
                                        {consultasPorTipo.map((entry, index) => (
                                            <Cell key={index} fill={entry.fill} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                            <div className="flex justify-center gap-4 mt-4">
                                {consultasPorTipo.map((item, index) => (
                                    <div key={index} className="flex items-center gap-2">
                                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.fill }}></div>
                                        <span className="text-sm text-slate-600">{item.name}</span>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Calendar className="w-5 h-5" />
                                Atividade dos Últimos 7 Dias
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={dadosTemporais}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="data" />
                                    <YAxis />
                                    <Tooltip />
                                    <Bar dataKey="quantidade" fill="#3b82f6" />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                </div>

                {/* Consultas Recentes */}
                <Card>
                    <CardHeader>
                        <CardTitle>Consultas Recentes</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {stats.consultas.slice(0, 10).map((consulta, index) => (
                                <div key={index} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                                    <div className="flex items-center gap-4">
                                        <Badge variant={consulta.sucesso ? "default" : "destructive"}>
                                            {consulta.tipo}
                                        </Badge>
                                        <div>
                                            <p className="font-medium text-slate-900">
                                                {consulta.termo_busca.substring(0, 50)}...
                                            </p>
                                            <p className="text-sm text-slate-500">
                                                {new Date(consulta.created_date).toLocaleString('pt-BR')}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        {consulta.fontes_cnj > 0 && (
                                            <Badge variant="outline" className="mb-1">
                                                {consulta.fontes_cnj} fontes CNJ
                                            </Badge>
                                        )}
                                        <p className="text-xs text-slate-500">
                                            {consulta.tempo_resposta}ms
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
