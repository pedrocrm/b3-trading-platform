
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Anotacao } from "@/api/entities";
import { Loader2, Edit, Trash2, StickyNote, Calendar } from 'lucide-react';
import { toast } from 'sonner';

export default function AnnotationsList({ caso, refreshTrigger = 0 }) {
  const [anotacoes, setAnotacoes] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadAnotacoes = useCallback(async () => {
    setLoading(true);
    try {
      const notas = await Anotacao.filter({ 
        id_item_associado: caso.processo 
      }, '-created_date');
      setAnotacoes(notas);
    } catch (error) {
      console.error("Erro ao carregar anotações:", error);
      toast.error("Falha ao carregar anotações.");
    } finally {
      setLoading(false);
    }
  }, [caso.processo]); // `caso.processo` is a dependency as it's used inside loadAnotacoes

  useEffect(() => {
    loadAnotacoes();
  }, [loadAnotacoes, refreshTrigger]); // `loadAnotacoes` is now a stable reference due to useCallback, and refreshTrigger triggers a reload

  const handleDelete = async (anotacaoId) => {
    if (!confirm("Tem certeza que deseja excluir esta anotação?")) return;
    
    try {
      await Anotacao.delete(anotacaoId);
      setAnotacoes(prev => prev.filter(a => a.id !== anotacaoId));
      toast.success("Anotação excluída.");
    } catch (error) {
      console.error("Erro ao excluir anotação:", error);
      toast.error("Falha ao excluir anotação.");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
        <span className="ml-2 text-slate-600">Carregando anotações...</span>
      </div>
    );
  }

  if (anotacoes.length === 0) {
    return (
      <div className="text-center p-8">
        <StickyNote className="h-12 w-12 text-slate-400 mx-auto mb-4" />
        <p className="text-slate-500">Nenhuma anotação encontrada para este caso.</p>
        <p className="text-sm text-slate-400 mt-1">
          Clique em "Adicionar Nota" para criar sua primeira anotação.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-lg flex items-center gap-2">
        <StickyNote className="w-5 h-5 text-orange-600" />
        Minhas Anotações ({anotacoes.length})
      </h3>
      
      {anotacoes.map((anotacao) => (
        <Card key={anotacao.id} className="bg-orange-50 border-orange-200">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-start">
              <CardTitle className="text-base text-orange-900">
                {anotacao.titulo}
              </CardTitle>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" onClick={() => handleDelete(anotacao.id)}>
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs text-orange-600">
              <Calendar className="w-3 h-3" />
              {new Date(anotacao.created_date).toLocaleDateString('pt-BR')}
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-sm text-slate-700 mb-3 whitespace-pre-wrap">
              {anotacao.conteudo}
            </p>
            {anotacao.tags && anotacao.tags.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {anotacao.tags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="text-xs bg-orange-100 text-orange-700">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
