import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Anotacao } from "@/api/entities";
import { toast } from "sonner";
import { Loader2, Tag } from 'lucide-react';

export default function AddAnnotationDialog({ open, onOpenChange, caso, onAnnotationAdded }) {
  const [titulo, setTitulo] = useState('');
  const [conteudo, setConteudo] = useState('');
  const [tags, setTags] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    if (!conteudo.trim()) {
      toast.warning("O conteúdo da anotação é obrigatório.");
      return;
    }

    setLoading(true);
    try {
      const tagsArray = tags.split(',').map(t => t.trim()).filter(Boolean);
      
      await Anotacao.create({
        titulo: titulo.trim() || `Nota sobre ${caso.processo}`,
        conteudo: conteudo.trim(),
        tags: tagsArray,
        id_item_associado: caso.processo,
        entidade_associada: 'Jurisprudencia'
      });

      toast.success("Anotação salva com sucesso!");
      onAnnotationAdded?.();
      onOpenChange(false);
      
      // Limpar campos
      setTitulo('');
      setConteudo('');
      setTags('');
    } catch (error) {
      console.error("Erro ao salvar anotação:", error);
      toast.error("Falha ao salvar a anotação.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Adicionar Anotação</DialogTitle>
          <p className="text-sm text-slate-600">
            Processo: {caso?.processo}
          </p>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <label className="text-sm font-medium mb-2 block">
              Título (opcional)
            </label>
            <Input
              placeholder="Título da anotação..."
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
            />
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">
              Conteúdo *
            </label>
            <Textarea
              placeholder="Suas anotações sobre este caso..."
              value={conteudo}
              onChange={(e) => setConteudo(e.target.value)}
              rows={6}
              className="resize-none"
            />
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block flex items-center gap-2">
              <Tag className="w-4 h-4" />
              Tags (separadas por vírgula)
            </label>
            <Input
              placeholder="Ex: importante, revisão, cliente-x"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={loading || !conteudo.trim()}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Salvar Anotação
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}