import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Brain, Sparkles, Wand2 } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function SemanticSearch({ onSearch, loading }) {
  const [query, setQuery] = useState('');
  const [conceptualSearch, setConceptualSearch] = useState(false);

  const handleSearch = () => {
    onSearch(query, conceptualSearch);
  };

  return (
    <div className="p-4 bg-purple-50 rounded-lg border border-purple-200 space-y-4">
      <Textarea
        placeholder="Descreva o que você procura em linguagem natural. Ex: 'casos de dano moral por inscrição indevida no SERASA em São Paulo'"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="text-lg bg-white"
        rows={4}
      />
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center space-x-2">
          <Switch 
            id="conceptual-search" 
            checked={conceptualSearch}
            onCheckedChange={setConceptualSearch}
          />
          <Label htmlFor="conceptual-search" className="flex items-center gap-2 text-purple-800">
            <Brain className="w-4 h-4" />
            Busca Conceitual (IA mais profunda)
          </Label>
        </div>
        <Button 
            size="lg" 
            onClick={handleSearch} 
            disabled={loading || !query.trim()}
            className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700"
        >
          {loading ? 'Analisando...' : <><Wand2 className="w-5 h-5 mr-2" /> Pesquisar com IA</>}
        </Button>
      </div>
    </div>
  );
}