import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileText, Calendar, Gavel, User, CheckCircle } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function ProcessoDetalhadoCard({ processo }) {
    if (!processo) return null;

    const formatarData = (data) => {
        if (!data) return 'Não informado';
        try {
            return format(parseISO(data), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
        } catch {
            return data;
        }
    };
    
    return (
        <Card className="bg-green-50 border-green-200">
             <CardHeader>
                <CardTitle className="flex items-center justify-between text-green-800">
                    <div className="flex items-center gap-3">
                        <CheckCircle className="w-6 h-6" /> Processo Encontrado
                    </div>
                    <Badge className="bg-green-100 text-green-800 border-green-300">
                        CNJ DataJud
                    </Badge>
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <h3 className="text-lg font-mono text-slate-800 mb-2">{processo.numero}</h3>
                     <div className="flex flex-wrap gap-2">
                        <Badge variant="outline">{processo.tribunal}</Badge>
                        <Badge variant="outline">{processo.classe}</Badge>
                     </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <p><strong>Órgão Julgador:</strong> {processo.orgaoJulgador || 'Não informado'}</p>
                    <p><strong>Data Distribuição:</strong> {formatarData(processo.dataDistribuicao)}</p>
                    <p><strong>Assunto:</strong> {processo.assunto || 'Não informado'}</p>
                     {processo.valorCausa && <p><strong>Valor da Causa:</strong> {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(processo.valorCausa)}</p>}
                </div>

                {processo.partes?.length > 0 && (
                    <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2"><User className="w-4 h-4"/>Partes</h4>
                        <div className="space-y-1 text-sm">
                            {processo.partes.map((p, i) => <div key={i} className="flex justify-between p-2 bg-white rounded-md"><span>{p.nome}</span><Badge variant="secondary">{p.tipo}</Badge></div>)}
                        </div>
                    </div>
                )}
                
                {processo.movimentacoes?.length > 0 && (
                    <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2"><Gavel className="w-4 h-4"/>Últimas Movimentações</h4>
                        <div className="space-y-2 text-sm">
                            {processo.movimentacoes.map((m, i) => (
                                <div key={i} className="p-2 border-l-2 border-blue-300 bg-white">
                                    <p className="font-medium">{m.descricao}</p>
                                    <p className="text-xs text-slate-500">{formatarData(m.data)}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

            </CardContent>
        </Card>
    );
}