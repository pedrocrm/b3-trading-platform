import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Calendar, Building2, User, Gavel, X, Download } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function CaseDetail({ case: caso, onClose }) {
  if (!caso) return null;

  return (
    <Card className="sticky top-8 border-blue-200 shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between bg-slate-50">
        <CardTitle className="text-lg">Detalhes do Caso</CardTitle>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div>
          <h3 className="font-bold text-xl text-slate-800 mb-2">{caso.processo}</h3>
          <div className="flex flex-wrap gap-2">
            {caso.categoria_automatica && <Badge>{caso.categoria_automatica}</Badge>}
          </div>
        </div>
        <div className="text-sm space-y-2">
          <p className="flex items-center gap-2"><Building2 className="w-4 h-4 text-slate-500" /> <strong>Tribunal:</strong> {caso.tribunal}</p>
          <p className="flex items-center gap-2"><Gavel className="w-4 h-4 text-slate-500" /> <strong>Órgão Julgador:</strong> {caso.orgao_julgador}</p>
          <p className="flex items-center gap-2"><User className="w-4 h-4 text-slate-500" /> <strong>Relator:</strong> {caso.relator}</p>
          <p className="flex items-center gap-2"><Calendar className="w-4 h-4 text-slate-500" /> <strong>Data:</strong> {format(new Date(caso.data_julgamento), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</p>
        </div>
        <div>
            <h4 className="font-semibold mb-2">Assuntos</h4>
            <div className="flex flex-wrap gap-1">
                {caso.assuntos?.map(a => <Badge key={a} variant="secondary">{a}</Badge>)}
            </div>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Ementa</h4>
          <p className="text-sm text-slate-700 bg-slate-50 p-3 rounded-md whitespace-pre-wrap">{caso.ementa}</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Inteiro Teor</h4>
           <div className="prose prose-sm max-w-none h-48 overflow-y-auto p-3 border rounded-md bg-slate-50">
            <p>{caso.inteiro_teor}</p>
           </div>
        </div>
        <Button className="w-full"><Download className="w-4 h-4 mr-2" /> Baixar Inteiro Teor</Button>
      </CardContent>
    </Card>
  );
}