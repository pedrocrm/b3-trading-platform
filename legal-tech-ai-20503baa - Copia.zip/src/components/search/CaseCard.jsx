import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText, Calendar, Building2, FolderPlus, Sparkles } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function CaseCard({ case: caso, onClick, isSelected, searchMode, onSaveToFolder }) {
  return (
    <Card
      className={`cursor-pointer transition-all duration-200 ${isSelected ? 'ring-2 ring-blue-500 shadow-lg' : 'hover:shadow-md'}`}
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg text-slate-800 hover:text-blue-600">{caso.processo}</h3>
          <div className="flex items-center gap-2">
            {searchMode === 'semantic' && (
              <Badge variant="outline" className="text-purple-600 border-purple-200">
                <Sparkles className="w-3 h-3 mr-1" />
                Relevância IA
              </Badge>
            )}
            <Button size="icon" variant="ghost" onClick={(e) => { e.stopPropagation(); onSaveToFolder(); }}>
                <FolderPlus className="w-5 h-5 text-slate-500 hover:text-blue-600" />
            </Button>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-slate-500 mb-4">
          <div className="flex items-center gap-1.5"><Building2 className="w-4 h-4" /> {caso.tribunal}</div>
          <div className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /> {format(new Date(caso.data_julgamento), "dd/MM/yyyy", { locale: ptBR })}</div>
        </div>
        <p className="text-sm text-slate-600 line-clamp-3 mb-4">{caso.ementa}</p>
        <div className="flex flex-wrap gap-2">
            {caso.categoria_automatica && <Badge>{caso.categoria_automatica}</Badge>}
            {caso.assuntos?.slice(0, 3).map(assunto => <Badge key={assunto} variant="secondary">{assunto}</Badge>)}
        </div>
      </CardContent>
    </Card>
  );
}