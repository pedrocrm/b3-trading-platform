import React from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter } from "lucide-react";

export default function SearchFilters({ onFilterChange }) {
    const [status, setStatus] = React.useState("all");
    const [priority, setPriority] = React.useState("all");
    const [category, setCategory] = React.useState("all");

    const handleFilterChange = (type, value) => {
        if (type === "status") setStatus(value);
        if (type === "priority") setPriority(value);
        if (type === "category") setCategory(value);
        onFilterChange({ 
            status: type === "status" ? value : status, 
            priority: type === "priority" ? value : priority,
            category: type === "category" ? value : category
        });
    };

    return (
        <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={status} onValueChange={(value) => handleFilterChange("status", value)}>
                    <SelectTrigger className="w-32">
                        <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="ativo">Ativo</SelectItem>
                        <SelectItem value="arquivado">Arquivado</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={priority} onValueChange={(value) => handleFilterChange("priority", value)}>
                    <SelectTrigger className="w-32">
                        <SelectValue placeholder="Prioridade" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">Todas</SelectItem>
                        <SelectItem value="alta">Alta</SelectItem>
                        <SelectItem value="media">Média</SelectItem>
                        <SelectItem value="baixa">Baixa</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={category} onValueChange={(value) => handleFilterChange("category", value)}>
                    <SelectTrigger className="w-32">
                        <SelectValue placeholder="Categorias" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">Todas Categorias</SelectItem>
                        <SelectItem value="civil">Civil</SelectItem>
                        <SelectItem value="penal">Penal</SelectItem>
                        <SelectItem value="trabalhista">Trabalhista</SelectItem>
                        <SelectItem value="tributario">Tributário</SelectItem>
                        <SelectItem value="consumidor">Consumidor</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        </div>
    );
}