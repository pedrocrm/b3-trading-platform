import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { InvokeLLM } from '@/api/integrations';
import { Loader2, Telescope } from 'lucide-react';

export default function SimilarCases({ currentCase, allCases, onSelectCase }) {
  const [similarCases, setSimilarCases] = useState([]);
  const [loading, setLoading] = useState(false);

  const findSimilar = useCallback(async () => {
    setLoading(true);
    try {
      if (!currentCase || !allCases) {
        setSimilarCases([]);
        return;
      }
      const otherCases = allCases.filter(c => c.id !== currentCase.id);
      const prompt = `
        Analisando o caso principal (ID ${currentCase.id}):
        Ementa: ${currentCase.ementa}

        Encontre os 3 casos mais similares na lista abaixo, considerando os fatos, os fundamentos jurídicos e o resultado.
        
        Lista de Casos para Comparação:
        ${otherCases.map(c => `ID: ${c.id}\nEmenta: ${c.ementa}\n---\n`).join('')}

        Retorne APENAS os IDs dos 3 casos mais similares, ordenados por similaridade. Formato de resposta: apenas uma lista de IDs separados por vírgula.
      `;
      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: 'object',
          properties: { case_ids: { type: 'array', items: { type: 'string' } } }
        }
      });
      
      const similar = response.case_ids.map(id => allCases.find(c => c.id === id)).filter(Boolean);
      setSimilarCases(similar);
    } catch (error) {
      console.error("Error finding similar cases:", error);
      setSimilarCases([]);
    } finally {
      setLoading(false);
    }
  }, [currentCase, allCases]);

  useEffect(() => {
    if (currentCase && allCases && allCases.length > 0) {
      findSimilar();
    } else {
      setSimilarCases([]);
    }
  }, [currentCase, allCases, findSimilar]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Telescope className="w-5 h-5" />
          Casos Similares (IA)
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center h-24">
            <Loader2 className="w-6 h-6 animate-spin text-slate-500" />
          </div>
        ) : similarCases.length > 0 ? (
          <div className="space-y-2">
            {similarCases.map(caso => (
              <div
                key={caso.id}
                onClick={() => onSelectCase(caso)}
                className="p-2 rounded-md hover:bg-slate-100 cursor-pointer text-sm"
              >
                <p className="font-semibold text-blue-700">{caso.processo}</p>
                <p className="text-slate-600 line-clamp-2">{caso.ementa}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-center text-slate-500 py-4">Nenhum caso similar encontrado pela IA.</p>
        )}
      </CardContent>
    </Card>
  );
}