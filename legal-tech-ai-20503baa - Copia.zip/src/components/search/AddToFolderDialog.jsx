import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pasta } from "@/api/entities";
import { toast } from "sonner";
import { Loader2 } from 'lucide-react';

export default function AddToFolderDialog({ open, onOpenChange, caso, user }) {
  const [pastas, setPastas] = useState([]);
  const [selectedPasta, setSelectedPasta] = useState('');
  const [newPastaName, setNewPastaName] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingPastas, setLoadingPastas] = useState(false);

  const loadPastas = useCallback(async () => {
    if (!user) return;
    setLoadingPastas(true);
    try {
      const userPastas = await Pasta.filter({ created_by: user.email });
      setPastas(userPastas);
    } catch (error) {
      console.error("Erro ao carregar pastas:", error);
      toast.error("Falha ao carregar suas pastas.");
    } finally {
      setLoadingPastas(false);
    }
  }, [user]);

  useEffect(() => {
    if (open && user) {
      loadPastas();
    }
  }, [open, user, loadPastas]);

  const handleAddToPasta = async () => {
    if (!selectedPasta) {
        toast.warning("Por favor, selecione uma pasta.");
        return;
    }
    setLoading(true);
    try {
        const pastaToUpdate = await Pasta.get(selectedPasta);
        
        const itemIdentifier = caso.processo || caso.numeroProcesso;
        if (!itemIdentifier) {
            toast.error("Não foi possível identificar o processo do caso.");
            setLoading(false);
            return;
        }

        const newItem = { entidade: 'Jurisprudencia', id_item: itemIdentifier };

        const itensSalvos = pastaToUpdate.itens_salvos || [];
        
        if (itensSalvos.some(item => item.id_item === itemIdentifier)) {
            toast.info("Este caso já está nesta pasta.");
            setLoading(false);
            onOpenChange(false);
            return;
        }

        await Pasta.update(selectedPasta, {
            itens_salvos: [...itensSalvos, newItem]
        });

        toast.success(`Caso salvo na pasta "${pastaToUpdate.nome}"!`);
        onOpenChange(false);
    } catch (error) {
        console.error("Erro ao salvar na pasta:", error);
        toast.error("Falha ao salvar na pasta.");
    } finally {
        setLoading(false);
    }
  };

  const handleCreateAndAdd = async () => {
    if (!newPastaName.trim()) {
        toast.warning("Por favor, dê um nome para a nova pasta.");
        return;
    }
    setLoading(true);
    try {
        const itemIdentifier = caso.processo || caso.numeroProcesso;
        if (!itemIdentifier) {
            toast.error("Não foi possível identificar o processo do caso.");
            setLoading(false);
            return;
        }
        
        const newItem = { entidade: 'Jurisprudencia', id_item: itemIdentifier };

        await Pasta.create({
            nome: newPastaName,
            descricao: `Pasta para casos sobre ${newPastaName}`,
            itens_salvos: [newItem]
        });
        
        toast.success(`Pasta "${newPastaName}" criada e caso salvo!`);
        onOpenChange(false);
        setNewPastaName('');
    } catch (error) {
        console.error("Erro ao criar pasta:", error);
        toast.error("Falha ao criar a pasta.");
    } finally {
        setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Salvar em Pasta</DialogTitle>
          <DialogDescription>
            Organize seus casos salvando-os em pastas.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
            <div className="space-y-2">
                <h4 className="font-medium">Salvar em pasta existente</h4>
                <div className="flex gap-2">
                    <Select onValueChange={setSelectedPasta} value={selectedPasta}>
                        <SelectTrigger disabled={loadingPastas}>
                            <SelectValue placeholder={loadingPastas ? "Carregando..." : "Selecione uma pasta"} />
                        </SelectTrigger>
                        <SelectContent>
                            {pastas.map(pasta => (
                                <SelectItem key={pasta.id} value={pasta.id}>{pasta.nome}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <Button onClick={handleAddToPasta} disabled={!selectedPasta || loading}>
                        {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Adicionar
                    </Button>
                </div>
            </div>

            <div className="relative">
                <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">Ou</span>
                </div>
            </div>

            <div className="space-y-2">
                <h4 className="font-medium">Criar nova pasta</h4>
                <div className="flex gap-2">
                    <Input
                        placeholder="Nome da nova pasta"
                        value={newPastaName}
                        onChange={(e) => setNewPastaName(e.target.value)}
                    />
                    <Button onClick={handleCreateAndAdd} disabled={!newPastaName.trim() || loading}>
                        {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Criar e Adicionar
                    </Button>
                </div>
            </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}